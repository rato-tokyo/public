r"""PixelDuplex common entry point for sender and receiver.

Install dependencies:
    python -m pip install -r requirements.txt

Configure this directory's config.json and key.txt, then run on both PCs:
    python .\pixelduplex.py run

Run a round-trip diagnostic from the receiver while the sender is running:
    python .\pixelduplex.py self-test

Stop with Ctrl+C or Escape. Paths are always resolved relative to this file,
not relative to the shell's current directory.
"""

from __future__ import annotations

import argparse
import traceback
from pathlib import Path

from src.app import print_status, run_command


BASE = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(description="Encrypted file synchronization over crossed HDMI capture links")
    parser.add_argument("command", choices=("run", "self-test", "status"))
    parser.add_argument("--json", action="store_true", help="accepted for status compatibility")
    args = parser.parse_args()
    if args.command == "status":
        return print_status(BASE)
    return run_command(BASE, args.command)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as error:
        print(f"FAILURE: {error}", flush=True)
        log = BASE / "artifacts" / "logs" / "fatal.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(traceback.format_exc(), encoding="utf-8")
        print(f"Error log: {log}", flush=True)
        raise SystemExit(1)
