r"""PixelDuplex common entry point for sender and receiver.

Install dependencies:
    python -m pip install -r requirements.txt

Configure this directory's config.json and key.txt, then run on both PCs:
    python .\pixelduplex.py run

Run a round-trip diagnostic from the receiver while the sender is running:
    python .\pixelduplex.py self-test

Run an explicit on-disk file round trip from the receiver:
    python .\pixelduplex.py file-test

Stop with Ctrl+C or Escape. Paths are always resolved relative to this file,
not relative to the shell's current directory.
"""

from __future__ import annotations

import argparse
import sys
import time
import traceback
from pathlib import Path

from src.app import InstanceLock, print_status, run_command
from src.ledger import atomic_json


BASE = Path(__file__).resolve().parent


def record_failure_status(base: Path, mode: str) -> None:
    """Replace stale status after a failed launch, unless another run owns it."""
    try:
        with InstanceLock(base / ".pixelduplex.lock"):
            atomic_json(base / "artifacts" / "reports" / "status.json", {
                "status": "FAILURE",
                "reason": "application error; see artifacts/logs/fatal.log",
                "role": None,
                "mode": mode,
                "connected": False,
                "handshake_state": None,
                "session_id": None,
                "active_transfer": None,
                "active_transfer_direction": None,
                "sync_token_owner": None,
                "sync_token_epoch": None,
                "authentication_failures": 0,
                "duplicate_secure_messages": 0,
                "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            })
    except (OSError, RuntimeError):
        # A second invocation must not replace the active instance's status.
        pass


def main() -> int:
    parser = argparse.ArgumentParser(description="Encrypted file synchronization over crossed HDMI capture links")
    parser.add_argument("command", choices=("run", "self-test", "file-test", "status"))
    parser.add_argument("--json", action="store_true", help="show status as JSON (status command)")
    args = parser.parse_args()
    if args.command == "status":
        return print_status(BASE)
    return run_command(BASE, args.command)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as error:
        print(f"FAILURE: {error}", flush=True)
        log = BASE / "artifacts" / "logs" / "fatal.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(traceback.format_exc(), encoding="utf-8")
        print(f"Error log: {log}", flush=True)
        mode = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] in {"run", "self-test", "file-test"} else "unknown"
        record_failure_status(BASE, mode)
        raise SystemExit(1)
