# PixelDuplex

PixelDuplex synchronizes newly added files in both directions between two
Windows PCs over crossed HDMI-output / USB-capture links. Each PC sends only
from its `target/` directory and receives only into its `received/` directory,
which prevents received files from being reflected back automatically.

The initial physical codec is based on the proven 1920x1080, 2x2 monochrome
cell codec from the adjacent `capture` project. File and control data are
authenticated and encrypted with a password from `key.txt`.

## Setup on both PCs

1. Install Python 3.12 or later.
2. Install dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

3. Copy `config.example.json` to `config.json` on each PC.
4. Set one PC's role to `sender` and the other to `receiver`. These are
   connection-establishment roles; both PCs can send and receive files.
5. Create `key.txt` with the same non-empty password on both PCs.
6. Ensure each PC has exactly one suitable non-primary 1920x1080 HDMI output,
   or set its Win32 device name in `monitor_device`.
7. On either PC, put files to send below that PC's `target/` directory. Files
   arriving from the other PC are written below `received/`.

All paths are resolved relative to `pixelduplex.py`, regardless of the shell's
current directory.

## Internal structure

- `src/sync.py` contains reusable one-direction sender and receiver state
  machines.
- `src/duplex.py` combines those state machines and owns the receive token that
  limits the whole link to one active file.
- `src/diagnostic.py` implements the in-memory reliable Blob round trip used by
  `self-test`.
- `src/link.py`, `src/handshake.py`, and `src/crypto.py` provide the authenticated
  encrypted message channel shared by synchronization and diagnostics.
- `src/ledger.py` owns atomic directional ledger persistence and safe migration
  from the version 1 ledger.

## Run

Start both endpoints:

```powershell
python .\pixelduplex.py run
```

The startup handshake retries for up to five minutes. After the connection has
been established, a later disconnect enters reconnection mode without applying
the startup timeout. Stop with Ctrl+C or Escape.

Inspect the last machine-readable state:

```powershell
python .\pixelduplex.py status --json
```

## Physical round-trip self-test

Keep the sender running normally. On the receiver, run:

```powershell
python .\pixelduplex.py self-test
```

The result is written to `artifacts/reports/self_test.json`. Diagnostic bytes
travel in both directions using chunking, selective repeat, ACKs, retransmission,
and SHA-256 verification. They do not enter `received/` or the synchronization
ledger.

## Offline validation

The offline suite does not require HDMI hardware:

```powershell
python -m unittest discover -s tests -v
```

It covers the pixel codec and underscan recovery, authenticated encryption,
tamper and replay rejection, fragmented messages, selective retransmission
under loss and reordering, path containment, atomic publication, ledger
corruption rejection, stability waiting, encrypted bidirectional file transfer,
directional ledgers, reflection prevention, and reliable diagnostic Blob return.

## Intentional initial limitations

- Only regular files are synchronized; links, junctions, reparse points, and
  empty directories are ignored.
- Editing and deletion are not synchronized.
- A completed relative path is never sent again. Use another name or relative
  path for another transfer.
- Only one file is transferred across the link at a time; an authenticated
  receive token alternates which endpoint may request the next file.
- Interrupted files restart from the beginning.
- Existing different content is reported as `CONFLICT` and never overwritten.
- File attributes, ACLs, and timestamps are not reproduced.
