#!/usr/bin/env python3
"""Read-only, bounded PixelDuplex runtime status snapshot.

Exit codes:
    0: healthy (fresh READY/connected status and a live recorded process)
    1: attention required (starting/reconnecting, stale status, or incomplete data)
    2: failure (reported failure, authentication failures, dead process, invalid files)

This utility never opens config.json, key.txt, the ledger, or received files. It
reads status.json and known PID files; bounded *.log tails are read only when
``--include-log-tails`` is explicitly requested.
"""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


EXIT_HEALTHY = 0
EXIT_ATTENTION = 1
EXIT_FAILURE = 2
DEFAULT_STALE_SECONDS = 10.0
DEFAULT_TAIL_LINES = 30
MAX_TAIL_LINES = 200
MAX_TAIL_BYTES = 128 * 1024
MAX_REPORT_BYTES = 256 * 1024
FUTURE_TOLERANCE_SECONDS = 2.0
KNOWN_PID_NAME_RE = re.compile(r"^(?:run|sender-run|receiver-run|self-test|file-test)\.pid$", re.IGNORECASE)
IDENTITY_CHECK_PID_NAME_RE = re.compile(
    r"^(?:sender-run|receiver-run|self-test|file-test)\.pid$", re.IGNORECASE
)

ERROR_RE = re.compile(
    r"(?:traceback|\b(?:error|exception|failure|fatal)\b|authentication.failed|"
    r"could not|reconnecting)",
    re.IGNORECASE,
)
SENSITIVE_FIELD_PATTERN = (
    r"(?:password|passphrase|derived[_ -]?key|secret|token|api[_ -]?key|private[_ -]?key)"
)
SENSITIVE_FIELD_RE = re.compile(SENSITIVE_FIELD_PATTERN, re.IGNORECASE)
SENSITIVE_RE = re.compile(
    rf"({SENSITIVE_FIELD_PATTERN})"
    r"\s*([:=])\s*(?![\"'])(\S+)",
    re.IGNORECASE,
)
SENSITIVE_JSON_RE = re.compile(
    rf'([\"\']{SENSITIVE_FIELD_PATTERN}'
    r'[\"\']\s*:\s*)([\"\'])(.*?)(?<!\\)\2',
    re.IGNORECASE,
)
SENSITIVE_QUOTED_ASSIGN_RE = re.compile(
    r"(?<![\w])"
    rf"({SENSITIVE_FIELD_PATTERN})"
    r"(\s*[=:]\s*)([\"'])(.*?)(?<!\\)\3",
    re.IGNORECASE,
)


def parse_timestamp(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed
    except ValueError:
        return None


def redact(line: str) -> str:
    line = line.rstrip("\r\n")
    try:
        parsed = json.loads(line)
    except (json.JSONDecodeError, TypeError):
        pass
    else:
        if isinstance(parsed, (dict, list)):
            return json.dumps(redact_object(parsed), ensure_ascii=False, separators=(",", ":"))
    line = SENSITIVE_JSON_RE.sub(r'\1\2<redacted>\2', line)
    line = SENSITIVE_QUOTED_ASSIGN_RE.sub(r"\1\2\3<redacted>\3", line)
    return SENSITIVE_RE.sub(r"\1\2<redacted>", line)


def redact_object(value: Any) -> Any:
    """Redact sensitive fields if a future status schema contains them."""
    if isinstance(value, dict):
        return {
            key: ("<redacted>" if SENSITIVE_FIELD_RE.fullmatch(str(key))
                  else redact_object(item))
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [redact_object(item) for item in value]
    return value


def read_json_object(path: Path) -> dict[str, Any]:
    """Read a bounded JSON object and redact any sensitive named fields."""
    size = path.stat().st_size
    if size > MAX_REPORT_BYTES:
        raise ValueError(f"file is too large ({size} bytes; limit {MAX_REPORT_BYTES})")
    loaded = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, dict):
        raise ValueError("root value is not an object")
    return redact_object(loaded)


def tail_lines(path: Path, limit: int) -> list[str]:
    """Return at most *limit* final lines without reading an unbounded log."""
    with path.open("rb") as stream:
        stream.seek(0, os.SEEK_END)
        size = stream.tell()
        stream.seek(max(0, size - MAX_TAIL_BYTES))
        data = stream.read(MAX_TAIL_BYTES)
    text = data.decode("utf-8", errors="replace")
    lines = text.splitlines()
    if size > MAX_TAIL_BYTES and lines:
        lines = lines[1:]  # first line may have begun before the bounded read
    return [redact(line) for line in lines[-limit:]]


def windows_process_alive(pid: int) -> bool | None:
    """Return process liveness on Windows; None means it could not be queried."""
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        except OSError:
            return None

    process_query_limited_information = 0x1000
    still_active = 259
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.OpenProcess.argtypes = [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong]
    kernel32.OpenProcess.restype = ctypes.c_void_p
    kernel32.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
    kernel32.GetExitCodeProcess.restype = ctypes.c_int
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    kernel32.CloseHandle.restype = ctypes.c_int
    handle = kernel32.OpenProcess(process_query_limited_information, False, pid)
    if not handle:
        error = ctypes.get_last_error()
        if error == 87:  # ERROR_INVALID_PARAMETER: PID does not exist
            return False
        if error == 5:  # Access denied still establishes that the PID exists
            return True
        return None
    try:
        exit_code = ctypes.c_ulong()
        if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
            return None
        return exit_code.value == still_active
    finally:
        kernel32.CloseHandle(handle)


def windows_process_is_pixelduplex(pid: int) -> bool | None:
    """Best-effort command-line identity check to reduce PID-reuse false positives."""
    if os.name != "nt":
        return None
    command = (
        "[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false);"
        "$p=Get-CimInstance Win32_Process -Filter \"ProcessId=" + str(pid) + "\";"
        "if($null -eq $p){exit 3};[Console]::Out.Write($p.CommandLine)"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", command],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=3, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0 or not (result.stdout or "").strip():
        return None
    return "pixelduplex.py" in result.stdout.casefold()


def read_pids(
    log_dir: Path, expected_name: str | None = None
) -> tuple[list[dict[str, Any]], list[str]]:
    results: list[dict[str, Any]] = []
    problems: list[str] = []
    for path in sorted(log_dir.glob("*.pid")):
        if not KNOWN_PID_NAME_RE.fullmatch(path.name):
            continue
        if expected_name is not None and path.name.casefold() != expected_name.casefold():
            continue
        item: dict[str, Any] = {"file": path.name, "pid": None, "alive": None}
        try:
            raw = path.read_text(encoding="utf-8").strip()
            pid = int(raw)
            if pid <= 0:
                raise ValueError("PID must be positive")
            item["pid"] = pid
            item["alive"] = windows_process_alive(pid)
            if item["alive"] is False:
                problems.append(f"recorded process is not running: {path.name} PID {pid}")
            elif item["alive"] is None:
                problems.append(f"could not determine process liveness: {path.name} PID {pid}")
            elif os.name == "nt" and IDENTITY_CHECK_PID_NAME_RE.fullmatch(path.name):
                identity = windows_process_is_pixelduplex(pid)
                item["pixelduplex_command"] = identity
                if identity is False:
                    problems.append(
                        f"PID may have been reused; command line is not PixelDuplex: {path.name} PID {pid}"
                    )
                elif identity is None:
                    problems.append(
                        f"could not verify PixelDuplex command line: {path.name} PID {pid}"
                    )
        except (OSError, ValueError) as error:
            item["error"] = str(error)
            problems.append(f"invalid PID file {path.name}: {error}")
        results.append(item)
    return results, problems


def collect(
    base: Path, stale_seconds: float, line_limit: int, include_log_tails: bool = False
) -> tuple[dict[str, Any], int]:
    report_dir = base / "artifacts" / "reports"
    log_dir = base / "artifacts" / "logs"
    status_path = report_dir / "status.json"
    last_transfer_path = report_dir / "last_transfer.json"
    now = datetime.now(timezone.utc)
    severity = EXIT_HEALTHY
    findings: list[str] = []
    status: dict[str, Any] | None = None
    age_seconds: float | None = None

    if not status_path.exists():
        severity = EXIT_ATTENTION
        findings.append("status.json is missing")
    else:
        try:
            status = read_json_object(status_path)
            stamp = parse_timestamp(status.get("updated_at"))
            if stamp is None:
                severity = max(severity, EXIT_ATTENTION)
                findings.append("status updated_at is missing or invalid")
            else:
                raw_age = (now - stamp.astimezone(timezone.utc)).total_seconds()
                age_seconds = max(0.0, raw_age)
                if raw_age < -FUTURE_TOLERANCE_SECONDS:
                    severity = max(severity, EXIT_ATTENTION)
                    findings.append(
                        f"status updated_at is {-raw_age:.1f}s in the future "
                        f"(tolerance {FUTURE_TOLERANCE_SECONDS:.1f}s)"
                    )
                elif age_seconds > stale_seconds:
                    severity = max(severity, EXIT_ATTENTION)
                    findings.append(
                        f"status is stale ({age_seconds:.1f}s old; threshold {stale_seconds:.1f}s)"
                    )
            state = str(status.get("status", "UNKNOWN")).upper()
            if state in {"FAILURE", "FAILED"}:
                severity = EXIT_FAILURE
                findings.append(f"application reported {state}: {status.get('reason') or 'no reason'}")
            elif state not in {"READY", "SUCCESS"}:
                severity = max(severity, EXIT_ATTENTION)
                findings.append(f"application state is {state}")
            if int(status.get("authentication_failures", 0) or 0) > 0:
                severity = EXIT_FAILURE
                findings.append(
                    f"authentication failures: {status.get('authentication_failures')}"
                )
            if state == "READY" and not bool(status.get("connected")):
                severity = EXIT_FAILURE
                findings.append("inconsistent status: READY but connected is false")
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as error:
            severity = EXIT_FAILURE
            findings.append(f"could not read valid status.json: {error}")

    last_transfer: dict[str, Any] | None = None
    last_transfer_age_seconds: float | None = None
    if last_transfer_path.exists():
        try:
            last_transfer = read_json_object(last_transfer_path)
            completed = parse_timestamp(last_transfer.get("completed_at"))
            if completed is not None:
                last_transfer_age_seconds = max(
                    0.0, (now - completed.astimezone(timezone.utc)).total_seconds()
                )
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as error:
            severity = max(severity, EXIT_ATTENTION)
            findings.append(f"could not read valid last_transfer.json: {error}")

    expected_pid_name = None
    if status is not None:
        role = status.get("role")
        mode = status.get("mode")
        if mode in {"self-test", "file-test"}:
            expected_pid_name = f"{mode}.pid"
        elif mode == "run" and role in {"sender", "receiver"}:
            expected_pid_name = f"{role}-run.pid"
    pids, pid_problems = read_pids(log_dir, expected_pid_name)
    if not pids:
        severity = max(severity, EXIT_ATTENTION)
        findings.append(
            f"no PID file found for current status: {expected_pid_name}"
            if expected_pid_name else "no PID file found"
        )
    for problem in pid_problems:
        severity = max(severity, EXIT_FAILURE if "not running" in problem or "invalid" in problem else EXIT_ATTENTION)
        findings.append(problem)

    logs: list[dict[str, Any]] = []
    error_lines: list[dict[str, Any]] = []
    if include_log_tails:
        for path in sorted(log_dir.glob("*.log")):
            try:
                lines = tail_lines(path, line_limit)
                modified_at = datetime.fromtimestamp(path.stat().st_mtime, timezone.utc)
                log_age = max(0.0, (now - modified_at).total_seconds())
                logs.append({"file": path.name, "tail": lines, "age_seconds": round(log_age, 3)})
                for line in lines:
                    if ERROR_RE.search(line):
                        error_lines.append({
                            "file": path.name, "line": line, "historical": True,
                            "log_age_seconds": round(log_age, 3),
                        })
            except OSError as error:
                severity = max(severity, EXIT_ATTENTION)
                findings.append(f"could not read log tail {path.name}: {error}")

    result = {
        "health": ("healthy", "attention", "failure")[severity],
        "exit_code": severity,
        "checked_at": now.isoformat(timespec="seconds"),
        "base": str(base),
        "status_age_seconds": round(age_seconds, 3) if age_seconds is not None else None,
        "stale_after_seconds": stale_seconds,
        "status": status,
        "diagnostics": {
            "authentication_failures": (
                status.get("authentication_failures") if status is not None else None
            ),
            "connected": status.get("connected") if status is not None else None,
            "handshake_state": (
                status.get("handshake_state") if status is not None else None
            ),
            "active_transfer": (
                status.get("active_transfer") if status is not None else None
            ),
            "active_transfer_direction": (
                status.get("active_transfer_direction") if status is not None else None
            ),
            "last_transfer": last_transfer,
            "last_transfer_age_seconds": (
                round(last_transfer_age_seconds, 3)
                if last_transfer_age_seconds is not None else None
            ),
        },
        "processes": pids,
        "findings": findings,
    }
    if include_log_tails:
        result["error_like_log_lines"] = error_lines
        result["logs"] = logs
    return result, severity


def print_human(snapshot: dict[str, Any]) -> None:
    status = snapshot.get("status") or {}
    print(f"PixelDuplex: {snapshot['health'].upper()} (exit {snapshot['exit_code']})")
    print(
        "Status: "
        f"{status.get('status', 'UNKNOWN')} | connected={status.get('connected', 'unknown')} | "
        f"handshake={status.get('handshake_state', 'unknown')} | "
        f"auth_failures={status.get('authentication_failures', 'unknown')}"
    )
    age = snapshot.get("status_age_seconds")
    print(f"Freshness: {'unknown' if age is None else f'{age:.1f}s old'}")
    diagnostics = snapshot.get("diagnostics") or {}
    active = diagnostics.get("active_transfer")
    print(
        "Transfer: "
        + (f"active {diagnostics.get('active_transfer_direction') or 'unknown'} {active}"
           if active else "idle")
    )
    last_transfer = diagnostics.get("last_transfer")
    if last_transfer:
        print(
            "Last transfer: "
            f"{last_transfer.get('status', 'UNKNOWN')} | "
            f"path={last_transfer.get('relative_path', 'unknown')} | "
            f"reason={last_transfer.get('reason') or 'none'}"
        )
    else:
        print("Last transfer: none recorded")
    if snapshot["processes"]:
        for process in snapshot["processes"]:
            print(f"Process: {process['file']} PID={process.get('pid')} alive={process.get('alive')}")
    else:
        print("Process: no PID file")
    if snapshot["findings"]:
        print("Findings:")
        for finding in snapshot["findings"]:
            print(f"  - {finding}")
    if snapshot.get("error_like_log_lines"):
        print("Historical error-like lines in explicitly requested bounded log tails:")
        for item in snapshot["error_like_log_lines"]:
            print(f"  [{item['file']}] {item['line']}")
    elif "error_like_log_lines" in snapshot:
        print("Error-like lines in bounded log tails: none")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="emit one JSON object")
    parser.add_argument(
        "--include-log-tails", action="store_true",
        help="include bounded, redacted log text (omitted by default)",
    )
    parser.add_argument(
        "--stale-seconds", type=float, default=DEFAULT_STALE_SECONDS,
        help=f"status age that requires attention (default: {DEFAULT_STALE_SECONDS:g})",
    )
    parser.add_argument(
        "--tail-lines", type=int, default=DEFAULT_TAIL_LINES,
        help=f"maximum lines read from each log tail (default: {DEFAULT_TAIL_LINES})",
    )
    args = parser.parse_args(argv)
    if args.stale_seconds <= 0:
        parser.error("--stale-seconds must be positive")
    if not 0 <= args.tail_lines <= MAX_TAIL_LINES:
        parser.error(f"--tail-lines must be between 0 and {MAX_TAIL_LINES}")

    base = Path(__file__).resolve().parent.parent
    snapshot, exit_code = collect(
        base, args.stale_seconds, args.tail_lines, include_log_tails=args.include_log_tails
    )
    if args.json:
        # Keep redirected output independent of the active Windows code page.
        print(json.dumps(snapshot, ensure_ascii=True, indent=2))
    else:
        print_human(snapshot)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
