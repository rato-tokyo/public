"""Windows display/capture transport for PixelDuplex physical frames."""

from __future__ import annotations

import ctypes
import queue
import threading
import time
from collections import deque
from ctypes import wintypes

import cv2

from .constants import DEFAULT_FRAME_INTERVAL_SECONDS, HEIGHT, WIDTH
from .wire import FragmentAssembler, PhysicalPacket, decode_image, packet_image


def configure_dpi() -> None:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def active_monitors() -> list[dict]:
    if not hasattr(ctypes, "windll"):
        raise RuntimeError("PixelDuplex hardware mode requires Windows")
    monitors: list[dict] = []
    callback_type = ctypes.WINFUNCTYPE(
        ctypes.c_int, wintypes.HMONITOR, wintypes.HDC,
        ctypes.POINTER(wintypes.RECT), wintypes.LPARAM,
    )

    class MONITORINFOEXW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
            ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD),
            ("szDevice", wintypes.WCHAR * 32),
        ]

    def callback(handle, _dc, _rect, _data):
        info = MONITORINFOEXW()
        info.cbSize = ctypes.sizeof(info)
        if ctypes.windll.user32.GetMonitorInfoW(handle, ctypes.byref(info)):
            rect = info.rcMonitor
            monitors.append({
                "handle": handle, "device": info.szDevice,
                "primary": bool(info.dwFlags & 1),
                "rect": (rect.left, rect.top, rect.right, rect.bottom),
            })
        return 1

    ctypes.windll.user32.EnumDisplayMonitors(None, None, callback_type(callback), 0)
    return monitors


def choose_external_monitor(monitors: list[dict], configured_device: str | None = None) -> dict:
    candidates = [item for item in monitors if not item["primary"]]
    if configured_device:
        candidates = [item for item in candidates if item["device"] == configured_device]
    if len(candidates) != 1:
        listing = "; ".join(
            f"{item['device']} primary={item['primary']} rect={item['rect']}"
            for item in monitors
        )
        raise RuntimeError(
            "could not select exactly one non-primary monitor before display; "
            f"detected: {listing or 'none'}"
        )
    selected = candidates[0]
    left, top, right, bottom = selected["rect"]
    if (right - left, bottom - top) != (WIDTH, HEIGHT):
        raise RuntimeError(
            f"PixelDuplex v1 requires a 1920x1080 external monitor; "
            f"selected {selected['device']} is {right-left}x{bottom-top}"
        )
    return selected


def position_and_verify(window: str, monitor: dict) -> None:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    find_window = user32.FindWindowW
    find_window.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    find_window.restype = wintypes.HWND
    hwnd = find_window(None, window)
    if not hwnd:
        raise RuntimeError("could not locate output window")
    show_window = user32.ShowWindow
    show_window.argtypes = [wintypes.HWND, ctypes.c_int]
    show_window.restype = wintypes.BOOL
    show_window(hwnd, 0)
    gwl_style, ws_popup, ws_visible = -16, 0x80000000, 0x10000000
    try:
        set_style = user32.SetWindowLongPtrW
        set_style.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
        set_style.restype = ctypes.c_ssize_t
        style = ws_popup | ws_visible
    except AttributeError:
        set_style = user32.SetWindowLongW
        set_style.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.LONG]
        set_style.restype = wintypes.LONG
        style = ctypes.c_long(ws_popup | ws_visible).value
    ctypes.set_last_error(0)
    previous = set_style(hwnd, gwl_style, style)
    if previous == 0 and ctypes.get_last_error():
        raise ctypes.WinError(ctypes.get_last_error())
    left, top, right, bottom = monitor["rect"]
    set_position = user32.SetWindowPos
    set_position.argtypes = [
        wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
        ctypes.c_int, ctypes.c_int, wintypes.UINT,
    ]
    set_position.restype = wintypes.BOOL
    if not set_position(hwnd, wintypes.HWND(-1), left, top, right - left, bottom - top, 0x20 | 0x40):
        raise ctypes.WinError(ctypes.get_last_error())
    actual = wintypes.RECT()
    get_rect = user32.GetWindowRect
    get_rect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    get_rect.restype = wintypes.BOOL
    if not get_rect(hwnd, ctypes.byref(actual)):
        raise ctypes.WinError(ctypes.get_last_error())
    if (actual.left, actual.top, actual.right, actual.bottom) != monitor["rect"]:
        raise RuntimeError("output window placement verification failed")


def open_capture(device: int):
    capture = cv2.VideoCapture(device, cv2.CAP_DSHOW)
    if capture.isOpened():
        capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"YUY2"))
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
        capture.set(cv2.CAP_PROP_FPS, 30)
    return capture


class HdmiFrameIO:
    """Queue physical packets while continuously capturing in a worker thread."""

    def __init__(self, device: int, monitor_device: str | None = None,
                 frame_interval: float = DEFAULT_FRAME_INTERVAL_SECONDS):
        self.device = device
        self.monitor_device = monitor_device
        self.frame_interval = frame_interval
        self.window = "PixelDuplex Data Display"
        self._outgoing: deque[PhysicalPacket] = deque()
        self._incoming: queue.Queue[tuple[PhysicalPacket, tuple | None]] = queue.Queue(maxsize=512)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._capture = None
        self._next_frame_at = 0.0

    def start(self) -> None:
        configure_dpi()
        monitor = choose_external_monitor(active_monitors(), self.monitor_device)
        self._capture = open_capture(self.device)
        if not self._capture.isOpened():
            raise RuntimeError(f"could not open capture device {self.device}")
        cv2.namedWindow(self.window, cv2.WINDOW_NORMAL)
        position_and_verify(self.window, monitor)
        self._thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._thread.start()

    def send(self, packets: list[PhysicalPacket]) -> None:
        self._outgoing.extend(packets)

    def clear_outgoing(self) -> None:
        self._outgoing.clear()

    def pump_display(self) -> bool:
        now = time.monotonic()
        if self._outgoing and now >= self._next_frame_at:
            cv2.imshow(self.window, packet_image(self._outgoing.popleft()))
            self._next_frame_at = now + self.frame_interval
        return (cv2.waitKey(1) & 0xFF) != 27

    def receive(self) -> list[tuple[PhysicalPacket, tuple | None]]:
        result = []
        while True:
            try:
                result.append(self._incoming.get_nowait())
            except queue.Empty:
                return result

    def _capture_loop(self) -> None:
        while not self._stop.is_set():
            ok, frame = self._capture.read()
            if not ok:
                continue
            packet, rect = decode_image(frame)
            if packet is not None:
                try:
                    self._incoming.put_nowait((packet, rect))
                except queue.Full:
                    pass

    def close(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)
        if self._capture is not None:
            self._capture.release()
        cv2.destroyAllWindows()
