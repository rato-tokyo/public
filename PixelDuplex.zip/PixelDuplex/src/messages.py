"""Compact application-message serialization."""

from __future__ import annotations

import json
import struct


DATA_HEADER = struct.Struct("<16sI")
ACK_HEADER = struct.Struct("<16sIQ")


def json_bytes(value: dict | list) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, separators=(",", ":"), sort_keys=True,
    ).encode("utf-8")


def parse_json(payload: bytes):
    return json.loads(payload.decode("utf-8"))


def encode_data(transfer_id: bytes, index: int, data: bytes) -> bytes:
    if len(transfer_id) != 16:
        raise ValueError("transfer_id must be 16 bytes")
    return DATA_HEADER.pack(transfer_id, index) + data


def decode_data(payload: bytes) -> tuple[bytes, int, bytes]:
    if len(payload) < DATA_HEADER.size:
        raise ValueError("file data message is too short")
    transfer_id, index = DATA_HEADER.unpack_from(payload)
    return transfer_id, index, payload[DATA_HEADER.size:]


def encode_ack(transfer_id: bytes, base: int, bitmap: int) -> bytes:
    if len(transfer_id) != 16:
        raise ValueError("transfer_id must be 16 bytes")
    return ACK_HEADER.pack(transfer_id, base, bitmap)


def decode_ack(payload: bytes) -> tuple[bytes, int, int]:
    if len(payload) != ACK_HEADER.size:
        raise ValueError("file ACK message has invalid length")
    return ACK_HEADER.unpack(payload)
