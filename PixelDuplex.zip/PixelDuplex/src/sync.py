"""Receiver-driven file synchronization state machines."""

from __future__ import annotations

import math
import uuid
import time
from dataclasses import dataclass
from pathlib import Path

from .constants import (
    DEFAULT_RETRANSMIT_SECONDS, DEFAULT_SCAN_INTERVAL_SECONDS,
    DEFAULT_STABLE_SECONDS, DEFAULT_WINDOW_SIZE, FILE_CHUNK_BYTES, MessageKind,
)
from .files import (
    AtomicReceiver, FileSnapshot, StabilityTracker, normalized_relative,
    safe_output_path, scan_regular_files, sha256_file, snapshot_file,
)
from .ledger import Ledger, atomic_json
from .messages import (
    decode_ack, decode_data, encode_ack, encode_data, json_bytes, parse_json,
)
from .reliable import SelectiveRepeatReceiver, SelectiveRepeatSender


AppMessage = tuple[int, bytes]


@dataclass
class SenderTransfer:
    transfer_id: bytes
    path: Path
    snapshot: FileSnapshot
    chunk_count: int
    reliable: SelectiveRepeatSender
    stream: object

    def read(self, index: int) -> bytes:
        self.stream.seek(index * FILE_CHUNK_BYTES)
        return self.stream.read(FILE_CHUNK_BYTES)

    def close(self) -> None:
        self.stream.close()


class SenderEngine:
    def __init__(self, root: Path, ledger: Ledger, *, window_size: int = DEFAULT_WINDOW_SIZE,
                 scan_interval: float = DEFAULT_SCAN_INTERVAL_SECONDS,
                 stable_seconds: float = DEFAULT_STABLE_SECONDS,
                 retransmit_seconds: float = DEFAULT_RETRANSMIT_SECONDS):
        self.root = root
        self.ledger = ledger
        self.window_size = window_size
        self.scan_interval = scan_interval
        self.retransmit_seconds = retransmit_seconds
        self.stability = StabilityTracker(stable_seconds)
        self.snapshots: dict[str, FileSnapshot] = {}
        self.paths: dict[str, Path] = {}
        self.last_scan = float("-inf")
        self.transfer: SenderTransfer | None = None
        self.completed_transfer_ids: set[str] = set()

    def close(self) -> None:
        if self.transfer is not None:
            self.transfer.close()
            self.transfer = None

    def scan(self, now: float) -> list[AppMessage]:
        if now - self.last_scan < self.scan_interval:
            return []
        self.last_scan = now
        announcements: list[AppMessage] = []
        for path in scan_regular_files(self.root):
            relative = normalized_relative(self.root, path)
            self.paths[relative] = path
            if self.ledger.is_complete(relative):
                continue
            info = path.stat()
            if not self.stability.observe(relative, info.st_size, info.st_mtime_ns, now):
                continue
            cached = self.snapshots.get(relative)
            if cached and (cached.size, cached.mtime_ns) == (info.st_size, info.st_mtime_ns):
                announcements.append((MessageKind.FILE_ANNOUNCE, json_bytes(self._item(cached))))
                continue
            try:
                snapshot = snapshot_file(self.root, path)
            except (OSError, RuntimeError):
                continue
            self.snapshots[relative] = snapshot
            announcements.append((MessageKind.FILE_ANNOUNCE, json_bytes(self._item(snapshot))))
        return announcements

    def _item(self, snapshot: FileSnapshot) -> dict:
        return {
            "path": snapshot.relative_path,
            "size": snapshot.size,
            "sha256": snapshot.sha256,
            "sendable": not self.ledger.is_complete(snapshot.relative_path),
        }

    def manifest(self) -> list[dict]:
        items = []
        for path in scan_regular_files(self.root):
            relative = normalized_relative(self.root, path)
            self.paths[relative] = path
            if self.ledger.is_complete(relative):
                record = self.ledger.get(relative) or {}
                items.append({
                    "path": relative, "size": record.get("size"),
                    "sha256": record.get("sha256"), "sendable": False,
                })
            elif relative in self.snapshots:
                items.append(self._item(self.snapshots[relative]))
            else:
                try:
                    size = path.stat().st_size
                except OSError:
                    continue
                items.append({
                    "path": relative, "size": size, "sha256": None,
                    "sendable": False, "reason": "waiting for file stability",
                })
        return items

    def handle(self, kind: int, payload: bytes, now: float) -> list[AppMessage]:
        if kind == MessageKind.MANIFEST_REQUEST:
            return [(MessageKind.MANIFEST, json_bytes(self.manifest()))]
        if kind == MessageKind.FILE_REQUEST:
            return self._request(parse_json(payload), now)
        if kind == MessageKind.FILE_ACK and self.transfer:
            transfer_id, base, bitmap = decode_ack(payload)
            if transfer_id == self.transfer.transfer_id:
                self.transfer.reliable.acknowledge(base, bitmap)
            return []
        if kind == MessageKind.FILE_COMPLETE and self.transfer:
            value = parse_json(payload)
            if value.get("transfer_id") != self.transfer.transfer_id.hex():
                return []
            snapshot = self.transfer.snapshot
            if value.get("sha256") != snapshot.sha256 or value.get("size") != snapshot.size:
                return []
            self.ledger.record(
                snapshot.relative_path, status="SUCCESS", size=snapshot.size,
                sha256=snapshot.sha256, session_id=value.get("session_id"),
            )
            transfer_id = self.transfer.transfer_id.hex()
            self.completed_transfer_ids.add(transfer_id)
            self.transfer.close()
            self.transfer = None
            return [(MessageKind.COMPLETE_CONFIRM, json_bytes({"transfer_id": transfer_id}))]
        if kind == MessageKind.FILE_COMPLETE:
            value = parse_json(payload)
            transfer_id = value.get("transfer_id")
            if transfer_id in self.completed_transfer_ids:
                return [(MessageKind.COMPLETE_CONFIRM, json_bytes({"transfer_id": transfer_id}))]
        if kind == MessageKind.ALREADY_COMPLETE:
            value = parse_json(payload)
            relative = value.get("path")
            if relative in self.paths:
                self.ledger.record(
                    relative, status="SUCCESS", size=value.get("size"),
                    sha256=value.get("sha256"), session_id=value.get("session_id"),
                    reason="receiver already held identical content",
                )
            return []
        return []

    def _request(self, value: dict, now: float) -> list[AppMessage]:
        relative = value.get("path")
        if not isinstance(relative, str):
            return []
        if self.ledger.is_complete(relative):
            record = self.ledger.get(relative) or {}
            return [(MessageKind.ALREADY_COMPLETE, json_bytes({
                "path": relative, "size": record.get("size"),
                "sha256": record.get("sha256"), "session_id": record.get("session_id"),
            }))]
        snapshot = self.snapshots.get(relative)
        path = self.paths.get(relative)
        if self.transfer is not None:
            if self.transfer.snapshot.relative_path == relative:
                return [self._metadata_message(self.transfer)]
            return []
        if snapshot is None or path is None:
            return []
        info = path.stat()
        if (info.st_size, info.st_mtime_ns) != (snapshot.size, snapshot.mtime_ns):
            self.snapshots.pop(relative, None)
            return [(MessageKind.CONFLICT, json_bytes({"path": relative, "reason": "source changed"}))]
        transfer_id = uuid.uuid4().bytes
        chunk_count = max(1, math.ceil(snapshot.size / FILE_CHUNK_BYTES))
        self.transfer = SenderTransfer(
            transfer_id, path, snapshot, chunk_count,
            SelectiveRepeatSender(chunk_count, self.window_size, self.retransmit_seconds),
            path.open("rb"),
        )
        return [self._metadata_message(self.transfer)]

    @staticmethod
    def _metadata_message(transfer: SenderTransfer) -> AppMessage:
        return MessageKind.FILE_META, json_bytes({
            "transfer_id": transfer.transfer_id.hex(),
            "path": transfer.snapshot.relative_path,
            "size": transfer.snapshot.size, "sha256": transfer.snapshot.sha256,
            "chunk_count": transfer.chunk_count, "chunk_bytes": FILE_CHUNK_BYTES,
        })

    def tick(self, now: float) -> list[AppMessage]:
        outgoing = self.scan(now)
        transfer = self.transfer
        if transfer is None:
            return outgoing
        try:
            info = transfer.path.stat()
        except OSError:
            info = None
        if info is None or (info.st_size, info.st_mtime_ns) != (
            transfer.snapshot.size, transfer.snapshot.mtime_ns,
        ):
            relative = transfer.snapshot.relative_path
            transfer.close()
            self.transfer = None
            self.snapshots.pop(relative, None)
            outgoing.append((MessageKind.CONFLICT, json_bytes({
                "path": relative, "reason": "source changed during transfer",
            })))
            return outgoing
        for transmission in transfer.reliable.due(now):
            outgoing.append((
                MessageKind.FILE_DATA,
                encode_data(transfer.transfer_id, transmission.index, transfer.read(transmission.index)),
            ))
        return outgoing


@dataclass
class ReceiverTransfer:
    transfer_id: bytes
    relative_path: str
    size: int
    sha256: str
    writer: AtomicReceiver
    reliable: SelectiveRepeatReceiver
    started_at: float
    first_chunk_at: float | None = None
    last_chunk_at: float | None = None
    first_chunk_bytes: int | None = None
    duplicate_chunks: int = 0


class ReceiverEngine:
    def __init__(self, root: Path, ledger: Ledger, session_id: str = "local",
                 report_path: Path | None = None):
        self.root = root
        self.ledger = ledger
        self.session_id = session_id
        self.report_path = report_path
        self.manifest_received = False
        self.last_request = float("-inf")
        self.pending: list[dict] = []
        self.queued_paths: set[str] = set()
        self.transfer: ReceiverTransfer | None = None
        self.completed_message: AppMessage | None = None
        self.last_complete_sent = float("-inf")

    def close(self) -> None:
        if self.transfer is not None:
            self.transfer.writer.abort()
            self.transfer = None
        self.completed_message = None

    def _failure_report(self, relative: str, reason: str, *, status: str = "FAILURE") -> None:
        if self.report_path is not None:
            atomic_json(self.report_path, {
                "status": status, "reason": reason, "relative_path": relative,
                "sha256_verified": False, "session_id": self.session_id,
                "goodput_bytes_per_second": None,
                "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            })

    def _consider(self, item: dict) -> list[AppMessage]:
        relative = item.get("path")
        digest = item.get("sha256")
        size = item.get("size")
        if not isinstance(relative, str) or not item.get("sendable", True):
            return []
        if self.ledger.is_complete(relative):
            record = self.ledger.get(relative) or {}
            return [(MessageKind.ALREADY_COMPLETE, json_bytes({
                "path": relative, "size": record.get("size"),
                "sha256": record.get("sha256"),
                "session_id": record.get("session_id"),
            }))]
        if relative in self.queued_paths:
            return []
        output = safe_output_path(self.root, relative)
        if output.exists():
            if output.is_file() and isinstance(digest, str) and sha256_file(output) == digest:
                self.ledger.record(
                    relative, status="SUCCESS", size=size, sha256=digest,
                    session_id=self.session_id,
                    reason="identical file already existed",
                )
                return [(MessageKind.ALREADY_COMPLETE, json_bytes({
                    "path": relative, "size": size, "sha256": digest,
                    "session_id": self.session_id,
                }))]
            self.ledger.record(
                relative, status="CONFLICT", size=size, sha256=digest,
                session_id=self.session_id, reason="destination exists with different content",
            )
            self._failure_report(
                relative, "destination exists with different content", status="CONFLICT",
            )
            return [(MessageKind.CONFLICT, json_bytes({
                "path": relative, "reason": "destination exists with different content",
            }))]
        self.pending.append(item)
        self.queued_paths.add(relative)
        return []

    def handle(self, kind: int, payload: bytes, now: float) -> list[AppMessage]:
        outgoing: list[AppMessage] = []
        if kind == MessageKind.MANIFEST:
            value = parse_json(payload)
            if not isinstance(value, list):
                return []
            self.manifest_received = True
            for item in value:
                if isinstance(item, dict):
                    outgoing.extend(self._consider(item))
        elif kind == MessageKind.FILE_ANNOUNCE:
            value = parse_json(payload)
            if isinstance(value, dict):
                outgoing.extend(self._consider(value))
        elif kind == MessageKind.FILE_META:
            outgoing.extend(self._metadata(parse_json(payload), now))
        elif kind == MessageKind.FILE_DATA and self.transfer:
            if self.completed_message is not None:
                return [self.completed_message]
            transfer_id, index, data = decode_data(payload)
            if transfer_id != self.transfer.transfer_id:
                return outgoing
            is_new = self.transfer.writer.write(index, data)
            self.transfer.reliable.accept(index)
            if is_new:
                if self.transfer.first_chunk_at is None:
                    self.transfer.first_chunk_at = now
                    self.transfer.first_chunk_bytes = len(data)
                self.transfer.last_chunk_at = now
            else:
                self.transfer.duplicate_chunks += 1
            base, bitmap = self.transfer.reliable.ack()
            outgoing.append((MessageKind.FILE_ACK, encode_ack(transfer_id, base, bitmap)))
            if self.transfer.reliable.done:
                outgoing.extend(self._publish(now))
        elif kind == MessageKind.COMPLETE_CONFIRM and self.transfer:
            value = parse_json(payload)
            if value.get("transfer_id") == self.transfer.transfer_id.hex():
                self.transfer = None
                self.completed_message = None
        elif kind == MessageKind.CONFLICT:
            value = parse_json(payload)
            if self.transfer and value.get("path") == self.transfer.relative_path:
                self._failure_report(
                    self.transfer.relative_path,
                    str(value.get("reason") or "sender cancelled transfer"),
                )
                self.transfer.writer.abort()
                self.queued_paths.discard(self.transfer.relative_path)
                self.transfer = None
                self.completed_message = None
        return outgoing

    def _metadata(self, value: dict, now: float) -> list[AppMessage]:
        relative = value.get("path")
        if self.transfer is not None or not self.pending or self.pending[0].get("path") != relative:
            return []
        transfer_id = bytes.fromhex(value["transfer_id"])
        output = safe_output_path(self.root, relative)
        writer = AtomicReceiver(
            output, int(value["size"]), value["sha256"], int(value["chunk_count"]),
            int(value["chunk_bytes"]),
        )
        self.transfer = ReceiverTransfer(
            transfer_id, relative, int(value["size"]), value["sha256"], writer,
            SelectiveRepeatReceiver(int(value["chunk_count"])), now,
        )
        self.pending.pop(0)
        base, bitmap = self.transfer.reliable.ack()
        return [(MessageKind.FILE_ACK, encode_ack(transfer_id, base, bitmap))]

    def _publish(self, now: float) -> list[AppMessage]:
        assert self.transfer is not None
        try:
            self.transfer.writer.publish()
        except Exception as error:
            self._failure_report(self.transfer.relative_path, f"publish failed: {error}")
            raise
        self.ledger.record(
            self.transfer.relative_path, status="SUCCESS", size=self.transfer.size,
            sha256=self.transfer.sha256, session_id=self.session_id,
        )
        transfer_seconds = None
        measured_bytes = None
        goodput = None
        if (
            self.transfer.first_chunk_at is not None
            and self.transfer.last_chunk_at is not None
            and self.transfer.last_chunk_at > self.transfer.first_chunk_at
            and len(self.transfer.reliable.received) >= 2
        ):
            transfer_seconds = self.transfer.last_chunk_at - self.transfer.first_chunk_at
            measured_bytes = self.transfer.size - (self.transfer.first_chunk_bytes or 0)
            goodput = measured_bytes / transfer_seconds
        if self.report_path is not None:
            atomic_json(self.report_path, {
                "status": "SUCCESS",
                "reason": "file reconstructed and SHA-256 verified",
                "relative_path": self.transfer.relative_path,
                "file_size": self.transfer.size,
                "expected_sha256": self.transfer.sha256,
                "actual_sha256": self.transfer.sha256,
                "sha256_verified": True,
                "session_id": self.session_id,
                "transfer_id": self.transfer.transfer_id.hex(),
                "unique_chunks": len(self.transfer.reliable.received),
                "duplicate_chunks": self.transfer.duplicate_chunks,
                "transfer_seconds": transfer_seconds,
                "goodput_measured_bytes": measured_bytes,
                "goodput_bytes_per_second": goodput,
                "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            })
        self.completed_message = (
            MessageKind.FILE_COMPLETE,
            json_bytes({
                "transfer_id": self.transfer.transfer_id.hex(),
                "path": self.transfer.relative_path, "size": self.transfer.size,
                "sha256": self.transfer.sha256, "session_id": self.session_id,
            }),
        )
        self.last_complete_sent = now
        return [self.completed_message]

    def tick(self, now: float) -> list[AppMessage]:
        if self.completed_message is not None:
            if now - self.last_complete_sent >= 1.0:
                self.last_complete_sent = now
                return [self.completed_message]
            return []
        if self.transfer is not None:
            return []
        if not self.manifest_received and now - self.last_request >= 1.0:
            self.last_request = now
            return [(MessageKind.MANIFEST_REQUEST, b"")]
        if self.pending and now - self.last_request >= 1.0:
            self.last_request = now
            return [(MessageKind.FILE_REQUEST, json_bytes({"path": self.pending[0]["path"]}))]
        return []
