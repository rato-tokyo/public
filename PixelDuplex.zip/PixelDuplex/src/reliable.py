"""Fixed-window Selective Repeat state machines."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Transmission:
    index: int
    attempts: int


class SelectiveRepeatSender:
    def __init__(self, chunk_count: int, window_size: int, retransmit_seconds: float):
        if chunk_count <= 0 or window_size <= 0 or retransmit_seconds <= 0:
            raise ValueError("selective-repeat parameters must be positive")
        self.chunk_count = chunk_count
        self.window_size = window_size
        self.retransmit_seconds = retransmit_seconds
        self.base = 0
        self.next_index = 0
        self.acked: set[int] = set()
        self.sent_at: dict[int, float] = {}
        self.attempts: dict[int, int] = {}

    @property
    def done(self) -> bool:
        return len(self.acked) == self.chunk_count

    def acknowledge(self, base: int, bitmap: int, width: int = 64) -> None:
        if not 0 <= base <= self.chunk_count:
            raise ValueError("ACK base out of range")
        self.acked.update(range(base))
        for offset in range(width):
            index = base + offset
            if index < self.chunk_count and bitmap & (1 << offset):
                self.acked.add(index)
        while self.base in self.acked:
            self.base += 1
        for index in list(self.sent_at):
            if index in self.acked:
                self.sent_at.pop(index, None)

    def due(self, now: float) -> list[Transmission]:
        result: list[Transmission] = []
        ceiling = min(self.chunk_count, self.base + self.window_size)
        while self.next_index < ceiling:
            index = self.next_index
            self.next_index += 1
            if index not in self.acked:
                result.append(self._mark(index, now))
        for index, sent_at in sorted(self.sent_at.items()):
            if index not in self.acked and now - sent_at >= self.retransmit_seconds:
                result.append(self._mark(index, now))
        return result

    def _mark(self, index: int, now: float) -> Transmission:
        self.sent_at[index] = now
        self.attempts[index] = self.attempts.get(index, 0) + 1
        return Transmission(index, self.attempts[index])


class SelectiveRepeatReceiver:
    def __init__(self, chunk_count: int):
        if chunk_count <= 0:
            raise ValueError("chunk_count must be positive")
        self.chunk_count = chunk_count
        self.received: set[int] = set()

    def accept(self, index: int) -> bool:
        if not 0 <= index < self.chunk_count:
            raise ValueError("chunk index out of range")
        is_new = index not in self.received
        self.received.add(index)
        return is_new

    @property
    def done(self) -> bool:
        return len(self.received) == self.chunk_count

    def ack(self, width: int = 64) -> tuple[int, int]:
        base = 0
        while base in self.received:
            base += 1
        bitmap = 0
        for offset in range(width):
            if base + offset in self.received:
                bitmap |= 1 << offset
        return base, bitmap
