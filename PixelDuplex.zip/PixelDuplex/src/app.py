"""PixelDuplex command-line application and hardware event loop."""

from __future__ import annotations

import json
import os
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path

from .constants import (
    DEFAULT_FRAME_INTERVAL_SECONDS, DEFAULT_HANDSHAKE_TIMEOUT_SECONDS,
    DEFAULT_RETRANSMIT_SECONDS, DEFAULT_SCAN_INTERVAL_SECONDS,
    DEFAULT_STABLE_SECONDS, DEFAULT_WINDOW_SIZE, MessageKind,
)
from .diagnostic import DiagnosticSession
from .duplex import DuplexEngine
from .hardware import HdmiFrameIO
from .ledger import Ledger, atomic_json
from .link import LinkSession


@dataclass(frozen=True)
class Settings:
    role: str
    capture_device: int
    monitor_device: str | None
    scan_interval_seconds: float
    file_stable_seconds: float
    handshake_timeout_seconds: float
    frame_interval_seconds: float
    retransmit_seconds: float
    window_size: int


def load_settings(base: Path) -> Settings:
    path = base / "config.json"
    if not path.exists():
        raise RuntimeError(
            f"Missing config: {path}\nCopy config.example.json to config.json and set role."
        )
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise RuntimeError(f"Invalid config.json: {error}") from error
    role = value.get("role")
    if role not in {"sender", "receiver"}:
        raise RuntimeError("config.json role must be sender or receiver")
    settings = Settings(
        role=role,
        capture_device=int(value.get("capture_device", 1)),
        monitor_device=value.get("monitor_device"),
        scan_interval_seconds=float(value.get("scan_interval_seconds", DEFAULT_SCAN_INTERVAL_SECONDS)),
        file_stable_seconds=float(value.get("file_stable_seconds", DEFAULT_STABLE_SECONDS)),
        handshake_timeout_seconds=float(value.get("handshake_timeout_seconds", DEFAULT_HANDSHAKE_TIMEOUT_SECONDS)),
        frame_interval_seconds=float(value.get("frame_interval_seconds", DEFAULT_FRAME_INTERVAL_SECONDS)),
        retransmit_seconds=float(value.get("retransmit_seconds", DEFAULT_RETRANSMIT_SECONDS)),
        window_size=int(value.get("window_size", DEFAULT_WINDOW_SIZE)),
    )
    if min(
        settings.scan_interval_seconds, settings.file_stable_seconds,
        settings.handshake_timeout_seconds, settings.frame_interval_seconds,
        settings.retransmit_seconds, settings.window_size,
    ) <= 0:
        raise RuntimeError("all timing values and window_size must be positive")
    return settings


def load_password(base: Path) -> str:
    path = base / "key.txt"
    if not path.exists():
        raise RuntimeError(f"Missing key file: {path}\nCreate key.txt and enter the shared password.")
    password = path.read_text(encoding="utf-8").rstrip("\r\n")
    if not password:
        raise RuntimeError("key.txt must not be empty")
    return password


class InstanceLock:
    def __init__(self, path: Path):
        self.path = path
        self.stream = None

    def __enter__(self):
        import msvcrt
        self.stream = self.path.open("a+b")
        self.stream.seek(0, os.SEEK_END)
        if self.stream.tell() == 0:
            self.stream.write(b"0")
            self.stream.flush()
        self.stream.seek(0)
        try:
            msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            self.stream.close()
            raise RuntimeError("PixelDuplex is already running from this directory") from error
        return self

    def __exit__(self, *_args):
        import msvcrt
        if self.stream is not None:
            self.stream.seek(0)
            try:
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            finally:
                self.stream.close()


class Runner:
    def __init__(self, base: Path, settings: Settings, password: str, mode: str):
        self.base = base
        self.settings = settings
        self.password = password
        self.mode = mode
        self.status_path = base / "artifacts" / "reports" / "status.json"
        self.self_test_path = base / "artifacts" / "reports" / "self_test.json"
        self.ledger = Ledger(base / "pixelduplex-ledger.json", settings.role)
        self.link = LinkSession(settings.role, password)
        self.io = HdmiFrameIO(
            settings.capture_device, settings.monitor_device,
            settings.frame_interval_seconds,
        )
        self.engine = self._new_engine()
        self.diagnostic = DiagnosticSession(
            settings.role, window_size=settings.window_size,
            retransmit_seconds=settings.retransmit_seconds,
        )
        self.started = time.monotonic()
        self.ever_connected = False
        self.reconnecting = False
        self.last_valid_packet = self.started
        self.last_keepalive = float("-inf")
        self.last_status = float("-inf")
        self._seen_packet_order: deque[tuple] = deque()
        self._seen_packets: set[tuple] = set()
        self.self_test_payload: bytes | None = None
        self.self_test_started: float | None = None

    def _new_engine(self):
        return DuplexEngine(
            self.base / "target", self.base / "received", self.ledger,
            self.settings.role,
            window_size=self.settings.window_size,
            scan_interval=self.settings.scan_interval_seconds,
            stable_seconds=self.settings.file_stable_seconds,
            retransmit_seconds=self.settings.retransmit_seconds,
            session_id=self.link.session_id.hex(),
            report_path=self.base / "artifacts" / "reports" / "last_transfer.json",
        )

    def _status(self, state: str, reason: str = "") -> None:
        transfer = getattr(self.engine, "transfer", None)
        atomic_json(self.status_path, {
            "status": state,
            "reason": reason,
            "role": self.settings.role,
            "mode": self.mode,
            "connected": self.link.connected,
            "handshake_state": self.link.handshake.state,
            "session_id": self.link.session_id.hex(),
            "active_transfer": (
                getattr(getattr(transfer, "snapshot", None), "relative_path", None)
                or getattr(transfer, "relative_path", None)
            ),
            "active_transfer_direction": (
                self.engine.transfer_direction
            ),
            "sync_token_owner": self.engine.token_owner,
            "sync_token_epoch": self.engine.token_epoch,
            "authentication_failures": self.link.authentication_failures,
            "duplicate_secure_messages": self.link.duplicate_secure_messages,
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        })

    def _send_app(self, messages) -> None:
        for kind, payload in messages:
            self.io.send(self.link.secure(kind, payload))

    def _reset_link(self) -> None:
        self.engine.close()
        self.io.clear_outgoing()
        self.link = LinkSession(self.settings.role, self.password)
        self.engine = self._new_engine()
        self.diagnostic = DiagnosticSession(
            self.settings.role, window_size=self.settings.window_size,
            retransmit_seconds=self.settings.retransmit_seconds,
        )
        if self.mode == "self-test":
            self.self_test_payload = None
            self.self_test_started = None
        self.last_valid_packet = time.monotonic()
        self._seen_packet_order.clear()
        self._seen_packets.clear()
        self.reconnecting = True

    def _is_new_physical_packet(self, packet) -> bool:
        identity = (
            packet.session_id, packet.kind, packet.message_id,
            packet.fragment_index, packet.fragment_count,
        )
        if identity in self._seen_packets:
            return False
        self._seen_packets.add(identity)
        self._seen_packet_order.append(identity)
        while len(self._seen_packet_order) > 4096:
            self._seen_packets.discard(self._seen_packet_order.popleft())
        return True

    def run(self) -> int:
        try:
            self.io.start()
            self._status("CONNECTING")
            while self.io.pump_display():
                now = time.monotonic()
                self.io.send(self.link.periodic(now))
                for packet, _active_rect in self.io.receive():
                    if self._is_new_physical_packet(packet):
                        self.last_valid_packet = now
                    outgoing, messages = self.link.receive(packet)
                    self.io.send(outgoing)
                    for kind, payload in messages:
                        if kind == MessageKind.KEEPALIVE:
                            pass
                        elif self.diagnostic.handles(kind):
                            self._send_app(self.diagnostic.handle(kind, payload, now))
                        else:
                            self._send_app(self.engine.handle(kind, payload, now))
                if self.link.connected:
                    self.engine.update_session_id(self.link.session_id.hex())
                    if not self.ever_connected:
                        self.ever_connected = True
                        print(f"CONNECTED role={self.settings.role} session={self.link.session_id.hex()}", flush=True)
                    self.reconnecting = False
                    if now - self.last_keepalive >= 2.0:
                        self.last_keepalive = now
                        self._send_app([(MessageKind.KEEPALIVE, b"")])
                    if self.mode == "self-test" and self.settings.role == "receiver" and self.self_test_payload is None:
                        self.self_test_payload = os.urandom(180_000)
                        self.self_test_started = now
                        self._send_app(self.diagnostic.start(self.self_test_payload, now))
                    self._send_app(self.diagnostic.tick(now))
                    if self.mode != "self-test" and not self.diagnostic.active:
                        self._send_app(self.engine.tick(now))
                    if self.mode == "self-test" and self.diagnostic.finished:
                        elapsed = now - (self.self_test_started or now)
                        verified = self.diagnostic.result == self.self_test_payload
                        report = {
                            "status": "SUCCESS" if verified else "FAILURE",
                            "sha256_verified": verified,
                            "transport": "selective-repeat-blob",
                            "bytes_each_direction": len(self.diagnostic.result),
                            "round_trip_seconds": elapsed,
                            "round_trip_goodput_bytes_per_second": (
                                len(self.diagnostic.result) * 2 / elapsed if elapsed > 0 else None
                            ),
                            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                        }
                        atomic_json(self.self_test_path, report)
                        self._status(report["status"], "self-test passed" if verified else "self-test mismatch")
                        print(json.dumps(report, ensure_ascii=False), flush=True)
                        return 0 if verified else 4
                    if now - self.last_valid_packet >= 15.0:
                        print("RECONNECTING: no valid captured protocol frame for 15 seconds", flush=True)
                        self._reset_link()
                        self._status("RECONNECTING", "link silent")
                elif not self.ever_connected and now - self.started >= self.settings.handshake_timeout_seconds:
                    self._status("FAILURE", "startup connection timeout")
                    print("FAILURE: startup connection timeout", flush=True)
                    return 3
                if now - self.last_status >= 1.0:
                    self.last_status = now
                    state = "READY" if self.link.connected else (
                        "RECONNECTING" if self.reconnecting else "CONNECTING"
                    )
                    self._status(state)
                time.sleep(0.002)
            self._status("CANCELLED", "Escape pressed")
            return 130
        except KeyboardInterrupt:
            self._status("CANCELLED", "Ctrl+C")
            return 130
        finally:
            self.engine.close()
            self.io.close()


def run_command(base: Path, mode: str) -> int:
    settings = load_settings(base)
    if mode == "self-test" and settings.role != "receiver":
        raise RuntimeError("self-test must be started on the receiver; run sender normally")
    password = load_password(base)
    for directory in (base / "target", base / "received", base / "artifacts" / "logs", base / "artifacts" / "reports"):
        directory.mkdir(parents=True, exist_ok=True)
    with InstanceLock(base / ".pixelduplex.lock"):
        return Runner(base, settings, password, mode).run()


def print_status(base: Path) -> int:
    path = base / "artifacts" / "reports" / "status.json"
    if not path.exists():
        print(json.dumps({"status": "NOT_RUNNING", "reason": "no status report"}))
        return 1
    print(path.read_text(encoding="utf-8"), end="")
    return 0
