"""PixelDuplex physical frames using the proven 2x2 monochrome grid."""

from __future__ import annotations

import math
import struct
import zlib
from dataclasses import dataclass, field

try:
    import cv2
    import numpy as np
except ModuleNotFoundError as error:  # pragma: no cover - environment guard
    raise SystemExit(
        f"Missing dependency: {error.name}\n"
        "Install dependencies with:\n  python -m pip install -r requirements.txt"
    ) from error

from .constants import (
    CELL, CRC_BYTES, FRAME_BYTES, GRID_H, GRID_W, HEIGHT,
    PHYSICAL_HEADER_BYTES, PHYSICAL_PAYLOAD_BYTES, PROTOCOL_VERSION, WIDTH,
)


MAGIC = b"PXDLNK01"
HEADER = struct.Struct("<8sBBH16sQIIII")
WHITEN = np.resize(np.array([0xAA, 0x55], dtype=np.uint8), FRAME_BYTES)
FULL_RECT = (0, 0, WIDTH, HEIGHT)
SAMPLING_PHASES = ((0, 0), (0, 1), (1, 0), (1, 1))


@dataclass(frozen=True)
class PhysicalPacket:
    kind: int
    session_id: bytes
    message_id: int
    fragment_index: int
    fragment_count: int
    total_length: int
    payload: bytes


def encode_packet(packet: PhysicalPacket) -> bytes:
    if len(packet.session_id) != 16:
        raise ValueError("session_id must be 16 bytes")
    if not 0 <= packet.kind <= 255:
        raise ValueError("physical kind out of range")
    if not 0 <= packet.message_id < 1 << 64:
        raise ValueError("message_id out of range")
    if not 0 < packet.fragment_count <= 0xFFFFFFFF:
        raise ValueError("invalid fragment_count")
    if not 0 <= packet.fragment_index < packet.fragment_count:
        raise ValueError("invalid fragment_index")
    if len(packet.payload) > PHYSICAL_PAYLOAD_BYTES:
        raise ValueError("physical payload too large")
    header = HEADER.pack(
        MAGIC, PROTOCOL_VERSION, packet.kind, PHYSICAL_HEADER_BYTES,
        packet.session_id, packet.message_id, packet.fragment_index,
        packet.fragment_count, packet.total_length, len(packet.payload),
    )
    body = (
        header.ljust(PHYSICAL_HEADER_BYTES, b"\0")
        + packet.payload.ljust(PHYSICAL_PAYLOAD_BYTES, b"\0")
    )
    return body + struct.pack("<I", zlib.crc32(body))


def decode_packet(raw: bytes) -> PhysicalPacket | None:
    if len(raw) != FRAME_BYTES:
        return None
    body, checksum = raw[:-CRC_BYTES], raw[-CRC_BYTES:]
    if zlib.crc32(body) != struct.unpack("<I", checksum)[0]:
        return None
    fields = HEADER.unpack_from(body)
    (magic, version, kind, header_size, session_id, message_id,
     fragment_index, fragment_count, total_length, payload_length) = fields
    if magic != MAGIC or version != PROTOCOL_VERSION:
        return None
    if header_size != PHYSICAL_HEADER_BYTES:
        return None
    if not fragment_count or fragment_index >= fragment_count:
        return None
    if payload_length > PHYSICAL_PAYLOAD_BYTES:
        return None
    if total_length > fragment_count * PHYSICAL_PAYLOAD_BYTES:
        return None
    if total_length <= (fragment_count - 1) * PHYSICAL_PAYLOAD_BYTES:
        return None
    payload = body[PHYSICAL_HEADER_BYTES:PHYSICAL_HEADER_BYTES + payload_length]
    return PhysicalPacket(
        kind, session_id, message_id, fragment_index, fragment_count,
        total_length, payload,
    )


def fragment_message(kind: int, session_id: bytes, message_id: int,
                     payload: bytes) -> list[PhysicalPacket]:
    count = max(1, math.ceil(len(payload) / PHYSICAL_PAYLOAD_BYTES))
    return [
        PhysicalPacket(
            kind, session_id, message_id, index, count, len(payload),
            payload[index * PHYSICAL_PAYLOAD_BYTES:(index + 1) * PHYSICAL_PAYLOAD_BYTES],
        )
        for index in range(count)
    ]


def packet_image(packet: PhysicalPacket):
    encoded = np.frombuffer(encode_packet(packet), dtype=np.uint8) ^ WHITEN
    bits = np.unpackbits(encoded, bitorder="big").reshape(GRID_H, GRID_W)
    mono = np.repeat(np.repeat(bits, CELL, axis=0), CELL, axis=1) * 255
    return cv2.cvtColor(mono.astype(np.uint8), cv2.COLOR_GRAY2BGR)


def sample_grid(frame, x_offset: int = 0, y_offset: int = 0):
    return frame[y_offset::CELL, x_offset::CELL, 0][:GRID_H, :GRID_W] >= 128


def grid_to_bytes(grid) -> bytes:
    packed = np.packbits(grid.astype(np.uint8).reshape(-1), bitorder="big")
    return (packed ^ WHITEN).tobytes()


def normalize_active_image(frame):
    mono = frame[:, :, 0]
    white = mono >= 128
    columns = np.flatnonzero(white.sum(axis=0) > HEIGHT * 0.10)
    rows = np.flatnonzero(white.sum(axis=1) > WIDTH * 0.10)
    if not columns.size or not rows.size:
        return None, None
    left, right = int(columns[0]), int(columns[-1] + 1)
    top, bottom = int(rows[0]), int(rows[-1] + 1)
    width, height = right - left, bottom - top
    if width < WIDTH * 0.80 or height < HEIGHT * 0.80:
        return None, None
    if abs(width / height - WIDTH / HEIGHT) > 0.02:
        return None, None
    restored = cv2.resize(
        frame[top:bottom, left:right], (WIDTH, HEIGHT),
        interpolation=cv2.INTER_LINEAR,
    )
    return restored, (left, top, right, bottom)


def _decode_grid_phases(frame) -> PhysicalPacket | None:
    for y_offset, x_offset in SAMPLING_PHASES:
        raw = grid_to_bytes(sample_grid(frame, x_offset, y_offset))
        packet = decode_packet(raw)
        if packet is not None:
            return packet
    return None


def decode_image(frame) -> tuple[PhysicalPacket | None, tuple[int, int, int, int] | None]:
    if getattr(frame, "shape", ())[:2] != (HEIGHT, WIDTH):
        return None, None
    decoded = _decode_grid_phases(frame)
    if decoded is not None:
        return decoded, FULL_RECT
    normalized, rect = normalize_active_image(frame)
    if normalized is None:
        return None, None
    decoded = _decode_grid_phases(normalized)
    return (decoded, rect) if decoded is not None else (None, None)


@dataclass
class FragmentAssembler:
    """Reassemble fragmented physical messages and discard bounded stale state."""

    max_messages: int = 64
    _parts: dict[tuple[bytes, int, int], dict[int, bytes]] = field(default_factory=dict)
    _meta: dict[tuple[bytes, int, int], tuple[int, int]] = field(default_factory=dict)

    def add(self, packet: PhysicalPacket) -> bytes | None:
        key = (packet.session_id, packet.kind, packet.message_id)
        meta = (packet.fragment_count, packet.total_length)
        if key in self._meta and self._meta[key] != meta:
            self._parts.pop(key, None)
            self._meta.pop(key, None)
            return None
        if key not in self._parts and len(self._parts) >= self.max_messages:
            oldest = next(iter(self._parts))
            self._parts.pop(oldest, None)
            self._meta.pop(oldest, None)
        self._meta[key] = meta
        self._parts.setdefault(key, {})[packet.fragment_index] = packet.payload
        parts = self._parts[key]
        if len(parts) != packet.fragment_count:
            return None
        try:
            result = b"".join(parts[index] for index in range(packet.fragment_count))
        except KeyError:
            return None
        self._parts.pop(key, None)
        self._meta.pop(key, None)
        if len(result) != packet.total_length:
            return None
        return result
