"""Small authenticated startup handshake for the bidirectional link."""

from __future__ import annotations

import hmac
import os
import struct
from dataclasses import dataclass

from .constants import MessageKind, PhysicalKind, PROTOCOL_VERSION
from .crypto import (
    CHALLENGE_BYTES, PROOF_BYTES, SALT_BYTES, SecureChannel, derive_root_key,
    receiver_proof, sender_proof,
)


BEACON = struct.Struct("<BB16s16s16s")  # protocol, role, session, salt, challenge
AUTH = struct.Struct("<16s32s")
ROLE_ID = {"sender": 1, "receiver": 2}
EMPTY_SESSION_ID = b"\0" * 16
EMPTY_CHALLENGE = b"\0" * CHALLENGE_BYTES
PING_PAYLOAD = b"PixelDuplex-v4"


class HandshakeError(RuntimeError):
    pass


@dataclass(frozen=True)
class OutgoingHandshake:
    physical_kind: int
    session_id: bytes
    payload: bytes


class Handshake:
    def __init__(self, role: str, password: str):
        if role not in ROLE_ID:
            raise ValueError("role must be sender or receiver")
        self.role = role
        self.password = password
        self.state = "CONNECTING"
        self.channel: SecureChannel | None = None
        self.session_id = os.urandom(16) if role == "receiver" else EMPTY_SESSION_ID
        self.salt = os.urandom(SALT_BYTES) if role == "receiver" else b"\0" * SALT_BYTES
        self.receiver_challenge = (
            os.urandom(CHALLENGE_BYTES) if role == "receiver" else EMPTY_CHALLENGE
        )
        self.sender_challenge = EMPTY_CHALLENGE
        self.root_key: bytes | None = None

    @property
    def connected(self) -> bool:
        return self.state == "CONNECTED"

    def beacon(self) -> OutgoingHandshake:
        payload = BEACON.pack(
            PROTOCOL_VERSION, ROLE_ID[self.role], self.session_id, self.salt,
            self.receiver_challenge,
        )
        return OutgoingHandshake(PhysicalKind.BEACON, self.session_id, payload)

    def receive_plain(self, kind: int, session_id: bytes, payload: bytes) -> OutgoingHandshake | None:
        if kind == PhysicalKind.BEACON:
            return self._receive_beacon(payload)
        if self.role == "receiver" and kind == PhysicalKind.AUTH:
            return self._receive_auth(session_id, payload)
        if self.role == "sender" and kind == PhysicalKind.READY:
            return self._receive_ready(session_id, payload)
        return None

    def _receive_beacon(self, payload: bytes) -> OutgoingHandshake | None:
        if len(payload) != BEACON.size:
            return None
        version, remote_role, session, salt, challenge = BEACON.unpack(payload)
        if version != PROTOCOL_VERSION:
            raise HandshakeError("protocol version mismatch")
        if remote_role == ROLE_ID[self.role]:
            raise HandshakeError(f"both endpoints are configured as {self.role}")
        if self.role == "receiver":
            return self.beacon()
        if remote_role != ROLE_ID["receiver"]:
            return None
        self.session_id, self.salt, self.receiver_challenge = session, salt, challenge
        self.root_key = derive_root_key(self.password, self.salt)
        if self.sender_challenge == EMPTY_CHALLENGE:
            self.sender_challenge = os.urandom(CHALLENGE_BYTES)
        proof = sender_proof(
            self.root_key, self.session_id, self.receiver_challenge,
            self.sender_challenge,
        )
        self.state = "WAIT_READY"
        return OutgoingHandshake(
            PhysicalKind.AUTH, self.session_id,
            AUTH.pack(self.sender_challenge, proof),
        )

    def _receive_auth(self, session_id: bytes, payload: bytes) -> OutgoingHandshake | None:
        if session_id != self.session_id or len(payload) != AUTH.size:
            return None
        challenge, proof = AUTH.unpack(payload)
        root = derive_root_key(self.password, self.salt)
        expected = sender_proof(root, self.session_id, self.receiver_challenge, challenge)
        if not hmac.compare_digest(proof, expected):
            raise HandshakeError("AUTHENTICATION_FAILED: key mismatch or damaged link")
        self.root_key, self.sender_challenge = root, challenge
        if self.channel is None:
            self.channel = SecureChannel.create("receiver", root, self.session_id)
            self.state = "WAIT_PING"
        proof = receiver_proof(root, self.session_id, self.receiver_challenge, challenge)
        return OutgoingHandshake(PhysicalKind.READY, self.session_id, proof)

    def _receive_ready(self, session_id: bytes, payload: bytes) -> None:
        if session_id != self.session_id or len(payload) != PROOF_BYTES or self.root_key is None:
            return None
        expected = receiver_proof(
            self.root_key, self.session_id, self.receiver_challenge,
            self.sender_challenge,
        )
        if not hmac.compare_digest(payload, expected):
            raise HandshakeError("AUTHENTICATION_FAILED: key mismatch or damaged link")
        if self.channel is None:
            self.channel = SecureChannel.create("sender", self.root_key, self.session_id)
            self.state = "WAIT_PONG"
        return None

    def secure_probe(self) -> tuple[int, bytes] | None:
        if self.role == "sender" and self.state == "WAIT_PONG":
            return MessageKind.PING, PING_PAYLOAD
        return None

    def receive_secure(self, kind: int, payload: bytes) -> tuple[int, bytes] | None:
        if self.role == "receiver" and kind == MessageKind.PING and self.state in {"WAIT_PING", "CONNECTED"}:
            self.state = "CONNECTED"
            return MessageKind.PONG, payload
        if self.role == "sender" and kind == MessageKind.PONG and self.state == "WAIT_PONG":
            if payload != PING_PAYLOAD:
                raise HandshakeError("invalid encrypted handshake response")
            self.state = "CONNECTED"
        return None
