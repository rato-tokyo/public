"""Filesystem boundary and file-integrity helpers."""

from __future__ import annotations

import hashlib
import os
import stat
import time
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from .constants import FILE_CHUNK_BYTES


WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalized_relative(root: Path, path: Path) -> str:
    relative = path.relative_to(root)
    return PurePosixPath(*relative.parts).as_posix()


def is_regular_without_reparse(path: Path) -> bool:
    try:
        info = path.lstat()
    except OSError:
        return False
    if path.is_symlink() or not stat.S_ISREG(info.st_mode):
        return False
    reparse = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    attributes = getattr(info, "st_file_attributes", 0)
    return not bool(attributes & reparse)


def scan_regular_files(root: Path) -> list[Path]:
    root.mkdir(parents=True, exist_ok=True)
    result: list[Path] = []
    for directory, directory_names, filenames in os.walk(root, followlinks=False):
        base = Path(directory)
        directory_names[:] = [
            name for name in directory_names
            if not (base / name).is_symlink()
            and not bool(getattr((base / name).lstat(), "st_file_attributes", 0) & 0x400)
        ]
        for name in filenames:
            candidate = base / name
            if is_regular_without_reparse(candidate):
                result.append(candidate)
    return sorted(result, key=lambda path: normalized_relative(root, path).casefold())


@dataclass(frozen=True)
class FileSnapshot:
    relative_path: str
    size: int
    mtime_ns: int
    sha256: str


def snapshot_file(root: Path, path: Path) -> FileSnapshot:
    before = path.stat()
    digest = sha256_file(path)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise RuntimeError(f"file changed while hashing: {path}")
    return FileSnapshot(
        normalized_relative(root, path), after.st_size, after.st_mtime_ns, digest,
    )


class StabilityTracker:
    def __init__(self, stable_seconds: float):
        self.stable_seconds = stable_seconds
        self._seen: dict[str, tuple[int, int, float]] = {}

    def observe(self, relative_path: str, size: int, mtime_ns: int,
                now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        previous = self._seen.get(relative_path)
        if previous is None or previous[:2] != (size, mtime_ns):
            self._seen[relative_path] = (size, mtime_ns, now)
            return False
        return now - previous[2] >= self.stable_seconds


def validate_relative_path(value: str) -> PurePosixPath:
    if not value or "\\" in value or "\0" in value:
        raise ValueError("invalid relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError("path must be a normalized relative path")
    for part in path.parts:
        stem = part.rstrip(" .").split(".", 1)[0].upper()
        if stem in WINDOWS_RESERVED or part.endswith((" ", ".")):
            raise ValueError("path contains a Windows-reserved component")
        if any(character in '<>:"|?*' for character in part):
            raise ValueError("path contains a Windows-invalid character")
    return path


def safe_output_path(root: Path, relative_path: str) -> Path:
    relative = validate_relative_path(relative_path)
    root_resolved = root.resolve()
    current = root_resolved
    for part in relative.parts[:-1]:
        current = current / part
        if current.exists() and (current.is_symlink() or not current.is_dir()):
            raise ValueError("output parent is not a safe directory")
    output = root_resolved.joinpath(*relative.parts)
    if output.exists() and output.is_symlink():
        raise ValueError("output path is a symbolic link")
    if os.path.commonpath([str(root_resolved), str(output.resolve(strict=False))]) != str(root_resolved):
        raise ValueError("output path escapes received directory")
    return output


def file_chunks(path: Path, chunk_bytes: int = FILE_CHUNK_BYTES):
    with path.open("rb") as stream:
        index = 0
        while True:
            block = stream.read(chunk_bytes)
            if not block:
                break
            yield index, block
            index += 1
        if index == 0:
            yield 0, b""


class AtomicReceiver:
    """Random-access .part writer published only after size and SHA-256 match."""

    def __init__(self, destination: Path, expected_size: int, expected_sha256: str,
                 chunk_count: int, chunk_bytes: int = FILE_CHUNK_BYTES):
        self.destination = destination
        self.part = destination.with_name(destination.name + ".part")
        self.expected_size = expected_size
        self.expected_sha256 = expected_sha256
        self.chunk_count = chunk_count
        self.chunk_bytes = chunk_bytes
        self.received: set[int] = set()
        destination.parent.mkdir(parents=True, exist_ok=True)
        self._stream = self.part.open("w+b")
        self._stream.truncate(expected_size)

    def write(self, index: int, payload: bytes) -> bool:
        if not 0 <= index < self.chunk_count:
            raise ValueError("chunk index out of range")
        expected = self.chunk_bytes
        if index == self.chunk_count - 1:
            expected = self.expected_size - self.chunk_bytes * (self.chunk_count - 1)
        if len(payload) != expected:
            raise ValueError("chunk length does not match metadata")
        if index in self.received:
            self._stream.seek(index * self.chunk_bytes)
            if self._stream.read(len(payload)) != payload:
                raise ValueError("duplicate chunk has different bytes")
            return False
        self._stream.seek(index * self.chunk_bytes)
        self._stream.write(payload)
        self.received.add(index)
        return True

    def complete(self) -> bool:
        return len(self.received) == self.chunk_count

    def publish(self) -> None:
        if not self.complete():
            raise RuntimeError("cannot publish incomplete file")
        self._stream.flush()
        os.fsync(self._stream.fileno())
        self._stream.close()
        if self.part.stat().st_size != self.expected_size:
            self.part.unlink(missing_ok=True)
            raise RuntimeError("received size mismatch")
        if sha256_file(self.part) != self.expected_sha256:
            self.part.unlink(missing_ok=True)
            raise RuntimeError("received SHA-256 mismatch")
        if self.destination.exists():
            self.part.unlink(missing_ok=True)
            raise FileExistsError("destination appeared during transfer")
        os.replace(self.part, self.destination)

    def abort(self) -> None:
        if not self._stream.closed:
            self._stream.close()
        self.part.unlink(missing_ok=True)
