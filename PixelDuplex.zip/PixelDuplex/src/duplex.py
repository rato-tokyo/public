"""Bidirectional file-sync composition and single-transfer arbitration."""

from __future__ import annotations

from pathlib import Path

from .constants import (
    DEFAULT_RETRANSMIT_SECONDS, DEFAULT_SCAN_INTERVAL_SECONDS,
    DEFAULT_STABLE_SECONDS, DEFAULT_WINDOW_SIZE, MessageKind,
)
from .ledger import Ledger
from .messages import json_bytes, parse_json
from .sync import AppMessage, ReceiverEngine, SenderEngine


class DuplexEngine:
    """Run outbound and inbound engines under one authenticated receive token."""

    def __init__(self, target: Path, received: Path, ledger: Ledger, role: str, *,
                 window_size: int = DEFAULT_WINDOW_SIZE,
                 scan_interval: float = DEFAULT_SCAN_INTERVAL_SECONDS,
                 stable_seconds: float = DEFAULT_STABLE_SECONDS,
                 retransmit_seconds: float = DEFAULT_RETRANSMIT_SECONDS,
                 session_id: str = "local", report_path: Path | None = None):
        if role not in {"sender", "receiver"}:
            raise ValueError("role must be sender or receiver")
        self.role = role
        self.peer_role = "receiver" if role == "sender" else "sender"
        self.outbound = SenderEngine(
            target, ledger.scope("outgoing"), window_size=window_size,
            scan_interval=scan_interval, stable_seconds=stable_seconds,
            retransmit_seconds=retransmit_seconds,
        )
        self.inbound = ReceiverEngine(
            received, ledger.scope("incoming"), session_id=session_id,
            report_path=report_path,
        )
        self.token_epoch = 0
        self.token_owner = "receiver"
        self.last_token_sent = float("-inf")
        self.idle_since: float | None = None
        self.scan_interval = scan_interval

    @property
    def transfer(self):
        return self.inbound.transfer or self.outbound.transfer

    @property
    def transfer_direction(self) -> str | None:
        if self.inbound.transfer is not None:
            return "incoming"
        if self.outbound.transfer is not None:
            return "outgoing"
        return None

    def close(self) -> None:
        self.outbound.close()
        self.inbound.close()

    def update_session_id(self, session_id: str) -> None:
        self.inbound.session_id = session_id

    def _token_message(self) -> AppMessage:
        return MessageKind.SYNC_TOKEN, json_bytes({
            "epoch": self.token_epoch, "owner": self.token_owner,
        })

    def _receive_idle(self) -> bool:
        return (
            self.inbound.manifest_received
            and not self.inbound.pending
            and self.inbound.transfer is None
            and self.inbound.completed_message is None
        )

    def handle(self, kind: int, payload: bytes, now: float) -> list[AppMessage]:
        if kind == MessageKind.SYNC_TOKEN:
            return self._handle_token(payload)
        if kind in {
            MessageKind.MANIFEST_REQUEST, MessageKind.FILE_REQUEST,
            MessageKind.FILE_ACK, MessageKind.FILE_COMPLETE,
            MessageKind.ALREADY_COMPLETE,
        }:
            return self.outbound.handle(kind, payload, now)
        return self.inbound.handle(kind, payload, now)

    def _handle_token(self, payload: bytes) -> list[AppMessage]:
        value = parse_json(payload)
        epoch, owner = value.get("epoch"), value.get("owner")
        if not isinstance(epoch, int) or owner not in {"sender", "receiver"}:
            return []
        if epoch < self.token_epoch:
            return [self._token_message()]
        if epoch == self.token_epoch:
            return [] if owner == self.token_owner else [self._token_message()]
        self.token_epoch, self.token_owner = epoch, owner
        self.idle_since = None
        if owner == self.role:
            self.inbound.manifest_received = False
            self.inbound.last_request = float("-inf")
        return [self._token_message()]

    def tick(self, now: float) -> list[AppMessage]:
        outgoing = self.outbound.tick(now)
        if self.token_owner == self.role:
            outgoing.extend(self.inbound.tick(now))
            if self._receive_idle():
                if self.idle_since is None:
                    self.idle_since = now
                elif now - self.idle_since >= max(1.0, self.scan_interval):
                    self.token_epoch += 1
                    self.token_owner = self.peer_role
                    self.last_token_sent = now
                    self.idle_since = None
                    outgoing.append(self._token_message())
            else:
                self.idle_since = None
        if now - self.last_token_sent >= 1.0:
            self.last_token_sent = now
            outgoing.append(self._token_message())
        return outgoing
