from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from src.constants import FILE_CHUNK_BYTES, MessageKind, PhysicalKind
from src.app import InstanceLock, load_password, load_settings
from src.crypto import (
    AuthenticationError, SecureChannel, derive_root_key, receiver_proof,
    sender_proof,
)
from src.diagnostic import DiagnosticSession
from src.duplex import DuplexEngine
from src.files import (
    AtomicReceiver, StabilityTracker, safe_output_path, scan_regular_files,
    sha256_file,
)
from src.ledger import Ledger, LedgerError
from src.link import LinkSession
from src.messages import decode_data
from src.reliable import SelectiveRepeatReceiver, SelectiveRepeatSender
from src.sync import ReceiverEngine, SenderEngine
from src.wire import (
    FragmentAssembler, PhysicalPacket, decode_image, decode_packet,
    encode_packet, fragment_message, packet_image,
)


class WireTests(unittest.TestCase):
    def test_packet_round_trip_and_crc_rejection(self):
        packet = PhysicalPacket(PhysicalKind.SECURE, b"s" * 16, 42, 0, 1, 5, b"hello")
        raw = encode_packet(packet)
        self.assertEqual(decode_packet(raw), packet)
        damaged = bytearray(raw)
        damaged[100] ^= 1
        self.assertIsNone(decode_packet(bytes(damaged)))

    def test_image_round_trip_and_underscan(self):
        packet = PhysicalPacket(PhysicalKind.SECURE, b"i" * 16, 7, 0, 1, 4, b"data")
        image = packet_image(packet)
        decoded, rect = decode_image(image)
        self.assertEqual(decoded, packet)
        self.assertEqual(rect, (0, 0, 1920, 1080))

        active = cv2.resize(image, (1728, 972), interpolation=cv2.INTER_LINEAR)
        underscanned = np.zeros_like(image)
        underscanned[54:1026, 96:1824] = active
        decoded, rect = decode_image(underscanned)
        self.assertEqual(decoded, packet)
        self.assertIsNotNone(rect)

    def test_fragment_assembly_out_of_order_and_duplicate(self):
        payload = os.urandom(150_000)
        packets = fragment_message(PhysicalKind.SECURE, b"f" * 16, 9, payload)
        assembler = FragmentAssembler()
        self.assertIsNone(assembler.add(packets[1]))
        self.assertIsNone(assembler.add(packets[1]))
        self.assertIsNone(assembler.add(packets[0]))
        self.assertEqual(assembler.add(packets[2]), payload)


class CryptoTests(unittest.TestCase):
    def setUp(self):
        self.session = b"x" * 16
        self.root = derive_root_key("correct horse battery staple", b"z" * 16)

    def test_proofs_and_directional_encryption(self):
        rc, sc = b"r" * 16, b"s" * 16
        self.assertNotEqual(
            sender_proof(self.root, self.session, rc, sc),
            receiver_proof(self.root, self.session, rc, sc),
        )
        sender = SecureChannel.create("sender", self.root, self.session)
        receiver = SecureChannel.create("receiver", self.root, self.session)
        envelope = sender.seal(8, b"secret")
        self.assertEqual(receiver.open(envelope), (8, b"secret"))
        response = receiver.seal(9, b"ack")
        self.assertEqual(sender.open(response), (9, b"ack"))

    def test_tamper_wrong_key_and_replay_are_rejected(self):
        sender = SecureChannel.create("sender", self.root, self.session)
        envelope = sender.seal(1, b"payload")
        damaged = bytearray(envelope)
        damaged[-1] ^= 1
        receiver = SecureChannel.create("receiver", self.root, self.session)
        with self.assertRaises(AuthenticationError):
            receiver.open(bytes(damaged))
        wrong = SecureChannel.create(
            "receiver", derive_root_key("wrong", b"z" * 16), self.session,
        )
        with self.assertRaises(AuthenticationError):
            wrong.open(envelope)
        self.assertEqual(receiver.open(envelope), (1, b"payload"))
        with self.assertRaises(AuthenticationError):
            receiver.open(envelope)

    def test_out_of_order_messages_within_replay_window(self):
        sender = SecureChannel.create("sender", self.root, self.session)
        receiver = SecureChannel.create("receiver", self.root, self.session)
        first = sender.seal(1, b"first")
        second = sender.seal(1, b"second")
        self.assertEqual(receiver.open(second)[1], b"second")
        self.assertEqual(receiver.open(first)[1], b"first")


class SelectiveRepeatTests(unittest.TestCase):
    def test_loss_duplicate_and_reordering(self):
        sender = SelectiveRepeatSender(25, window_size=5, retransmit_seconds=1.0)
        receiver = SelectiveRepeatReceiver(25)
        now = 0.0
        deliberately_lost = {2, 7, 13}
        while not sender.done:
            for transmission in sender.due(now):
                if transmission.index in deliberately_lost and transmission.attempts == 1:
                    continue
                receiver.accept(transmission.index)
                receiver.accept(transmission.index)
            base, bitmap = receiver.ack()
            sender.acknowledge(base, bitmap)
            now += 1.1
            self.assertLess(now, 100)
        self.assertTrue(receiver.done)
        self.assertTrue(all(sender.attempts[index] == 2 for index in deliberately_lost))

    def test_diagnostic_blob_round_trip_retransmits_loss(self):
        payload = os.urandom(FILE_CHUNK_BYTES * 2 + 123)
        initiator = DiagnosticSession("receiver", window_size=3, retransmit_seconds=0.2)
        responder = DiagnosticSession("sender", window_size=3, retransmit_seconds=0.2)
        to_responder = list(initiator.start(payload, 0.0))
        to_initiator = []
        dropped: set[bytes] = set()
        dropped_complete_ack = False
        for step in range(500):
            now = step * 0.05
            to_responder.extend(initiator.tick(now))
            to_initiator.extend(responder.tick(now))
            while to_responder:
                kind, body = to_responder.pop(0)
                if kind == MessageKind.BLOB_DATA:
                    transfer_id, index, _data = decode_data(body)
                    marker = transfer_id + index.to_bytes(4, "little")
                    if index == 1 and marker not in dropped:
                        dropped.add(marker)
                        continue
                if kind == MessageKind.BLOB_COMPLETE_ACK and not dropped_complete_ack:
                    dropped_complete_ack = True
                    continue
                to_initiator.extend(responder.handle(kind, body, now))
            while to_initiator:
                kind, body = to_initiator.pop(0)
                if kind == MessageKind.BLOB_DATA:
                    transfer_id, index, _data = decode_data(body)
                    marker = transfer_id + index.to_bytes(4, "little")
                    if index == 1 and marker not in dropped:
                        dropped.add(marker)
                        continue
                to_responder.extend(initiator.handle(kind, body, now))
            if initiator.finished:
                break
        self.assertTrue(initiator.finished)
        self.assertEqual(initiator.result, payload)
        self.assertEqual(len(dropped), 2)
        self.assertTrue(dropped_complete_ack)


class LinkTests(unittest.TestCase):
    def test_handshake_and_secure_bidirectional_messages(self):
        sender = LinkSession("sender", "shared password")
        receiver = LinkSession("receiver", "shared password")
        to_sender = []
        to_receiver = []
        for step in range(30):
            now = step * 0.6
            to_receiver.extend(sender.periodic(now))
            to_sender.extend(receiver.periodic(now))
            while to_sender:
                outgoing, _messages = sender.receive(to_sender.pop(0))
                to_receiver.extend(outgoing)
            while to_receiver:
                outgoing, _messages = receiver.receive(to_receiver.pop(0))
                to_sender.extend(outgoing)
            if sender.connected and receiver.connected:
                break
        self.assertTrue(sender.connected)
        self.assertTrue(receiver.connected)

        packets = sender.secure(MessageKind.KEEPALIVE, b"hello")
        delivered = []
        for packet in reversed(packets):
            outgoing, messages = receiver.receive(packet)
            self.assertFalse(outgoing)
            delivered.extend(messages)
        self.assertEqual(delivered, [(MessageKind.KEEPALIVE, b"hello")])

    def test_same_roles_are_rejected(self):
        first = LinkSession("sender", "password")
        second = LinkSession("sender", "password")
        with self.assertRaisesRegex(RuntimeError, "both endpoints"):
            first.receive(second.periodic(0.0)[0])


class FilesAndLedgerTests(unittest.TestCase):
    def test_instance_lock_file_does_not_grow(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / ".lock"
            with InstanceLock(path):
                pass
            with InstanceLock(path):
                pass
            self.assertEqual(path.stat().st_size, 1)

    def test_config_and_key_are_resolved_from_supplied_base(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            (base / "config.json").write_text(
                json.dumps({"role": "receiver", "capture_device": 4}),
                encoding="utf-8",
            )
            (base / "key.txt").write_text(" secret with spaces \r\n", encoding="utf-8")
            settings = load_settings(base)
            self.assertEqual(settings.role, "receiver")
            self.assertEqual(settings.capture_device, 4)
            self.assertEqual(load_password(base), " secret with spaces ")

    def test_stability_tracker(self):
        tracker = StabilityTracker(10.0)
        self.assertFalse(tracker.observe("a.bin", 1, 1, 0.0))
        self.assertFalse(tracker.observe("a.bin", 1, 1, 9.9))
        self.assertTrue(tracker.observe("a.bin", 1, 1, 10.0))
        self.assertFalse(tracker.observe("a.bin", 2, 2, 11.0))

    def test_safe_paths(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertEqual(
                safe_output_path(root, "sub/file.bin"),
                root.resolve() / "sub" / "file.bin",
            )
            for invalid in ("../escape", "/absolute", "C:/drive", "bad\\name", "CON/file"):
                with self.assertRaises(ValueError, msg=invalid):
                    safe_output_path(root, invalid)

    def test_scan_regular_ignores_symlink(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "normal.txt").write_text("ok", encoding="utf-8")
            try:
                (root / "link.txt").symlink_to(root / "normal.txt")
            except OSError:
                pass
            names = [path.name for path in scan_regular_files(root)]
            self.assertIn("normal.txt", names)
            self.assertNotIn("link.txt", names)

    def test_atomic_receiver_and_hash(self):
        data = os.urandom(FILE_CHUNK_BYTES * 2 + 123)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "source.bin"
            source.write_bytes(data)
            destination = root / "out" / "file.bin"
            receiver = AtomicReceiver(destination, len(data), sha256_file(source), 3)
            receiver.write(2, data[FILE_CHUNK_BYTES * 2:])
            receiver.write(0, data[:FILE_CHUNK_BYTES])
            receiver.write(1, data[FILE_CHUNK_BYTES:FILE_CHUNK_BYTES * 2])
            receiver.publish()
            self.assertEqual(destination.read_bytes(), data)
            self.assertFalse(destination.with_name("file.bin.part").exists())

    def test_ledger_atomic_and_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ledger.json"
            ledger = Ledger(path, "sender")
            ledger.record("a.bin", status="SUCCESS", size=3, sha256="abc")
            self.assertTrue(Ledger(path, "sender").is_complete("a.bin"))
            value = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(value["version"], 2)
            self.assertIn("outgoing", value)
            self.assertIn("incoming", value)
            path.write_text("{broken", encoding="utf-8")
            with self.assertRaises(LedgerError):
                Ledger(path, "sender")

    def test_ledger_keeps_same_path_independent_by_direction(self):
        with tempfile.TemporaryDirectory() as directory:
            ledger = Ledger(Path(directory) / "ledger.json", "sender")
            ledger.scope("outgoing").record(
                "same.bin", status="SUCCESS", size=3, sha256="outgoing",
            )
            ledger.scope("incoming").record(
                "same.bin", status="CONFLICT", size=4, sha256="incoming",
            )
            self.assertTrue(ledger.is_complete("same.bin", "outgoing"))
            self.assertFalse(ledger.is_complete("same.bin", "incoming"))
            self.assertEqual(ledger.get("same.bin", "outgoing")["sha256"], "outgoing")
            self.assertEqual(ledger.get("same.bin", "incoming")["sha256"], "incoming")

    def test_v1_ledger_is_backed_up_and_migrated_by_role(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ledger.json"
            path.write_text(json.dumps({
                "version": 1, "role": "sender",
                "files": {"done.bin": {"status": "SUCCESS", "sha256": "abc"}},
            }), encoding="utf-8")
            ledger = Ledger(path, "sender")
            self.assertTrue(ledger.is_complete("done.bin", "outgoing"))
            self.assertFalse(ledger.is_complete("done.bin", "incoming"))
            self.assertTrue(path.with_name("ledger.json.v1.bak").exists())
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["version"], 2)


class EndToEndSyncTests(unittest.TestCase):
    def test_receiver_driven_encrypted_payload_logic_with_loss(self):
        data = os.urandom(FILE_CHUNK_BYTES * 3 + 777)
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            target = base / "sender" / "target"
            received = base / "receiver" / "received"
            target.mkdir(parents=True)
            (target / "nested").mkdir()
            source = target / "nested" / "payload.bin"
            source.write_bytes(data)
            sender = SenderEngine(
                target, Ledger(base / "sender" / "ledger.json", "sender"),
                scan_interval=1.0, stable_seconds=2.0, retransmit_seconds=0.5,
            )
            receiver = ReceiverEngine(
                received, Ledger(base / "receiver" / "ledger.json", "receiver"),
                session_id="test-session",
            )

            try:
                # Initial manifest may be empty while the file is still in its
                # mandatory stability window. The later announcement drives sync.
                for kind, payload in receiver.tick(0.0):
                    for reply in sender.handle(kind, payload, 0.0):
                        receiver.handle(*reply, 0.0)
                sender.tick(0.0)
                sender.tick(1.0)
                for message in sender.tick(2.0):
                    receiver.handle(*message, 2.0)

                request = receiver.tick(2.1)
                self.assertEqual(request[0][0], MessageKind.FILE_REQUEST)
                first_meta = sender.handle(*request[0], 2.1)
                self.assertEqual(first_meta[0][0], MessageKind.FILE_META)
                # Drop the first metadata response. A repeated request must
                # reproduce it without creating a second transfer.
                repeated_request = receiver.tick(3.2)
                meta = sender.handle(*repeated_request[0], 3.2)
                self.assertEqual(meta[0], first_meta[0])
                ack = receiver.handle(*meta[0], 3.2)
                sender.handle(*ack[0], 3.2)

                lost_once = {1, 3}
                lost = set()
                now = 2.1
                for _ in range(100):
                    now += 0.25
                    outbound = sender.tick(now)
                    responses = []
                    for kind, payload in reversed(outbound):
                        if kind == MessageKind.FILE_DATA:
                            _tid, index, _data = decode_data(payload)
                            if index in lost_once and index not in lost:
                                lost.add(index)
                                continue
                        responses.extend(receiver.handle(kind, payload, now))
                    for response in responses:
                        # Deliberately drop the first completion confirmation.
                        sender.handle(*response, now)
                    for completion in receiver.tick(now):
                        for confirm in sender.handle(*completion, now):
                            receiver.handle(*confirm, now)
                    if (
                        (received / "nested" / "payload.bin").exists()
                        and sender.transfer is None and receiver.transfer is None
                    ):
                        break
                self.assertEqual((received / "nested" / "payload.bin").read_bytes(), data)
                self.assertTrue(sender.ledger.is_complete("nested/payload.bin"))
                self.assertTrue(receiver.ledger.is_complete("nested/payload.bin"))
                self.assertEqual(lost, lost_once)
            finally:
                sender.close()
                receiver.close()

    def test_completed_path_is_not_sendable_after_content_replacement(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            target = base / "target"
            target.mkdir()
            path = target / "same.txt"
            path.write_text("old", encoding="utf-8")
            ledger = Ledger(base / "ledger.json", "sender")
            ledger.record("same.txt", status="SUCCESS", size=3, sha256="old-hash")
            path.write_text("new content", encoding="utf-8")
            sender = SenderEngine(target, ledger, scan_interval=0.1, stable_seconds=0.1)
            sender.tick(0.0)
            sender.tick(1.0)
            manifest = sender.manifest()
            self.assertEqual(len(manifest), 1)
            self.assertFalse(manifest[0]["sendable"])
            self.assertEqual(manifest[0]["sha256"], "old-hash")


if __name__ == "__main__":
    unittest.main()
