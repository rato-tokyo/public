from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from src.constants import MessageKind
from src.ledger import Ledger
from src.messages import json_bytes, parse_json
from src.sync import SenderEngine


class OutgoingTransferReportTests(unittest.TestCase):
    def test_receiver_completion_ack_writes_outgoing_last_transfer(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "target"
            target.mkdir()
            (target / "sample.bin").write_bytes(b"payload")
            report_path = root / "last_transfer.json"
            sender = SenderEngine(
                target, Ledger(root / "ledger.json", "sender").scope("outgoing"),
                scan_interval=0.1, stable_seconds=0.1,
                report_path=report_path,
            )
            try:
                sender.tick(0.0)
                sender.tick(1.0)
                metadata = sender.handle(
                    MessageKind.FILE_REQUEST, json_bytes({"path": "sample.bin"}), 1.1
                )
                self.assertEqual(metadata[0][0], MessageKind.FILE_META)
                meta = parse_json(metadata[0][1])
                replies = sender.handle(
                    MessageKind.FILE_COMPLETE,
                    json_bytes({
                        "transfer_id": meta["transfer_id"],
                        "size": meta["size"],
                        "sha256": meta["sha256"],
                        "session_id": "peer-session",
                    }),
                    2.0,
                )
            finally:
                sender.close()

            self.assertEqual(replies[0][0], MessageKind.COMPLETE_CONFIRM)
            report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(report["status"], "SUCCESS")
            self.assertEqual(report["direction"], "outgoing")
            self.assertEqual(report["relative_path"], "sample.bin")
            self.assertTrue(report["sha256_verified"])
            self.assertEqual(report["session_id"], "peer-session")

    def test_source_change_writes_cancelled_outgoing_last_transfer(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "target"
            target.mkdir()
            source = target / "sample.bin"
            source.write_bytes(b"before")
            report_path = root / "last_transfer.json"
            sender = SenderEngine(
                target, Ledger(root / "ledger.json", "sender").scope("outgoing"),
                scan_interval=0.1, stable_seconds=0.1,
                report_path=report_path,
            )
            try:
                sender.tick(0.0)
                sender.tick(1.0)
                sender.handle(
                    MessageKind.FILE_REQUEST, json_bytes({"path": "sample.bin"}), 1.1
                )
                source.write_bytes(b"changed and now longer")
                sender.tick(2.0)
            finally:
                sender.close()

            report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(report["status"], "CANCELLED")
            self.assertEqual(report["direction"], "outgoing")
            self.assertEqual(report["relative_path"], "sample.bin")
            self.assertFalse(report["sha256_verified"])


if __name__ == "__main__":
    unittest.main()
