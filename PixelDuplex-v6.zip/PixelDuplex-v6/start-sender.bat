@echo off
rem PixelDuplex sender: double-click. The other PC runs start-receiver.bat
rem from the same release ZIP. Add --check to set up and diagnose only.
call "%~dp0tools\launch.bat" start --role sender %*
exit /b %ERRORLEVEL%
