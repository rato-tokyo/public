@echo off
rem PixelDuplex receiver: double-click. The other PC runs start-sender.bat
rem from the same release ZIP. Add --check to set up and diagnose only.
call "%~dp0tools\launch.bat" start --role receiver %*
exit /b %ERRORLEVEL%
