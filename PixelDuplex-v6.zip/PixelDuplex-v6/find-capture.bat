@echo off
rem Find this PC's USB capture index and save it to config.json.
rem Stop this PC's PixelDuplex first (Esc); keep the other PC's running.
call "%~dp0tools\launch.bat" find-capture --write
exit /b %ERRORLEVEL%
