"""Short USB HDMI capture diagnostic for PixelDuplex.

Run from any directory::

    python tools/capture_probe.py
    python tools/capture_probe.py --json --save-frame

The probe refuses to open the capture device while PixelDuplex owns the
project instance lock.  ``--force`` is intended only for deliberate operator
diagnosis when device contention is understood.

The default probe does not modify synchronization data.  ``--save-frame``
writes a new diagnostic image which may contain sensitive on-screen content.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import uuid
from collections import Counter
from contextlib import nullcontext
from pathlib import Path


BASE = Path(__file__).resolve().parents[1]
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

try:
    import cv2
    import numpy as np

    from src.app import InstanceLock, load_settings
    from src.band_codec import decode_bands
    from src.build import BUILD_TEXT
    from src.constants import HEIGHT, PROTOCOL_VERSION, WIDTH, PhysicalKind
    from src.handshake import BEACON, EMPTY_NONCE, FLAG_HEARD, ROLE_NAME
    from src.hardware import open_capture, require_opencv_gui
    from src.wire import decode_image_detail
except (ImportError, ModuleNotFoundError) as error:  # pragma: no cover - environment guard
    missing = getattr(error, "name", None) or error.__class__.__name__
    message = (
        f"Missing dependency: {missing}. Install dependencies with: "
        "python -m pip install -r requirements.txt"
    )
    if "--json" in sys.argv[1:]:
        print(json.dumps({
            "status": "FAILURE",
            "error": message,
            "error_type": error.__class__.__name__,
            "device": None,
        }, ensure_ascii=True, indent=2))
    else:
        print(f"Capture probe: FAILURE\n{message}", file=sys.stderr)
    raise SystemExit(2) from error


EXIT_SUCCESS = 0
EXIT_WARNING = 1
EXIT_OPERATIONAL_FAILURE = 2
WORKER_GRACE_SECONDS = 5.0


class _ProbeArgumentParser(argparse.ArgumentParser):
    """Keep the machine-readable CLI contract even for argparse failures."""

    def error(self, message: str) -> None:
        if "--json" in sys.argv[1:]:
            print(json.dumps({
                "status": "FAILURE",
                "error": message,
                "error_type": "ArgumentError",
                "device": None,
            }, ensure_ascii=True, indent=2))
            raise SystemExit(EXIT_OPERATIONAL_FAILURE)
        super().error(message)


def parse_args() -> argparse.Namespace:
    parser = _ProbeArgumentParser(
        description="Briefly inspect the PixelDuplex USB HDMI capture input"
    )
    parser.add_argument(
        "--device", type=int,
        help="DirectShow capture index (default: config.json capture_device)",
    )
    parser.add_argument(
        "--frames", type=int, default=60,
        help="number of frames to attempt, 1-90 (default: 60)",
    )
    parser.add_argument(
        "--timeout", type=float, default=15.0,
        help=("maximum measurement time after warmup in seconds (default: 15); "
              "total best-effort duration is warmup plus timeout"),
    )
    parser.add_argument(
        "--warmup-seconds", type=float, default=2.5,
        help="discard frames for this many seconds before measurement, 0 or greater (default: 2.5)",
    )
    parser.add_argument("--json", action="store_true", help="emit JSON only")
    parser.add_argument(
        "--save-frame", action="store_true",
        help=("save one captured frame under artifacts/reports with a unique name; "
              "the image may contain sensitive on-screen content"),
    )
    parser.add_argument(
        "--force", action="store_true",
        help="bypass the running-instance lock check (may contend for the device)",
    )
    parser.add_argument("--_probe-worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not 1 <= args.frames <= 90:
        parser.error("--frames must be between 1 and 90")
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    if args.warmup_seconds < 0:
        parser.error("--warmup-seconds must be zero or greater")
    if args.device is not None and args.device < 0:
        parser.error("--device must be zero or greater")
    return args


def run_probe_worker(args: argparse.Namespace, device: int) -> dict:
    """Run the potentially blocking DirectShow work behind a hard process deadline."""
    command = [
        sys.executable, str(Path(__file__).resolve()), "--_probe-worker", "--json",
        "--device", str(device), "--frames", str(args.frames),
        "--timeout", str(args.timeout),
        "--warmup-seconds", str(args.warmup_seconds),
    ]
    if args.save_frame:
        command.append("--save-frame")
    hard_timeout = args.warmup_seconds + args.timeout + WORKER_GRACE_SECONDS
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=hard_timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as error:
        raise RuntimeError(
            "capture probe exceeded its hard deadline "
            f"({hard_timeout:.1f}s); DirectShow open/read may be blocked"
        ) from error
    try:
        report = json.loads(completed.stdout)
    except json.JSONDecodeError as error:
        detail = completed.stderr.strip() or "worker produced no valid JSON"
        raise RuntimeError(f"capture probe worker failed: {detail}") from error
    if not isinstance(report, dict):
        raise RuntimeError("capture probe worker returned invalid JSON")
    return report


def rect_key(rect: tuple[int, int, int, int] | None) -> str:
    return "none" if rect is None else ",".join(str(value) for value in rect)


def packet_id(packet) -> tuple[str, int, int]:
    """Identity of one transmitted message; a new message means a redrawn screen.

    Pixel differences cannot tell a stopped peer from one that only updates a
    beacon (about 20 changed bits), so screen updates are judged from the
    decoded messages instead.
    """
    return packet.session_id.hex(), int(packet.kind), int(packet.message_id)


def parse_beacon(payload: bytes) -> dict | None:
    """Public fields of a peer beacon; salt and challenge are not reported."""
    if len(payload) != BEACON.size:
        return None
    (version, role, flags, _session, _salt, _challenge, build, nonce,
     heard_nonce) = BEACON.unpack(payload)
    return {
        "protocol_version": version,
        "role": ROLE_NAME.get(role, f"unknown({role})"),
        "build": build.hex(),
        "heard_flag": bool(flags & FLAG_HEARD),
        "heard_someone": heard_nonce != EMPTY_NONCE,
        "process_nonce": nonce.hex(),
    }


def summarize_beacons(beacons: list[dict]) -> dict | None:
    if not beacons:
        return None
    last = beacons[-1]
    builds = sorted({item["build"] for item in beacons})
    return {
        "beacons_decoded": len(beacons),
        "role": last["role"],
        "roles_seen": sorted({item["role"] for item in beacons}),
        "build": last["build"],
        "builds_seen": builds,
        "build_matches_local": all(build == BUILD_TEXT for build in builds),
        "protocol_version": last["protocol_version"],
        "heard_flag": last["heard_flag"],
        "heard_flag_seen": any(item["heard_flag"] for item in beacons),
        "heard_someone": last["heard_someone"],
        "distinct_process_nonces": len({item["process_nonce"] for item in beacons}),
    }


def screen_update_verdict(decoded_frames: int, changes: int) -> str:
    if decoded_frames < 2:
        return "undetermined"
    return "updating" if changes else "static"


def probe(
    device: int,
    frame_limit: int,
    timeout: float,
    save_frame: bool,
    warmup_seconds: float = 0.0,
) -> dict:
    gui_backend = require_opencv_gui()
    capture = open_capture(device)
    probe_started = time.monotonic()
    if not capture.isOpened():
        capture.release()
        raise RuntimeError(f"could not open DirectShow capture device {device}")

    warmup_frames = 0
    warmup_read_failures = 0
    warmup_deadline = time.monotonic() + warmup_seconds
    try:
        while time.monotonic() < warmup_deadline:
            ok, frame = capture.read()
            if ok and frame is not None:
                warmup_frames += 1
            else:
                warmup_read_failures += 1
    except BaseException:
        capture.release()
        raise

    measurement_started = time.monotonic()
    captured_frames = 0
    read_failures = 0
    kinds: Counter[str] = Counter()
    rects: Counter[str] = Counter()
    decode_successes = 0
    band_frame_successes = 0
    band_packets = 0
    actual = {}
    shapes: Counter[str] = Counter()
    mean_sum = 0.0
    stddev_sum = 0.0
    distinct_ids: set[tuple[str, int, int]] = set()
    previous_frame_ids: frozenset | None = None
    packet_id_changes = 0
    decoded_packet_frames = 0
    foreign_frames = 0
    foreign_versions: Counter[int] = Counter()
    beacons: list[dict] = []
    malformed_beacons = 0
    last_frame = None
    try:
        for _ in range(frame_limit):
            if time.monotonic() - measurement_started >= timeout:
                break
            ok, frame = capture.read()
            if not ok or frame is None:
                read_failures += 1
                continue
            captured_frames += 1
            shapes["x".join(str(value) for value in frame.shape)] += 1
            mean_sum += float(np.mean(frame))
            stddev_sum += float(np.std(frame))
            last_frame = frame
            packet, rect, foreign = decode_image_detail(frame)
            if foreign is not None:
                # An intact PixelDuplex frame of another protocol version.
                foreign_frames += 1
                foreign_versions[int(foreign)] += 1
                packets = []
            elif packet is not None:
                decode_successes += 1
                packets = [packet]
            else:
                # Banded profiles draw four independently checked bands instead.
                packets, rect = decode_bands(frame)
                if packets:
                    band_frame_successes += 1
                    band_packets += len(packets)
            for item in packets:
                try:
                    name = PhysicalKind(item.kind).name
                except ValueError:
                    name = f"UNKNOWN_{item.kind}"
                kinds[name] += 1
                if item.kind == PhysicalKind.BEACON:
                    beacon = parse_beacon(item.payload)
                    if beacon is None:
                        malformed_beacons += 1
                    else:
                        beacons.append(beacon)
            if packets:
                rects[rect_key(rect)] += 1
                decoded_packet_frames += 1
                frame_ids = frozenset(packet_id(item) for item in packets)
                distinct_ids.update(frame_ids)
                if previous_frame_ids is not None and frame_ids != previous_frame_ids:
                    packet_id_changes += 1
                previous_frame_ids = frame_ids
    finally:
        actual_fourcc = int(capture.get(cv2.CAP_PROP_FOURCC))
        actual = {
            "fourcc": "".join(
                chr((actual_fourcc >> (8 * index)) & 0xFF) for index in range(4)
            ).rstrip("\x00"),
            "width": int(capture.get(cv2.CAP_PROP_FRAME_WIDTH)),
            "height": int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT)),
            "fps": float(capture.get(cv2.CAP_PROP_FPS)),
        }
        capture.release()
    measurement_elapsed = time.monotonic() - measurement_started

    output_path = None
    if save_frame and last_frame is not None:
        reports = BASE / "artifacts" / "reports"
        reports.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%dT%H%M%S", time.gmtime())
        # A UUID makes accidental overwrite impossible in normal operation;
        # retain the existence check as a final defensive guard.
        path = reports / f"capture-probe-{stamp}Z-{uuid.uuid4().hex[:12]}.png"
        if path.exists():
            raise RuntimeError(f"refusing to overwrite diagnostic image: {path}")
        if not cv2.imwrite(str(path), last_frame):
            raise RuntimeError(f"failed to save captured frame: {path}")
        output_path = str(path)

    total_elapsed = time.monotonic() - probe_started
    protocol_detected = bool(decode_successes or band_frame_successes)
    peer_beacon = summarize_beacons(beacons)
    if peer_beacon is None:
        peer_build_verdict = "unknown"
    else:
        peer_build_verdict = "match" if peer_beacon["build_matches_local"] else "mismatch"
    return {
        "status": "SUCCESS" if captured_frames else "FAILURE",
        "success_scope": (
            "protocol_detected" if protocol_detected else "capture_only"
        ) if captured_frames else "none",
        "protocol_frames_detected": protocol_detected,
        "device": device,
        "backend": "DirectShow",
        "opencv_gui_backend": gui_backend,
        "requested": {"fourcc": "YUY2", "width": WIDTH, "height": HEIGHT, "fps": 30},
        "actual": actual,
        "attempted_frames": frame_limit,
        "captured_frames": captured_frames,
        "read_failures": read_failures,
        "warmup_seconds_requested": warmup_seconds,
        "warmup_frames_discarded": warmup_frames,
        "warmup_read_failures": warmup_read_failures,
        "elapsed_seconds": round(measurement_elapsed, 3),
        "total_elapsed_seconds": round(total_elapsed, 3),
        "timeout_scope": "measurement_after_warmup",
        "shapes": dict(shapes),
        "pixel_mean": None if not captured_frames else round(mean_sum / captured_frames, 3),
        "pixel_stddev": None if not captured_frames else round(stddev_sum / captured_frames, 3),
        "local_protocol_version": PROTOCOL_VERSION,
        "local_build": BUILD_TEXT,
        # The peer screen is judged from decoded messages, never pixel deltas.
        "peer_screen_visible": protocol_detected,
        "decoded_packet_frames": decoded_packet_frames,
        "distinct_packet_ids": len(distinct_ids),
        "packet_id_changes": packet_id_changes,
        "screen_update_verdict": screen_update_verdict(
            decoded_packet_frames, packet_id_changes
        ),
        "foreign_version_frames": foreign_frames,
        "foreign_versions": sorted(foreign_versions),
        "peer_beacon": peer_beacon,
        "malformed_beacons": malformed_beacons,
        "peer_build_verdict": peer_build_verdict,
        "decode_image_successes": decode_successes,
        # Frames read only as bands, and the band packets they carried.
        "band_decode_frames": band_frame_successes,
        "band_packets_decoded": band_packets,
        "packet_kinds": dict(sorted(kinds.items())),
        "active_rects": dict(sorted(rects.items())),
        "saved_frame": output_path,
        "saved_frame_contains_screen_content": bool(output_path),
        "capture_read_timeout_note": (
            "--timeout is checked between reads; the DirectShow backend may block "
            "inside capture.read(), so it is not a hard per-read deadline"
        ),
    }


def conclusion_lines(report: dict) -> list[str]:
    """Japanese conclusions first, each backed by the counts it came from."""
    lines = []
    foreign = report.get("foreign_version_frames", 0)
    versions = ", ".join(f"v{value}" for value in report.get("foreign_versions", []))
    if report.get("peer_screen_visible"):
        lines.append(
            f"相手の画面: 見えている（PixelDuplexのフレームを{report['decoded_packet_frames']}枚復号）"
        )
    elif foreign:
        lines.append(
            f"相手の画面: 別の版の画面が見えている（{versions}、{foreign}枚）。"
            f"このPCはv{report.get('local_protocol_version')}。両方のPCで同じZIPを展開して起動する"
        )
    else:
        lines.append("相手の画面: 見えていない（PixelDuplexのフレームを1枚も復号できなかった）")
    verdict = report.get("screen_update_verdict")
    ids = report.get("distinct_packet_ids", 0)
    changes = report.get("packet_id_changes", 0)
    if verdict == "updating":
        lines.append(f"相手の画面の更新: 更新されている（異なるパケット{ids}種、切替{changes}回）")
    elif verdict == "static":
        lines.append(
            f"相手の画面の更新: 同じパケットだけが見えた（{ids}種、切替0回）。"
            "測定時間を延ばして再確認する（--timeout）"
        )
    else:
        lines.append("相手の画面の更新: 判定できない（復号できたフレームが2枚未満）")
    beacon = report.get("peer_beacon")
    local = report.get("local_build")
    if beacon is None:
        lines.append("相手のビルド: 不明（ビーコンを受信できなかった）")
    elif report.get("peer_build_verdict") == "match":
        lines.append(f"相手のビルド: 一致（{beacon['build']}）")
    else:
        lines.append(
            f"相手のビルド: 不一致（相手 {', '.join(beacon['builds_seen'])}、このPC {local}）。"
            "両方のPCで同じZIPを展開して起動する"
        )
    if beacon is not None:
        heard = "受信中と表示" if beacon["heard_flag"] else "受信していないと表示"
        lines.append(
            f"相手のビーコン: role={beacon['role']} v{beacon['protocol_version']} "
            f"相手はこちらの画面を{heard}（{beacon['beacons_decoded']}件）"
        )
        if not beacon["heard_flag"]:
            lines.append(
                "  注: このPCのPixelDuplexを止めて測定しているため、相手が受信していないのは通常の結果"
            )
    return lines


def print_human(report: dict) -> None:
    for line in conclusion_lines(report):
        print(line)
    print("")
    print(f"Capture probe: {report['status']}")
    print(f"Local: protocol v{report.get('local_protocol_version')} build {report.get('local_build')}")
    print(f"Device: {report['device']} via {report['backend']}")
    print(f"Frames: {report['captured_frames']}/{report['attempted_frames']} "
          f"(read failures: {report['read_failures']})")
    print(f"Shapes: {report['shapes'] or 'none'}")
    print(f"Pixel mean/stddev: {report['pixel_mean']} / {report['pixel_stddev']}")
    print(f"Decoded packet frames: {report.get('decoded_packet_frames', 0)} | "
          f"distinct packet ids: {report.get('distinct_packet_ids', 0)} | "
          f"id changes: {report.get('packet_id_changes', 0)} | "
          f"verdict: {report.get('screen_update_verdict')}")
    print(f"Foreign-version frames: {report.get('foreign_version_frames', 0)} "
          f"{report.get('foreign_versions') or ''}".rstrip())
    print(f"PixelDuplex decodes: full-frame={report['decode_image_successes']} "
          f"band-frames={report.get('band_decode_frames', 0)} "
          f"(band packets: {report.get('band_packets_decoded', 0)})")
    if report["status"] == "SUCCESS" and not report["protocol_frames_detected"]:
        print("Result scope: capture-only success; no PixelDuplex protocol frame decoded")
    elif report["status"] == "SUCCESS":
        print("Result scope: PixelDuplex protocol frame detected")
    print(f"Packet kinds: {report['packet_kinds'] or 'none'}")
    print(f"Active rects: {report['active_rects'] or 'none'}")
    if report["saved_frame"]:
        print(f"Saved frame: {report['saved_frame']}")
        print("WARNING: the saved image may contain sensitive on-screen content.")


def main() -> int:
    args = parse_args()
    device = args.device
    try:
        if device is None:
            device = load_settings(BASE).capture_device
        if device < 0:
            raise ValueError("capture_device must be zero or greater")
        if args._probe_worker:
            # The parent owns the instance lock and enforces the hard deadline.
            report = probe(
                device, args.frames, args.timeout, args.save_frame,
                warmup_seconds=args.warmup_seconds,
            )
        else:
            lock = nullcontext() if args.force else InstanceLock(BASE / ".pixelduplex.lock")
            with lock:
                report = run_probe_worker(args, device)
    except Exception as error:
        message = str(error)
        if message == "PixelDuplex is already running from this directory":
            message += "; stop it first or use --force only if device contention is acceptable"
        report = {
            "status": "FAILURE",
            "error": message or error.__class__.__name__,
            "error_type": error.__class__.__name__,
            "device": device,
        }
        if args.json:
            print(json.dumps(report, ensure_ascii=True, indent=2))
        else:
            print(f"Capture probe: FAILURE\n{message}", file=sys.stderr)
        return EXIT_OPERATIONAL_FAILURE

    if args.json:
        print(json.dumps(report, ensure_ascii=True, indent=2))
    else:
        print_human(report)
    if report["status"] == "SUCCESS":
        return EXIT_SUCCESS
    if report["status"] == "WARNING":
        return EXIT_WARNING
    return EXIT_OPERATIONAL_FAILURE


if __name__ == "__main__":
    raise SystemExit(main())
