@echo off
rem Shared by start-sender.bat, start-receiver.bat and find-capture.bat.
rem Prepares .venv on first use, then runs "pixelduplex.py <arguments>".
setlocal
cd /d "%~dp0.."
set "BASE=%CD%"
set "PY=%BASE%\.venv\Scripts\python.exe"
set "RC=0"
if exist "%PY%" goto version

echo SETUP: creating .venv - first start only
where py >nul 2>nul
if errorlevel 1 goto path_python
py -3.12 -m venv "%BASE%\.venv"
if exist "%PY%" goto version
:path_python
python -m venv "%BASE%\.venv"
if exist "%PY%" goto version
echo FAILURE: Python 3.12 or later was not found. Install it from python.org, then start again.
set "RC=2"
goto end

:version
"%PY%" -c "import sys; sys.exit(sys.version_info < (3, 12))"
if not errorlevel 1 goto deps
echo FAILURE: .venv uses Python older than 3.12. Install Python 3.12, delete the .venv folder, then start again.
set "RC=2"
goto end

:deps
"%PY%" -c "import cv2, numpy, cryptography" >nul 2>nul
if not errorlevel 1 goto run
echo SETUP: installing requirements.txt into .venv
"%PY%" -m pip install -r "%BASE%\requirements.txt"
if not errorlevel 1 goto run
echo FAILURE: pip install failed. Check the network, delete the .venv folder, then start again.
echo If the folder path is long, extract the ZIP to a short path such as C:\PixelDuplex-v6 (Windows 260-character path limit).
set "RC=2"
goto end

:run
"%PY%" "%BASE%\pixelduplex.py" %*
set "RC=%ERRORLEVEL%"

:end
echo PixelDuplex ended with exit code %RC%
if "%PIXELDUPLEX_NO_PAUSE%"=="" pause
exit /b %RC%
