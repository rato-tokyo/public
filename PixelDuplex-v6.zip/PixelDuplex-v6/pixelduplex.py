r"""PixelDuplex common entry point for sender and receiver.

Normal start: double-click start-sender.bat on one PC and start-receiver.bat
on the other. They create .venv, config.json and key.txt on first start and
then call:
    python .\pixelduplex.py start --role sender|receiver

Find the capture index while the other PC shows PixelDuplex:
    python .\pixelduplex.py find-capture --write

Run with an already prepared config.json and key.txt:
    python .\pixelduplex.py run

Run a round-trip diagnostic from the receiver while the sender is running:
    python .\pixelduplex.py self-test

Run an explicit on-disk file round trip from the receiver:
    python .\pixelduplex.py file-test

Stop with Ctrl+C or Escape. Paths are always resolved relative to this file,
not relative to the shell's current directory.
"""

from __future__ import annotations

import argparse
import sys
import time
import traceback
from pathlib import Path

from src.app import (
    DEFAULT_TEST_BYTES, DEFAULT_TEST_PROFILE, InstanceLock, print_status, request_stop, run_command,
)
from src.ledger import atomic_json
from src.start import find_capture, start


BASE = Path(__file__).resolve().parent


def record_failure_status(base: Path, mode: str) -> None:
    """Replace stale status after a failed launch, unless another run owns it."""
    try:
        with InstanceLock(base / ".pixelduplex.lock"):
            atomic_json(base / "artifacts" / "reports" / "status.json", {
                "status": "FAILURE",
                "reason": "application error; see artifacts/logs/fatal.log",
                "role": None,
                "mode": mode,
                "connected": False,
                "handshake_state": None,
                "session_id": None,
                "active_transfer": None,
                "active_transfer_direction": None,
                "sync_token_owner": None,
                "sync_token_epoch": None,
                "authentication_failures": 0,
                "duplicate_secure_messages": 0,
                "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            })
    except (OSError, RuntimeError):
        # A second invocation must not replace the active instance's status.
        pass


def main() -> int:
    parser = argparse.ArgumentParser(description="Encrypted file synchronization over crossed HDMI capture links")
    parser.add_argument("command", choices=(
        "start", "run", "self-test", "file-test", "profile-test", "status", "stop", "find-capture",
    ))
    parser.add_argument("--role", choices=("sender", "receiver"),
                        help="start: this PC's role; creates config.json from its template")
    parser.add_argument("--check", action="store_true",
                        help="start: prepare and diagnose only, do not run")
    parser.add_argument("--write", action="store_true",
                        help="find-capture: save a single match to config.json")
    parser.add_argument("--json", action="store_true", help="show status as JSON (status command)")
    parser.add_argument("--profile", choices=("baseline", "mono-band4", "gray4-band4"),
                        default=DEFAULT_TEST_PROFILE,
                        help="candidate for profile-test; never persists a setting")
    parser.add_argument("--bytes", type=int, default=DEFAULT_TEST_BYTES,
                        help="in-memory blob size for self-test / profile-test")
    args = parser.parse_args()
    if args.command == "status":
        return print_status(BASE)
    if args.command == "stop":
        return request_stop(BASE)
    if args.command == "start":
        if args.role is None:
            parser.error("start needs --role sender or --role receiver")
        return start(BASE, args.role, check_only=args.check)
    if args.command == "find-capture":
        return find_capture(BASE, write=args.write)
    return run_command(BASE, args.command, test_profile=args.profile, test_bytes=args.bytes)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception as error:
        print(f"FAILURE: {error}", flush=True)
        log = BASE / "artifacts" / "logs" / "fatal.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(traceback.format_exc(), encoding="utf-8")
        print(f"Error log: {log}", flush=True)
        mode = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] in {"start", "run", "self-test", "file-test", "profile-test"} else "unknown"
        record_failure_status(BASE, mode)
        raise SystemExit(1)
