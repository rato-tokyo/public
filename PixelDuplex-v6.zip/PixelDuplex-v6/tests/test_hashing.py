"""SHA-256 work must not stall the display loop (ISSUE-014)."""

from __future__ import annotations

import hashlib
import os
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from src.constants import MessageKind
from src.files import AtomicReceiver, HashCancelled, sha256_file, snapshot_file
from src.ledger import Ledger
from src.sync import SCAN_HASH_WAIT_SECONDS, SenderEngine


class IncrementalReceiveHashTests(unittest.TestCase):
    def test_out_of_order_chunks_publish_without_rereading_the_file(self):
        data = os.urandom(10_000)
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "out.bin"
            receiver = AtomicReceiver(destination, len(data), hashlib.sha256(data).hexdigest(),
                                      chunk_count=4, chunk_bytes=3_000)
            for index in (2, 0, 3, 1, 2):
                receiver.write(index, data[index * 3_000:(index + 1) * 3_000])
            with mock.patch("src.files.sha256_file", side_effect=AssertionError("re-read")):
                receiver.publish()
            self.assertEqual(destination.read_bytes(), data)

    def test_wrong_content_is_refused_and_removed(self):
        data = os.urandom(5_000)
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "out.bin"
            receiver = AtomicReceiver(destination, len(data), hashlib.sha256(b"other").hexdigest(),
                                      chunk_count=2, chunk_bytes=3_000)
            receiver.write(0, data[:3_000])
            receiver.write(1, data[3_000:])
            with self.assertRaisesRegex(RuntimeError, "SHA-256"):
                receiver.publish()
            self.assertFalse(destination.exists())
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_empty_file(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "empty.bin"
            receiver = AtomicReceiver(destination, 0, hashlib.sha256(b"").hexdigest(), chunk_count=1)
            receiver.write(0, b"")
            receiver.publish()
            self.assertEqual(destination.read_bytes(), b"")


class BackgroundSenderHashTests(unittest.TestCase):
    def make_sender(self, base: Path) -> SenderEngine:
        target = base / "target"
        target.mkdir()
        (target / "big.bin").write_bytes(b"payload")
        return SenderEngine(target, Ledger(base / "ledger.json", "sender").scope("outgoing"),
                            scan_interval=0.1, stable_seconds=0.1)

    def test_slow_hash_does_not_block_the_scan(self):
        release = threading.Event()

        def slow_snapshot(root, path, stop=None):
            release.wait(5)
            return snapshot_file(root, path)

        with tempfile.TemporaryDirectory() as directory:
            sender = self.make_sender(Path(directory))
            try:
                with mock.patch("src.sync.snapshot_file", side_effect=slow_snapshot):
                    sender.scan(0.0)
                    started = time.monotonic()
                    self.assertEqual(sender.scan(1.0), [])
                    self.assertLess(time.monotonic() - started, SCAN_HASH_WAIT_SECONDS + 0.5)
                    self.assertFalse(sender.manifest()[0]["sendable"])
                    release.set()
                    time.sleep(0.05)
                    announced = sender.scan(2.0)
                self.assertEqual([kind for kind, _ in announced], [MessageKind.FILE_ANNOUNCE])
                self.assertTrue(sender.manifest()[0]["sendable"])
            finally:
                release.set()
                sender.close()

    def test_small_file_is_announced_in_the_same_scan(self):
        with tempfile.TemporaryDirectory() as directory:
            sender = self.make_sender(Path(directory))
            try:
                sender.scan(0.0)
                self.assertEqual([kind for kind, _ in sender.scan(1.0)], [MessageKind.FILE_ANNOUNCE])
            finally:
                sender.close()

    def test_close_cancels_a_running_hash(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "file.bin"
            path.write_bytes(b"x" * 3_000_000)
            stop = threading.Event()
            stop.set()
            with self.assertRaises(HashCancelled):
                sha256_file(path, stop)


if __name__ == "__main__":
    unittest.main()
