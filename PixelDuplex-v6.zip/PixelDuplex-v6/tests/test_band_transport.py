"""Offline tests for profile routing, staggered bands and ACK coalescing."""

from __future__ import annotations

import unittest
from collections import deque
from unittest import mock

import numpy as np

from src import band_codec
from src.constants import MessageKind, PHYSICAL_PAYLOAD_BYTES
from src.hardware import HdmiFrameIO
from src.link import LinkSession
from src.wire import PhysicalPacket


def packet(message_id: int, payload: bytes = b"x") -> PhysicalPacket:
    return PhysicalPacket(4, b"s" * 16, message_id, 0, 1, len(payload), payload)


class LinkProfileTests(unittest.TestCase):
    def test_rejects_unknown_profile_and_unconnected_switch(self):
        link = LinkSession("sender", "password")
        with self.assertRaises(ValueError):
            link.set_send_profile("gray4-2")
        with self.assertRaises(RuntimeError):
            link.set_send_profile("mono-band4")
        self.assertEqual(link.send_profile, "baseline")

    def test_secure_uses_band_capacity_but_control_can_force_baseline(self):
        for layout in band_codec.LAYOUTS.values():
            link = LinkSession("sender", "password")
            link.handshake.channel = mock.Mock()
            link.handshake.channel.seal.return_value = b"x" * (layout.payload_bytes + 10)
            link.handshake.session_id = b"s" * 16
            with mock.patch.object(type(link), "connected", new_callable=mock.PropertyMock,
                                   return_value=True):
                link.set_send_profile(layout.profile_id)
            packets = link.secure(MessageKind.KEEPALIVE, b"x")
            self.assertEqual(len(packets), 2)
            self.assertEqual(len(packets[0].payload), layout.payload_bytes)
            baseline = link.secure(MessageKind.KEEPALIVE, b"x", force_baseline=True)
            # The full-frame format holds the same envelope in one packet.
            self.assertLess(layout.payload_bytes + 10, PHYSICAL_PAYLOAD_BYTES)
            self.assertEqual(len(baseline), 1)
            self.assertEqual(len(baseline[0].payload), layout.payload_bytes + 10)


class StaggeredDisplayTests(unittest.TestCase):
    def pump(self, io: HdmiFrameIO, times: int, now: float = 100.0):
        with mock.patch("src.hardware.cv2.imshow") as show, \
             mock.patch("src.hardware.cv2.waitKey", return_value=-1), \
             mock.patch("src.hardware.time.monotonic", return_value=now):
            for _ in range(times):
                io.pump_display()
        return show

    def test_bands_repaint_one_at_a_time_in_rotation(self):
        io = HdmiFrameIO(0, frame_interval=0.4)
        sent = [packet(index, bytes([index])) for index in range(1, 6)]
        io.send(sent, profile="mono-band4")
        displayed = []
        for step in range(5):
            show = self.pump(io, 1, now=100.0 + step * 0.1)
            displayed.append(show.call_args.args[1].copy())
            self.assertAlmostEqual(io._next_frame_at, 100.0 + step * 0.1 + 0.1)
        decoded, _ = band_codec.decode_bands(displayed[3])
        self.assertEqual(decoded, sent[:4])
        # The fifth packet replaces band 0 only; bands 1-3 stay on screen.
        decoded, _ = band_codec.decode_bands(displayed[4])
        self.assertEqual(decoded, [sent[4], *sent[1:4]])

    def test_display_callback_fires_when_band_is_painted(self):
        io = HdmiFrameIO(0, frame_interval=0)
        seen = []
        io.send([packet(1)], profile="gray4-band4", on_display=seen.append)
        self.pump(io, 1, now=5.0)
        self.assertEqual(seen, [5.0])

    def test_full_frame_waits_until_newest_band_was_up_for_one_interval(self):
        io = HdmiFrameIO(0, frame_interval=0.4)
        io.send([packet(1)], profile="mono-band4")
        io.send([packet(2)])
        self.pump(io, 1, now=10.0)
        show = self.pump(io, 1, now=10.2)
        show.assert_not_called()
        self.assertEqual(len(io._outgoing), 1)
        show = self.pump(io, 1, now=10.41)
        show.assert_called_once()
        # The band canvas survives a baseline frame so the next band repaint
        # does not blank the other bands.
        self.assertIsNotNone(io._canvas)

    def test_clear_and_reject_unknown(self):
        io = HdmiFrameIO(0)
        with self.assertRaises(ValueError):
            io.send([packet(1)], profile="unknown")
        io.send([packet(1)], profile="mono-band4", coalesce_key=("ack", 1))
        io.clear_outgoing()
        self.assertFalse(io._outgoing)


class AckCoalescingTests(unittest.TestCase):
    def test_newer_ack_replaces_undisplayed_one_in_place(self):
        io = HdmiFrameIO(0, frame_interval=0)
        io.send([packet(1)], profile="mono-band4")
        first_seen, second_seen = [], []
        io.send([packet(2, b"old")], priority=True, profile="mono-band4",
                coalesce_key=(9, b"t"), on_display=first_seen.append)
        io.send([packet(3, b"new")], priority=True, profile="mono-band4",
                coalesce_key=(9, b"t"), on_display=second_seen.append)
        self.assertEqual([p.message_id for p in io.queued_packets()], [3, 1])
        self.assertEqual(io.queued_packets()[0].payload, b"new")
        self.assertEqual(io.coalesced_frames, 1)
        with mock.patch("src.hardware.cv2.imshow"), \
             mock.patch("src.hardware.cv2.waitKey", return_value=-1):
            io.pump_display()
        self.assertEqual(first_seen, [])
        self.assertEqual(len(second_seen), 1)

    def test_other_keys_and_multi_packet_sends_are_not_coalesced(self):
        io = HdmiFrameIO(0)
        io.send([packet(1)], coalesce_key=(9, b"a"))
        io.send([packet(2)], coalesce_key=(9, b"b"))
        io.send([packet(3), packet(4)], coalesce_key=(9, b"a"))
        self.assertEqual(len(io._outgoing), 4)
        self.assertEqual(io.coalesced_frames, 0)

    def test_displayed_ack_is_not_replaced(self):
        io = HdmiFrameIO(0, frame_interval=0)
        io.send([packet(1)], coalesce_key=(9, b"a"))
        with mock.patch("src.hardware.cv2.imshow"), \
             mock.patch("src.hardware.cv2.waitKey", return_value=-1):
            io.pump_display()
        io.send([packet(2)], coalesce_key=(9, b"a"))
        self.assertEqual([p.message_id for p in io.queued_packets()], [2])
        self.assertEqual(io.coalesced_frames, 0)


class RunnerAckRoutingTests(unittest.TestCase):
    def test_acks_are_prioritised_and_coalesced_per_transfer(self):
        from src.app import Runner
        from src.messages import encode_ack
        runner = Runner.__new__(Runner)
        runner.io = mock.Mock()
        runner.link = mock.Mock(send_profile="mono-band4")
        runner.link.secure.side_effect = lambda kind, payload: [packet(1, payload)]
        transfer_id = b"t" * 16
        runner._send_app([
            (MessageKind.FILE_ACK, encode_ack(transfer_id, 3, 5)),
            (MessageKind.BLOB_ACK, encode_ack(transfer_id, 0, 1)),
            (MessageKind.FILE_COMPLETE, b"{}"),
        ])
        calls = runner.io.send.call_args_list
        self.assertEqual(calls[0].kwargs["coalesce_key"], (int(MessageKind.FILE_ACK), transfer_id))
        self.assertTrue(calls[0].kwargs["priority"])
        self.assertEqual(calls[1].kwargs["coalesce_key"], (int(MessageKind.BLOB_ACK), transfer_id))
        # Other control messages coalesce only with an identical undisplayed copy.
        self.assertEqual(calls[2].kwargs["coalesce_key"][0], int(MessageKind.FILE_COMPLETE))
        self.assertFalse(calls[2].kwargs["priority"])

    def test_identical_control_retries_coalesce_but_data_does_not(self):
        from src.app import Runner
        from src.messages import encode_data
        runner = Runner.__new__(Runner)
        runner.io = mock.Mock()
        runner.link = mock.Mock(send_profile="baseline")
        runner.link.secure.side_effect = lambda kind, payload: [packet(1, payload)]
        runner.engine = mock.Mock()
        runner.engine.outbound.transfer = None
        runner.diagnostic = mock.Mock(send=None)
        runner._send_app([
            (MessageKind.SYNC_TOKEN, b'{"epoch":1}'),
            (MessageKind.SYNC_TOKEN, b'{"epoch":1}'),
            (MessageKind.SYNC_TOKEN, b'{"epoch":2}'),
            (MessageKind.FILE_DATA, encode_data(b"t" * 16, 0, b"x")),
        ])
        keys = [call.kwargs["coalesce_key"] for call in runner.io.send.call_args_list]
        self.assertEqual(keys[0], keys[1])
        self.assertNotEqual(keys[1], keys[2])
        self.assertIsNone(keys[3])

    def test_window_larger_than_ack_bitmap_is_rejected(self):
        import json
        import tempfile
        from pathlib import Path
        from src.app import MAX_WINDOW_SIZE, load_settings
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            path.write_text(json.dumps({"role": "sender", "window_size": MAX_WINDOW_SIZE}),
                            encoding="utf-8")
            self.assertEqual(load_settings(Path(directory)).window_size, 64)
            path.write_text(json.dumps({"role": "sender", "window_size": 65}), encoding="utf-8")
            with self.assertRaises(RuntimeError):
                load_settings(Path(directory))


class BandCaptureTests(unittest.TestCase):
    def run_capture(self, io: HdmiFrameIO, frames: list[np.ndarray]) -> None:
        class FiniteCapture:
            reads = deque((True, frame) for frame in frames)

            def read(self):
                if self.reads:
                    return self.reads.popleft()
                io._stop.set()
                return False, None

        io._capture = FiniteCapture()
        io._capture_loop()

    def test_unchanged_bands_are_delivered_once(self):
        io = HdmiFrameIO(0)
        layout = band_codec.MONO
        packets = [packet(index, bytes([index])) for index in range(1, 5)]
        first = band_codec.render_frame(layout, packets)
        second = first.copy()
        replacement = packet(9, b"new")
        band_codec.paint_band(second, 2, layout, replacement)
        self.run_capture(io, [first, first, second])
        delivered = [item[0] for item in io.receive()]
        self.assertEqual(delivered, [*packets, replacement])
        self.assertEqual(io.repeated_capture_frames, 4 + 3)
        self.assertTrue(io._prefer_bands)

    def test_baseline_frames_still_decode_and_switch_preference(self):
        from src.wire import packet_image
        io = HdmiFrameIO(0)
        io._prefer_bands = True
        expected = packet(3)
        self.run_capture(io, [packet_image(expected)])
        self.assertEqual([item[0] for item in io.receive()], [expected])
        self.assertFalse(io._prefer_bands)

    def test_capture_rate_is_measured_over_a_window(self):
        io = HdmiFrameIO(0)
        for step in range(8):
            io._count_capture_read(step * 1.0)
        self.assertEqual(io.capture_frames_per_second, 1.0)
        self.assertEqual(io.display_metrics()["capture_reads_per_second"], 1.0)


if __name__ == "__main__":
    unittest.main()
