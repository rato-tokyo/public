"""Offline checks for ISSUE-002; these do not replace two-PC trials."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from src.app import Runner
from src.constants import MessageKind
from src.handshake import Presence
from src.ledger import Ledger
from src.sync import SenderEngine
from src.messages import json_bytes
from src.profile_negotiation import ProfileNegotiator


def bare_runner(*, connected: bool, now: float) -> Runner:
    runner = Runner.__new__(Runner)
    runner.base = Path("nonexistent-bare-runner-base")  # no stop request there
    runner.io = mock.Mock()
    runner.io.pump_display.side_effect = [True, False]
    runner.link = mock.Mock(connected=connected)
    runner.link.periodic.return_value = []
    runner.settings = mock.Mock(
        role="receiver", handshake_timeout_seconds=300.0,
        scan_interval_seconds=5.0,
    )
    runner.mode = "run"
    runner.started = 0.0
    runner.last_valid_packet = 0.0
    runner.last_keepalive = float("-inf")
    runner.last_status = float("-inf")
    runner.ever_connected = False
    runner.reconnecting = False
    runner.candidate_failed = False
    runner.handshake_started_at = None
    runner.progress_marker = None
    runner.progress_changed_at = 0.0
    runner.engine = mock.Mock()
    runner.engine.outbound.transfer = None
    runner.engine.inbound.transfer = None
    runner.diagnostic = mock.Mock(active=False)
    runner.profile = mock.Mock(state="ACTIVE")
    runner.applied_profile = "baseline"
    runner._profile_tick = mock.Mock()
    runner._receive_packets = mock.Mock()
    runner._send_app = mock.Mock()
    runner._status = mock.Mock()
    runner._reset_link = mock.Mock()
    runner._check_session_change = mock.Mock()
    runner.presence = Presence()
    runner.link_down_since = 0.0
    runner.last_hint = 0.0
    runner.last_handshake_error = None
    runner.watchdog = mock.Mock(max_pause_seconds=0.0)
    runner.watchdog.beat.return_value = None
    runner.io.capture_alive.return_value = True
    runner.io.capture_metrics.return_value = {}
    runner._hint_tick = mock.Mock()
    runner._connect_failure = mock.Mock()
    runner._diagnosis = mock.Mock()
    return runner


class RunnerTimingTests(unittest.TestCase):
    def test_initial_connection_times_out_at_configured_limit(self):
        runner = bare_runner(connected=False, now=300.0)
        with mock.patch("src.app.time.monotonic", return_value=300.0):
            result = runner.run()
        self.assertEqual(result, 3)
        runner._status.assert_any_call("FAILURE", "startup connection timeout")
        runner._reset_link.assert_not_called()

    def test_connected_link_silence_resets_session_without_startup_timeout(self):
        runner = bare_runner(connected=True, now=301.0)
        runner.ever_connected = True
        runner.last_valid_packet = 285.0
        with mock.patch("src.app.time.monotonic", return_value=301.0):
            result = runner.run()
        self.assertEqual(result, 130)  # fake display ends the finite loop
        runner._reset_link.assert_called_once_with()
        runner._status.assert_any_call("RECONNECTING", "link silent")
        self.assertNotIn(
            mock.call("FAILURE", "startup connection timeout"),
            runner._status.call_args_list,
        )


class RunnerProfileTests(unittest.TestCase):
    def test_normal_receiver_proposes_baseline_before_sync(self):
        runner = bare_runner(connected=True, now=1.0)
        runner._profile_tick = Runner._profile_tick.__get__(runner)
        runner._new_profile = lambda: ProfileNegotiator("initiator", "session")
        runner._send_profile = mock.Mock()
        runner.profile = None
        runner.last_profile_send = float("-inf")
        runner.settings.preferred_profile = "baseline"
        runner._profile_tick(1.0)
        self.assertEqual(runner.profile.state, "WAIT_ACK")
        self.assertEqual(runner._send_profile.call_args.args[0]["profile_id"], "baseline")
        runner.engine.tick.assert_not_called()

    def test_explicit_profile_test_proposes_candidate_only(self):
        runner = bare_runner(connected=True, now=1.0)
        runner._profile_tick = Runner._profile_tick.__get__(runner)
        runner._new_profile = lambda: ProfileNegotiator(
            "initiator", "session", supported_profiles={"baseline", "mono-band4"},
        )
        runner._send_profile = mock.Mock()
        runner.profile = None
        runner.last_profile_send = float("-inf")
        runner.mode = "profile-test"
        runner.test_profile = "mono-band4"
        runner._profile_tick(1.0)
        self.assertEqual(runner._send_profile.call_args.args[0]["profile_id"], "mono-band4")
        self.assertEqual(runner.applied_profile, "baseline")


class SourceMutationTests(unittest.TestCase):
    def test_source_change_during_transfer_cancels_without_success_record(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            target = base / "target"
            target.mkdir()
            source = target / "payload.bin"
            source.write_bytes(b"original payload")
            ledger = Ledger(base / "ledger.json", "sender")
            report_path = base / "report.json"
            sender = SenderEngine(
                target, ledger.scope("outgoing"),
                scan_interval=0.1, stable_seconds=0.1,
                report_path=report_path,
            )
            try:
                sender.tick(0.0)
                sender.tick(1.0)
                response = sender.handle(
                    MessageKind.FILE_REQUEST,
                    json_bytes({"path": "payload.bin"}), 1.1,
                )
                self.assertEqual(response[0][0], MessageKind.FILE_META)
                source.write_bytes(b"changed payload with a different length")
                messages = sender.tick(1.2)
                self.assertIn(MessageKind.CONFLICT, [kind for kind, _ in messages])
                self.assertIsNone(sender.transfer)
                self.assertFalse(ledger.is_complete("payload.bin", "outgoing"))
                self.assertEqual(json.loads(report_path.read_text(encoding="utf-8"))["status"], "CANCELLED")
            finally:
                sender.close()


if __name__ == "__main__":
    unittest.main()
