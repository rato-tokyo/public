"""Offline checks for the banded physical frames (PD-DEC-040)."""

import unittest

import cv2
import numpy as np

from src import band_codec, wire


def band_packet(message_id: int, payload: bytes, index: int = 0, count: int = 1,
                total: int | None = None) -> wire.PhysicalPacket:
    return wire.PhysicalPacket(
        4, b"s" * 16, message_id, index, count,
        len(payload) if total is None else total, payload,
    )


def full_bands(layout: band_codec.BandLayout, seed: int) -> list[wire.PhysicalPacket]:
    rng = np.random.default_rng(seed)
    return [band_packet(seed * 10 + band, rng.bytes(layout.payload_bytes))
            for band in range(band_codec.BANDS)]


class BandLayoutTests(unittest.TestCase):
    def test_capacities_and_chunk_sizes(self):
        self.assertEqual(band_codec.MONO.band_bytes, 16_200)
        self.assertEqual(band_codec.MONO.payload_bytes, 16_132)
        self.assertEqual(band_codec.MONO.chunk_bytes, 16_000)
        self.assertEqual(band_codec.GRAY4.band_bytes, 32_400)
        self.assertEqual(band_codec.GRAY4.payload_bytes, 32_332)
        self.assertEqual(band_codec.GRAY4.chunk_bytes, 32_000)
        # A sealed FILE_DATA message of one chunk must fit one band exactly.
        for layout in band_codec.LAYOUTS.values():
            self.assertLessEqual(layout.chunk_bytes + 45, layout.payload_bytes)
        self.assertEqual(band_codec.BANDS * band_codec.BAND_ROWS, 540)

    def test_layout_lookup_rejects_unknown(self):
        self.assertIs(band_codec.layout_for("mono-band4"), band_codec.MONO)
        with self.assertRaises(ValueError):
            band_codec.layout_for("baseline")


class BandCodecTests(unittest.TestCase):
    def test_all_bands_round_trip_for_each_layout(self):
        for seed, layout in enumerate(band_codec.LAYOUTS.values(), start=1):
            packets = full_bands(layout, seed)
            image = band_codec.render_frame(layout, packets)
            self.assertEqual(image.shape, (1080, 1920, 3))
            decoded, rect = band_codec.decode_bands(image)
            self.assertEqual(decoded, packets)
            self.assertEqual(rect, band_codec.FULL_RECT)

    def test_fragmentation_and_empty(self):
        layout = band_codec.MONO
        data = b"a" * (layout.payload_bytes + 17)
        packets = band_codec.fragment_message(layout, 4, b"s" * 16, 9, data)
        self.assertEqual(len(packets), 2)
        self.assertEqual(b"".join(packet.payload for packet in packets), data)
        for packet in packets:
            raw = band_codec.encode_packet(layout, packet)
            self.assertEqual(band_codec.decode_packet(layout, raw), packet)
        empty = band_codec.fragment_message(layout, 4, b"s" * 16, 10, b"")
        self.assertEqual(len(empty), 1)
        raw = band_codec.encode_packet(layout, empty[0])
        self.assertEqual(band_codec.decode_packet(layout, raw), empty[0])

    def test_corruption_and_format_separation(self):
        packet = band_packet(7, b"hello")
        raw = bytearray(band_codec.encode_packet(band_codec.MONO, packet))
        raw[100] ^= 1
        self.assertIsNone(band_codec.decode_packet(band_codec.MONO, bytes(raw)))
        self.assertIsNone(wire.decode_packet(band_codec.encode_packet(band_codec.MONO, packet)))
        # Same size is impossible across layouts, but the magic also differs.
        self.assertNotEqual(band_codec.MONO.magic, band_codec.GRAY4.magic)
        v4_image = wire.packet_image(packet)
        self.assertEqual(band_codec.decode_bands(v4_image), ([], None))
        band_image = band_codec.render_frame(band_codec.MONO, [packet])
        self.assertEqual(wire.decode_image(band_image), (None, None))

    def test_one_damaged_band_leaves_the_others_decodable(self):
        packets = full_bands(band_codec.MONO, 3)
        image = band_codec.render_frame(band_codec.MONO, packets)
        top = 2 * band_codec.BAND_PIXEL_ROWS
        image[top + 40:top + 60] = 255 - image[top + 40:top + 60]
        decoded, _ = band_codec.decode_bands(image)
        self.assertEqual(decoded, [packets[0], packets[1], packets[3]])

    def test_torn_capture_during_staggered_repaint_loses_one_band_at_most(self):
        layout = band_codec.MONO
        old = full_bands(layout, 4)
        canvas = band_codec.render_frame(layout, old)
        before = canvas.copy()
        replacement = band_packet(99, b"new band")
        band_codec.paint_band(canvas, 1, layout, replacement)
        # Scanout tear in the middle of the band being repainted.
        tear = band_codec.BAND_PIXEL_ROWS + band_codec.BAND_PIXEL_ROWS // 2
        torn = np.vstack([canvas[:tear], before[tear:]])
        decoded, _ = band_codec.decode_bands(torn)
        self.assertEqual(decoded, [old[0], old[2], old[3]])
        decoded, _ = band_codec.decode_bands(canvas)
        self.assertEqual(decoded, [old[0], replacement, old[2], old[3]])

    def test_bands_of_different_layouts_share_one_screen(self):
        canvas = band_codec.blank_canvas()
        mono, gray = band_packet(1, b"mono"), band_packet(2, b"gray")
        band_codec.paint_band(canvas, 0, band_codec.MONO, mono)
        band_codec.paint_band(canvas, 3, band_codec.GRAY4, gray)
        decoded, _ = band_codec.decode_bands(canvas)
        self.assertEqual(decoded, [mono, gray])

    def test_paint_band_rejects_out_of_range_index(self):
        with self.assertRaises(ValueError):
            band_codec.paint_band(band_codec.blank_canvas(), band_codec.BANDS,
                                band_codec.MONO, band_packet(1, b"x"))

    def test_shifted_phase(self):
        packets = full_bands(band_codec.MONO, 5)
        image = band_codec.render_frame(band_codec.MONO, packets)
        shifted = np.zeros_like(image)
        shifted[1:, 1:] = image[:-1, :-1]
        decoded, _ = band_codec.decode_bands(shifted)
        # The last cell column/row is cut off, so the bottom band may be lost,
        # but no band may decode to wrong data.
        self.assertTrue(decoded)
        for packet in decoded:
            self.assertIn(packet, packets)

    def test_scaled_gray_band_is_rejected_not_misread(self):
        packets = full_bands(band_codec.GRAY4, 6)
        image = band_codec.render_frame(band_codec.GRAY4, packets)
        border = 20
        canvas = np.zeros_like(image)
        canvas[border:-border, border:-border] = cv2.resize(
            image, (1920 - 2 * border, 1080 - 2 * border), interpolation=cv2.INTER_AREA)
        decoded, _ = band_codec.decode_bands(canvas)
        # Resampling damages four-level symbols; CRC must reject, never accept garbage.
        for packet in decoded:
            self.assertIn(packet, packets)


if __name__ == "__main__":
    unittest.main()
