"""One-command start and capture index search; no hardware required."""

from __future__ import annotations

import io
import json
import shutil
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

from src import start as start_module
from src.build import BUILD_TEXT
from src.start import StartError, describe_probe, ensure_config, ensure_key, find_capture


ROOT = Path(__file__).resolve().parents[1]


def folder_with_templates(directory: str) -> Path:
    base = Path(directory)
    for role in ("sender", "receiver"):
        shutil.copyfile(ROOT / f"config.{role}.json", base / f"config.{role}.json")
    return base


class EnsureConfigTests(unittest.TestCase):
    def test_missing_config_is_created_from_role_template(self):
        with tempfile.TemporaryDirectory() as directory:
            base = folder_with_templates(directory)
            with redirect_stdout(io.StringIO()):
                ensure_config(base, "receiver")
            self.assertEqual(json.loads((base / "config.json").read_text(encoding="utf-8"))["role"], "receiver")

    def test_existing_config_with_other_role_is_refused_unchanged(self):
        with tempfile.TemporaryDirectory() as directory:
            base = folder_with_templates(directory)
            shutil.copyfile(base / "config.sender.json", base / "config.json")
            before = (base / "config.json").read_bytes()
            with self.assertRaisesRegex(StartError, "sender"):
                ensure_config(base, "receiver")
            self.assertEqual((base / "config.json").read_bytes(), before)

    def test_existing_config_with_same_role_is_kept(self):
        with tempfile.TemporaryDirectory() as directory:
            base = folder_with_templates(directory)
            (base / "config.json").write_text('{"role": "sender", "capture_device": 3}', encoding="utf-8")
            ensure_config(base, "sender")
            self.assertEqual(json.loads((base / "config.json").read_text(encoding="utf-8"))["capture_device"], 3)


class EnsureKeyTests(unittest.TestCase):
    def test_existing_key_is_not_asked_again(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            (base / "key.txt").write_text("shared\r\n", encoding="utf-8")
            prompt = mock.Mock()
            ensure_key(base, prompt=prompt, interactive=True)
            prompt.assert_not_called()

    def test_missing_key_without_console_is_an_error(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(StartError, "key.txt"):
                ensure_key(Path(directory), prompt=mock.Mock(), interactive=False)

    def test_password_is_saved_only_after_two_matching_entries(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            prompt = mock.Mock(side_effect=["one", "two", "shared", "shared"])
            with redirect_stdout(io.StringIO()) as output:
                ensure_key(base, prompt=prompt, interactive=True)
            self.assertEqual((base / "key.txt").read_text(encoding="utf-8"), "shared")
            self.assertNotIn("shared", output.getvalue())

    def test_repeated_mismatch_gives_up_without_a_key(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            prompt = mock.Mock(side_effect=["a", "b"] * 3)
            with redirect_stdout(io.StringIO()), self.assertRaises(StartError):
                ensure_key(base, prompt=prompt, interactive=True)
            self.assertFalse((base / "key.txt").exists())


def probe(index, *, decoded=0, foreign=0, width=1920, height=1080, reads=10, peer=None, opened=True):
    if not opened:
        return {"index": index, "opened": False}
    return {"index": index, "opened": True,
            "format": {"width": width, "height": height, "fps": 30.0, "fourcc": "YUY2"},
            "reads": reads, "decoded_frames": decoded, "foreign_version_frames": foreign,
            "mean_brightness": 100.0, "shape": [height, width, 3], "peer": peer}


class DescribeProbeTests(unittest.TestCase):
    def test_each_outcome_names_the_cause(self):
        self.assertIn("開けません", describe_probe(probe(0, opened=False)))
        self.assertIn("1920x1080ではありません", describe_probe(probe(0, width=640, height=480)))
        self.assertIn("別のバージョン", describe_probe(probe(0, foreign=3)))
        self.assertIn("PixelDuplexではありません", describe_probe(probe(0)))
        same = describe_probe(probe(1, decoded=5, peer={"role": "sender", "build": BUILD_TEXT,
                                                        "sees_its_peer": False}))
        self.assertIn("一致", same)
        other = describe_probe(probe(1, decoded=5, peer={"role": "sender", "build": "0" * 16,
                                                         "sees_its_peer": False}))
        self.assertIn("不一致", other)


class FindCaptureTests(unittest.TestCase):
    def run_find(self, base: Path, results: list[dict], *, write: bool) -> tuple[int, str]:
        by_index = {item["index"]: item for item in results}
        with mock.patch("src.app.instance_running", return_value=False), \
                mock.patch.object(start_module, "probe_capture", side_effect=lambda i: by_index[i]), \
                redirect_stdout(io.StringIO()) as output:
            code = find_capture(base, write=write, indices=sorted(by_index))
        return code, output.getvalue()

    def test_single_match_is_written_to_config(self):
        with tempfile.TemporaryDirectory() as directory:
            base = folder_with_templates(directory)
            shutil.copyfile(base / "config.receiver.json", base / "config.json")
            code, _ = self.run_find(base, [probe(0, width=640, height=480), probe(2, decoded=4)], write=True)
            self.assertEqual(code, 0)
            config = json.loads((base / "config.json").read_text(encoding="utf-8"))
            self.assertEqual(config["capture_device"], 2)
            self.assertEqual(config["role"], "receiver")
            self.assertTrue((base / "artifacts" / "reports" / "find_capture.json").exists())

    def test_only_full_hd_device_is_written_as_unconfirmed_guess(self):
        with tempfile.TemporaryDirectory() as directory:
            base = folder_with_templates(directory)
            shutil.copyfile(base / "config.receiver.json", base / "config.json")
            code, output = self.run_find(
                base, [probe(0, width=1280, height=720), probe(3), probe(4, opened=False)], write=True,
            )
            self.assertEqual(code, 3)
            self.assertIn("未確認", output)
            self.assertEqual(json.loads((base / "config.json").read_text(encoding="utf-8"))["capture_device"], 3)

    def test_no_or_many_matches_leave_config_unchanged(self):
        for results in ([probe(0), probe(1)], [probe(0, decoded=1), probe(1, decoded=1)]):
            with tempfile.TemporaryDirectory() as directory:
                base = folder_with_templates(directory)
                shutil.copyfile(base / "config.receiver.json", base / "config.json")
                before = (base / "config.json").read_bytes()
                code, _ = self.run_find(base, results, write=True)
                self.assertEqual(code, 1)
                self.assertEqual((base / "config.json").read_bytes(), before)

    def test_running_instance_is_not_disturbed(self):
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch("src.app.instance_running", return_value=True), \
                    mock.patch.object(start_module, "probe_capture") as probe_capture, \
                    redirect_stdout(io.StringIO()):
                self.assertEqual(find_capture(Path(directory)), 2)
            probe_capture.assert_not_called()


class StartTests(unittest.TestCase):
    def test_first_start_sets_capture_device_once(self):
        with tempfile.TemporaryDirectory() as directory:
            base = folder_with_templates(directory)
            (base / "key.txt").write_text("shared", encoding="utf-8")
            with mock.patch.object(start_module, "run_preflight", return_value=0), \
                    mock.patch.object(start_module, "find_capture") as finder, \
                    redirect_stdout(io.StringIO()):
                start_module.start(base, "receiver", check_only=True)
                start_module.start(base, "receiver", check_only=True)
            finder.assert_called_once_with(base, write=True)

    def test_scan_stops_at_the_first_missing_device(self):
        seen = []

        def fake(index):
            seen.append(index)
            return probe(index, opened=index < 2)

        with tempfile.TemporaryDirectory() as directory, \
                mock.patch("src.app.instance_running", return_value=False), \
                mock.patch.object(start_module, "probe_capture", side_effect=fake), \
                redirect_stdout(io.StringIO()):
            find_capture(Path(directory))
        self.assertEqual(seen, [0, 1, 2])

    def test_check_only_prepares_folder_without_running(self):
        with tempfile.TemporaryDirectory() as directory:
            base = folder_with_templates(directory)
            (base / "key.txt").write_text("shared", encoding="utf-8")
            with mock.patch.object(start_module, "run_preflight", return_value=0), \
                    mock.patch("src.app.run_command") as run_command, \
                    redirect_stdout(io.StringIO()) as output:
                code = start_module.start(base, "sender", check_only=True)
            self.assertEqual(code, 0)
            run_command.assert_not_called()
            self.assertTrue((base / "target").is_dir())
            self.assertTrue((base / "received").is_dir())
            self.assertIn(BUILD_TEXT, output.getvalue())

    def test_failed_preflight_does_not_run(self):
        with tempfile.TemporaryDirectory() as directory:
            base = folder_with_templates(directory)
            (base / "key.txt").write_text("shared", encoding="utf-8")
            with mock.patch.object(start_module, "run_preflight", return_value=2), \
                    mock.patch("src.app.run_command") as run_command, \
                    redirect_stdout(io.StringIO()):
                self.assertEqual(start_module.start(base, "receiver"), 2)
            run_command.assert_not_called()

    def test_start_scripts_call_the_shared_launcher_with_their_role(self):
        for role in ("sender", "receiver"):
            text = (ROOT / f"start-{role}.bat").read_bytes()
            self.assertIn(f"launch.bat\" start --role {role}".encode("ascii"), text)
            self.assertNotIn(b"\n", text.replace(b"\r\n", b""))  # CRLF only for cmd.exe
        finder = (ROOT / "find-capture.bat").read_bytes()
        self.assertIn(b"launch.bat\" find-capture --write", finder)
        launcher = (ROOT / "tools" / "launch.bat").read_bytes()
        for script in (finder, launcher):
            self.assertNotIn(b"\n", script.replace(b"\r\n", b""))
            self.assertTrue(script.isascii())
        self.assertIn(b"pixelduplex.py\" %*", launcher)


if __name__ == "__main__":
    unittest.main()
