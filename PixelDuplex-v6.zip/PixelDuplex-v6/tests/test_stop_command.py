"""Offline checks for ``pixelduplex.py stop`` (ISSUE-016, PD-DEC-042)."""

from __future__ import annotations

import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from src.app import InstanceLock, request_stop, stop_request_path
try:
    from test_issue002_offline import bare_runner
except ImportError:  # run as ``python -m unittest tests.test_stop_command``
    from tests.test_issue002_offline import bare_runner


class StopCommandTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.base = Path(self.directory.name)
        self.addCleanup(self.directory.cleanup)

    def test_nothing_running_leaves_no_request(self):
        with mock.patch("builtins.print"):
            self.assertEqual(request_stop(self.base, wait_seconds=1.0), 1)
        self.assertFalse(stop_request_path(self.base).exists())

    def test_running_instance_is_asked_and_stop_waits_for_it(self):
        held = threading.Event()

        def instance():
            with InstanceLock(self.base / ".pixelduplex.lock"):
                held.set()
                deadline = time.monotonic() + 5.0
                while time.monotonic() < deadline:
                    if stop_request_path(self.base).exists():
                        stop_request_path(self.base).unlink()
                        return
                    time.sleep(0.05)

        thread = threading.Thread(target=instance)
        thread.start()
        self.assertTrue(held.wait(5.0))
        with mock.patch("builtins.print"):
            result = request_stop(self.base, wait_seconds=5.0)
        thread.join(5.0)
        self.assertEqual(result, 0)
        self.assertFalse(stop_request_path(self.base).exists())

    def test_unresponsive_instance_times_out_and_keeps_the_request(self):
        with InstanceLock(self.base / ".pixelduplex.lock"):
            with mock.patch("builtins.print"):
                self.assertEqual(request_stop(self.base, wait_seconds=0.3), 2)
        self.assertTrue(stop_request_path(self.base).exists())

    def test_run_loop_ends_like_escape_on_request(self):
        runner = bare_runner(connected=True, now=0.0)
        runner.base = self.base
        runner.io.pump_display.side_effect = [True, True]
        stop_request_path(self.base).parent.mkdir(parents=True)
        stop_request_path(self.base).write_text("stop\n", encoding="ascii")
        with mock.patch("builtins.print"), \
             mock.patch("src.app.time.monotonic", return_value=1.0):
            self.assertEqual(runner.run(), 130)
        runner._status.assert_called_with("CANCELLED", "stop requested")
        self.assertFalse(stop_request_path(self.base).exists())
        runner.io.close.assert_called_once()

    def test_new_instance_clears_a_stale_request(self):
        from src import app
        stop_request_path(self.base).parent.mkdir(parents=True)
        stop_request_path(self.base).write_text("stop\n", encoding="ascii")
        seen = []

        class FakeRunner:
            def __init__(self, *_args, **_kwargs):
                seen.append(stop_request_path(self.base_path).exists())

            def run(self):
                return 0

        FakeRunner.base_path = self.base
        settings = mock.Mock(role="receiver")
        with mock.patch.object(app, "load_settings", return_value=settings), \
             mock.patch.object(app, "load_password", return_value="pw"), \
             mock.patch.object(app, "Runner", FakeRunner):
            self.assertEqual(app.run_command(self.base, "run"), 0)
        self.assertEqual(seen, [False])


if __name__ == "__main__":
    unittest.main()
