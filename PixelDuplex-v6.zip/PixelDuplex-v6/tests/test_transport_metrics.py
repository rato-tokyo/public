"""Offline transport queue telemetry; never opens the capture device."""

from __future__ import annotations

import unittest
from unittest import mock

from src.hardware import HdmiFrameIO
from src.app import Runner
from src.constants import MessageKind
from src.messages import encode_data
from src.reliable import SelectiveRepeatSender
from src.wire import PhysicalPacket


def packet(message_id: int) -> PhysicalPacket:
    return PhysicalPacket(4, b"s" * 16, message_id, 0, 1, 1, b"x")


class TransportMetricTests(unittest.TestCase):
    def test_queue_depth_delay_and_displayed_identity(self):
        io = HdmiFrameIO(0, frame_interval=0)
        first = packet(1)
        second = packet(2)
        with mock.patch("src.hardware.time.monotonic", side_effect=[1.0, 2.0, 3.0, 4.0, 5.0]):
            io.send([first, second])
            io.send([first], priority=True)
            with mock.patch("src.hardware.packet_image", return_value=object()), \
                 mock.patch("src.hardware.cv2.imshow"), \
                 mock.patch("src.hardware.cv2.waitKey", return_value=-1):
                self.assertTrue(io.pump_display())
                self.assertTrue(io.pump_display())
                self.assertTrue(io.pump_display())
        metrics = io.display_metrics()
        self.assertEqual(metrics["outgoing_queue_depth"], 0)
        self.assertEqual(metrics["outgoing_queue_high_watermark"], 3)
        self.assertEqual(metrics["displayed_unique_frames"], 2)
        self.assertEqual(metrics["displayed_duplicate_frames"], 1)
        self.assertAlmostEqual(metrics["display_delay_seconds_mean"], 8 / 3)
        self.assertEqual(metrics["display_delay_seconds_max"], 4.0)

    def test_clear_outgoing_clears_timestamps_too(self):
        io = HdmiFrameIO(0)
        io.send([packet(1)])
        io.clear_outgoing()
        self.assertEqual(io.display_metrics()["outgoing_queue_depth"], 0)
        self.assertEqual(len(io._outgoing), 0)

    def test_callback_runs_only_after_last_fragment_displayed(self):
        io = HdmiFrameIO(0, frame_interval=0)
        observed = []
        io.send([packet(1), packet(2)], on_display=observed.append)
        with mock.patch("src.hardware.packet_image", return_value=object()), \
             mock.patch("src.hardware.cv2.imshow"), \
             mock.patch("src.hardware.cv2.waitKey", return_value=-1):
            io.pump_display()
            self.assertEqual(observed, [])
            io.pump_display()
        self.assertEqual(len(observed), 1)

    def test_file_chunk_retry_clock_starts_from_display_callback(self):
        runner = Runner.__new__(Runner)
        runner.io = mock.Mock()
        runner.link = mock.Mock()
        runner.link.secure.return_value = [packet(1)]
        runner.engine = mock.Mock()
        runner.diagnostic = mock.Mock()
        transfer_id = b"t" * 16
        reliable = SelectiveRepeatSender(1, 1, 1.0)
        self.assertEqual([item.index for item in reliable.due(0)], [0])
        runner.engine.outbound.transfer = mock.Mock(transfer_id=transfer_id, reliable=reliable)
        runner._send_app([(MessageKind.FILE_DATA, encode_data(transfer_id, 0, b"data"))])
        callback = runner.io.send.call_args.kwargs["on_display"]
        self.assertIsNotNone(callback)
        self.assertEqual(reliable.due(10), [])
        callback(10)
        self.assertEqual(reliable.due(10.9), [])
        self.assertEqual([item.index for item in reliable.due(11.0)], [0])

    def test_blob_chunk_uses_its_own_display_clock(self):
        runner = Runner.__new__(Runner)
        runner.io = mock.Mock()
        runner.link = mock.Mock()
        runner.link.secure.return_value = [packet(1)]
        runner.engine = mock.Mock()
        runner.diagnostic = mock.Mock()
        transfer_id = b"b" * 16
        reliable = SelectiveRepeatSender(1, 1, 1.0)
        reliable.due(0)
        runner.diagnostic.send = mock.Mock(transfer_id=transfer_id, reliable=reliable)
        runner._send_app([(MessageKind.BLOB_DATA, encode_data(transfer_id, 0, b"data"))])
        runner.io.send.call_args.kwargs["on_display"](5.0)
        self.assertEqual(reliable.due(5.9), [])
        self.assertEqual([item.index for item in reliable.due(6.0)], [0])


if __name__ == "__main__":
    unittest.main()
