"""Hardware-independent tests for the v6 connection diagnostics (commit 118e23d).

Covers the presence beacon, build ID, foreign-version frame detection, the
diagnosis rules, the main-loop watchdog, and the capture worker statistics.
"""

from __future__ import annotations

import faulthandler
import os
import re
import tempfile
import threading
import types
import unittest
from collections import deque
from pathlib import Path
from unittest import mock

import numpy as np

from src import build as build_module
from src import hardware
from src.build import BUILD_ID, BUILD_ID_BYTES, BUILD_TEXT, compute_build_id
from src.constants import HEIGHT, PROTOCOL_VERSION, WIDTH, PhysicalKind
from src.diagnosis import (
    BLACK_MEAN, SLOW_HANDSHAKE_SECONDS, STALE_SECONDS, diagnose, diagnose_error,
    facts_line,
)
from src.handshake import (
    BEACON, EMPTY_NONCE, FLAG_HEARD, HEARD_SECONDS, NONCE_BYTES, ROLE_ID,
    BuildMismatchError, Handshake, HandshakeError, Presence,
)
from src.hardware import HdmiFrameIO, NO_DECODE_REOPEN_SECONDS
from src.link import LinkSession
from src.watchdog import PAUSE_REPORT_SECONDS, LoopWatchdog
from src.wire import (
    PhysicalPacket, decode_image_detail, decode_packet, encode_packet,
    inspect_packet, packet_image,
)


PASSWORD = "shared password"


def unpack_beacon(outgoing) -> dict:
    fields = BEACON.unpack(outgoing.payload)
    names = ("version", "role", "flags", "session", "salt", "challenge",
             "build", "nonce", "heard_nonce")
    return dict(zip(names, fields))


def deliver_beacon(target: Handshake, source: Handshake, now: float):
    outgoing = source.beacon(now)
    return target.receive_plain(outgoing.physical_kind, outgoing.session_id,
                                outgoing.payload, now)


# ---------------------------------------------------------------- handshake


class PresenceTests(unittest.TestCase):
    def test_hears_peer_only_within_heard_seconds(self):
        presence = Presence()
        self.assertFalse(presence.hears_peer(0.0))
        presence.peer_frame(10.0)
        self.assertTrue(presence.hears_peer(10.0))
        self.assertTrue(presence.hears_peer(10.0 + HEARD_SECONDS))
        self.assertFalse(presence.hears_peer(10.0 + HEARD_SECONDS + 0.01))

    def test_as_dict_before_anything_is_seen(self):
        presence = Presence()
        self.assertEqual(len(presence.nonce), NONCE_BYTES)
        self.assertEqual(presence.as_dict(5.0), {
            "we_see_peer": False,
            "peer_sees_us": None,
            "last_peer_frame_age_seconds": None,
            "last_peer_beacon_age_seconds": None,
            "own_screen_seen_age_seconds": None,
            "peer_role": None,
            "peer_build": None,
            "peer_process_restarts": 0,
        })

    def test_as_dict_reports_rounded_ages(self):
        presence = Presence(b"n" * NONCE_BYTES)
        self.assertEqual(presence.nonce, b"n" * NONCE_BYTES)
        presence.peer_frame(1.0)
        presence.own_beacon_seen_at = 2.0
        state = presence.as_dict(3.26)
        self.assertEqual(state["last_peer_frame_age_seconds"], 2.3)
        self.assertEqual(state["own_screen_seen_age_seconds"], 1.3)
        self.assertTrue(state["we_see_peer"])


class BeaconTests(unittest.TestCase):
    def setUp(self):
        self.sender = Handshake("sender", PASSWORD)
        self.receiver = Handshake("receiver", PASSWORD)

    def test_beacon_layout(self):
        outgoing = self.receiver.beacon(0.0)
        self.assertEqual(outgoing.physical_kind, PhysicalKind.BEACON)
        self.assertEqual(outgoing.session_id, self.receiver.session_id)
        self.assertEqual(len(outgoing.payload), BEACON.size)
        fields = unpack_beacon(outgoing)
        self.assertEqual(fields["version"], PROTOCOL_VERSION)
        self.assertEqual(fields["role"], ROLE_ID["receiver"])
        self.assertEqual(fields["flags"], 0)
        self.assertEqual(fields["build"], BUILD_ID)
        self.assertEqual(fields["nonce"], self.receiver.presence.nonce)
        self.assertEqual(fields["heard_nonce"], EMPTY_NONCE)
        self.assertEqual(fields["session"], self.receiver.session_id)
        self.assertEqual(fields["salt"], self.receiver.salt)
        self.assertEqual(fields["challenge"], self.receiver.receiver_challenge)

    def test_peer_beacon_sets_heard_flag_and_heard_nonce(self):
        response = deliver_beacon(self.sender, self.receiver, 1.0)
        self.assertEqual(response.physical_kind, PhysicalKind.AUTH)
        self.assertEqual(self.sender.state, "WAIT_READY")
        fields = unpack_beacon(self.sender.beacon(1.5))
        self.assertTrue(fields["flags"] & FLAG_HEARD)
        self.assertEqual(fields["heard_nonce"], self.receiver.presence.nonce)
        presence = self.sender.presence
        self.assertEqual(presence.peer_role, "receiver")
        self.assertEqual(presence.peer_build, BUILD_TEXT)
        self.assertEqual(presence.last_peer_beacon_at, 1.0)
        # The receiver's beacon was packed before it heard the sender.
        self.assertIs(presence.peer_hears_us, False)

    def test_peer_sees_us_after_peer_heard_our_beacon(self):
        # The receiver hears the sender first; its reply beacon then carries
        # the heard flag with the sender's nonce.
        reply = deliver_beacon(self.receiver, self.sender, 1.0)
        self.assertEqual(reply.physical_kind, PhysicalKind.BEACON)
        fields = unpack_beacon(reply)
        self.assertTrue(fields["flags"] & FLAG_HEARD)
        self.assertEqual(fields["heard_nonce"], self.sender.presence.nonce)
        self.sender.receive_plain(reply.physical_kind, reply.session_id,
                                  reply.payload, 1.1)
        self.assertIs(self.sender.presence.peer_hears_us, True)
        self.assertIs(self.sender.presence.as_dict(1.2)["peer_sees_us"], True)

    def test_heard_flag_with_foreign_heard_nonce_is_not_us(self):
        payload = BEACON.pack(
            PROTOCOL_VERSION, ROLE_ID["receiver"], FLAG_HEARD,
            self.receiver.session_id, self.receiver.salt,
            self.receiver.receiver_challenge, BUILD_ID,
            self.receiver.presence.nonce, b"x" * NONCE_BYTES,
        )
        self.sender.receive_plain(PhysicalKind.BEACON, self.receiver.session_id, payload, 0.0)
        self.assertIs(self.sender.presence.peer_hears_us, False)

    def test_heard_flag_expires_after_heard_seconds(self):
        deliver_beacon(self.receiver, self.sender, 10.0)
        self.assertTrue(unpack_beacon(self.receiver.beacon(10.0 + HEARD_SECONDS))["flags"] & FLAG_HEARD)
        late = unpack_beacon(self.receiver.beacon(10.0 + HEARD_SECONDS + 0.5))
        self.assertFalse(late["flags"] & FLAG_HEARD)

    def test_own_beacon_is_recorded_and_does_not_advance(self):
        for handshake in (self.sender, self.receiver):
            response = deliver_beacon(handshake, handshake, 2.0)
            self.assertIsNone(response)
            self.assertEqual(handshake.state, "CONNECTING")
            self.assertEqual(handshake.presence.own_beacon_seen_at, 2.0)
            self.assertIsNone(handshake.presence.last_peer_frame_at)
            self.assertIsNone(handshake.presence.peer_role)
            self.assertEqual(handshake.presence.peer_nonce, EMPTY_NONCE)

    def test_same_role_beacon_raises(self):
        for role in ("sender", "receiver"):
            with self.subTest(role=role):
                one, two = Handshake(role, PASSWORD), Handshake(role, PASSWORD)
                with self.assertRaises(HandshakeError) as caught:
                    deliver_beacon(one, two, 0.0)
                self.assertNotIsInstance(caught.exception, BuildMismatchError)
                self.assertEqual(diagnose_error(str(caught.exception)).code, "SAME_ROLE")
                # The observation is still recorded for the diagnosis.
                self.assertEqual(one.presence.peer_role, role)

    def test_other_build_raises_build_mismatch(self):
        other_build = bytes(b ^ 0xFF for b in BUILD_ID)
        payload = BEACON.pack(
            PROTOCOL_VERSION, ROLE_ID["receiver"], 0,
            self.receiver.session_id, self.receiver.salt,
            self.receiver.receiver_challenge, other_build,
            self.receiver.presence.nonce, EMPTY_NONCE,
        )
        with self.assertRaises(BuildMismatchError) as caught:
            self.sender.receive_plain(PhysicalKind.BEACON, self.receiver.session_id, payload, 0.0)
        self.assertIn(other_build.hex(), str(caught.exception))
        self.assertEqual(self.sender.presence.peer_build, other_build.hex())
        self.assertEqual(self.sender.state, "CONNECTING")
        self.assertEqual(diagnose_error(str(caught.exception)).code, "BUILD_MISMATCH")

    def test_short_beacon_is_ignored(self):
        self.assertIsNone(self.sender.receive_plain(PhysicalKind.BEACON, b"\0" * 16, b"short", 0.0))
        self.assertIsNone(self.sender.presence.last_peer_frame_at)

    def test_new_peer_nonce_counts_a_restart(self):
        deliver_beacon(self.receiver, self.sender, 0.0)
        restarted = Handshake("sender", PASSWORD)
        deliver_beacon(self.receiver, restarted, 1.0)
        self.assertEqual(self.receiver.presence.peer_restarts, 1)
        self.assertEqual(self.receiver.presence.peer_nonce, restarted.presence.nonce)
        deliver_beacon(self.receiver, restarted, 2.0)
        self.assertEqual(self.receiver.presence.peer_restarts, 1)

    def test_presence_is_shared_across_handshakes(self):
        presence = Presence()
        first = Handshake("sender", PASSWORD, presence)
        second = Handshake("sender", PASSWORD, presence)
        self.assertIs(second.presence, first.presence)
        self.assertEqual(unpack_beacon(second.beacon(0.0))["nonce"], presence.nonce)


# --------------------------------------------------------------------- link


def exchange(sender: LinkSession, receiver: LinkSession, steps: int = 30,
             on_step=None, step_seconds: float = 0.6) -> float:
    """Pass physical packets both ways with explicit clocks until connected."""
    to_sender: list[PhysicalPacket] = []
    to_receiver: list[PhysicalPacket] = []
    for step in range(steps):
        now = step * step_seconds
        to_receiver.extend(sender.periodic(now))
        to_sender.extend(receiver.periodic(now))
        while to_sender or to_receiver:
            while to_sender:
                outgoing, _ = sender.receive(to_sender.pop(0), now)
                to_receiver.extend(outgoing)
            while to_receiver:
                outgoing, _ = receiver.receive(to_receiver.pop(0), now)
                to_sender.extend(outgoing)
        if on_step is not None:
            on_step(step, now)
        if sender.connected and receiver.connected:
            return now
    raise AssertionError("test handshake did not connect")


class LinkPresenceTests(unittest.TestCase):
    def test_two_links_connect_and_see_each_other(self):
        sender = LinkSession("sender", PASSWORD)
        receiver = LinkSession("receiver", PASSWORD)
        snapshots = []
        now = exchange(sender, receiver, on_step=lambda step, t: snapshots.append(
            (sender.presence.as_dict(t), receiver.presence.as_dict(t))))
        self.assertTrue(sender.connected and receiver.connected)
        self.assertEqual(sender.authentication_failures, 0)
        self.assertEqual(receiver.authentication_failures, 0)
        sender_view, receiver_view = sender.presence.as_dict(now), receiver.presence.as_dict(now)
        self.assertTrue(sender_view["we_see_peer"])
        self.assertTrue(receiver_view["we_see_peer"])
        self.assertEqual(sender_view["peer_role"], "receiver")
        self.assertEqual(receiver_view["peer_role"], "sender")
        self.assertEqual(sender_view["peer_build"], BUILD_TEXT)
        self.assertEqual(receiver_view["peer_build"], BUILD_TEXT)
        self.assertIsNone(sender_view["own_screen_seen_age_seconds"])
        self.assertEqual(sender_view["peer_process_restarts"], 0)
        # The receiver answers every sender beacon with a beacon packed after
        # hearing it, so the sender learns that the receiver sees it.
        self.assertIs(sender_view["peer_sees_us"], True)
        self.assertTrue(snapshots)
        self.assertTrue(all(s["we_see_peer"] and r["we_see_peer"] for s, r in snapshots))

    def test_key_mismatch_is_detected_by_receiver(self):
        sender = LinkSession("sender", PASSWORD)
        receiver = LinkSession("receiver", "other password")
        with self.assertRaises(HandshakeError) as caught:
            exchange(sender, receiver, steps=5)
        self.assertIn("AUTHENTICATION_FAILED", str(caught.exception))
        self.assertEqual(diagnose_error(str(caught.exception)).code, "KEY_MISMATCH")

    def test_one_way_video_is_reported_on_the_side_that_sees(self):
        # Only receiver -> sender works: the sender sees beacons without the
        # heard flag and blames the path towards the receiver.
        sender = LinkSession("sender", PASSWORD)
        receiver = LinkSession("receiver", PASSWORD)
        for step in range(5):
            now = step * 0.6
            sender.periodic(now)  # lost on the way
            for packet in receiver.periodic(now):
                sender.receive(packet, now)
        view = sender.presence.as_dict(now)
        self.assertTrue(view["we_see_peer"])
        self.assertIs(view["peer_sees_us"], False)
        self.assertEqual(diagnose(
            role="sender", handshake_state=sender.handshake.state,
            capture=healthy_capture(), presence=view,
        ).code, "PEER_DOES_NOT_SEE_US")
        # The receiver never saw anything.
        self.assertEqual(diagnose(
            role="receiver", handshake_state=receiver.handshake.state,
            capture=healthy_capture(), presence=receiver.presence.as_dict(now),
        ).code, "PEER_SCREEN_NOT_SEEN")

    # The sender stops beaconing after WAIT_READY, so AUTH itself must prove
    # that the sender sees the receiver.
    def test_receiver_in_handshake_is_not_told_that_peer_does_not_see_it(self):
        sender = LinkSession("sender", PASSWORD)
        receiver = LinkSession("receiver", PASSWORD)
        # Both start at once: the sender's first beacon (not yet heard the
        # receiver) reaches the receiver, then the receiver's beacon reaches
        # the sender, which answers with AUTH. The sender's encrypted PING is
        # lost, so the receiver stays in WAIT_PING.
        now = 0.0
        sender_beacon = sender.periodic(now)
        receiver_beacon = receiver.periodic(now)
        for packet in sender_beacon:
            receiver.receive(packet, now)
        auth = []
        for packet in receiver_beacon:
            auth.extend(sender.receive(packet, now)[0])
        self.assertTrue(auth and all(p.kind == PhysicalKind.AUTH for p in auth))
        for packet in auth:
            receiver.receive(packet, now)  # READY back is not needed here
        now = 1.0
        for packet in sender.periodic(now):  # repeats AUTH while WAIT_READY
            receiver.receive(packet, now)
        self.assertEqual(receiver.handshake.state, "WAIT_PING")
        self.assertEqual(sender.handshake.state, "WAIT_READY")
        code = diagnose(
            role="receiver", handshake_state=receiver.handshake.state,
            capture=healthy_capture(), presence=receiver.presence.as_dict(now),
        ).code
        self.assertEqual(code, "HANDSHAKE_IN_PROGRESS")


# --------------------------------------------------------------------- wire


class ForeignVersionFrameTests(unittest.TestCase):
    PACKET = PhysicalPacket(PhysicalKind.BEACON, b"s" * 16, 3, 0, 1, 5, b"hello")

    def foreign(self, version: int):
        with mock.patch("src.wire.PROTOCOL_VERSION", version):
            return encode_packet(self.PACKET), packet_image(self.PACKET)

    def test_current_version_decodes(self):
        raw = encode_packet(self.PACKET)
        self.assertEqual(inspect_packet(raw), (self.PACKET, None))
        packet, rect, foreign = decode_image_detail(packet_image(self.PACKET))
        self.assertEqual(packet, self.PACKET)
        self.assertIsNotNone(rect)
        self.assertIsNone(foreign)

    def test_other_version_frame_is_reported_not_decoded(self):
        for version in (PROTOCOL_VERSION - 1, PROTOCOL_VERSION + 1):
            with self.subTest(version=version):
                raw, image = self.foreign(version)
                self.assertEqual(inspect_packet(raw), (None, version))
                self.assertIsNone(decode_packet(raw))
                self.assertEqual(decode_image_detail(image), (None, None, version))

    def test_damaged_or_unrelated_frame_is_not_foreign(self):
        raw, _image = self.foreign(PROTOCOL_VERSION - 1)
        broken = bytearray(raw)
        broken[100] ^= 0xFF
        self.assertEqual(inspect_packet(bytes(broken)), (None, None))
        self.assertEqual(inspect_packet(raw[:-1]), (None, None))
        self.assertEqual(decode_image_detail(np.zeros((HEIGHT, WIDTH, 3), np.uint8)),
                         (None, None, None))
        self.assertEqual(decode_image_detail(np.zeros((10, 10, 3), np.uint8)),
                         (None, None, None))


# ---------------------------------------------------------------- diagnosis


def healthy_capture(**changes) -> dict:
    capture = {
        "device": 1,
        "format": {"width": WIDTH, "height": HEIGHT, "fps": 30.0, "fourcc": "YUY2"},
        "worker_alive": True,
        "reads": 100,
        "reads_per_second": 10.0,
        "last_read_age_seconds": 0.1,
        "decoded_frames": 50,
        "last_frame_shape": [HEIGHT, WIDTH, 3],
        "last_frame_mean_brightness": 120.0,
        "foreign_version_frames": 0,
        "last_foreign_version": None,
        "worker_errors": 0,
        "last_worker_error": None,
        "reopens": 0,
    }
    capture.update(changes)
    return capture


def healthy_presence(**changes) -> dict:
    presence = {
        "we_see_peer": True,
        "peer_sees_us": True,
        "last_peer_frame_age_seconds": 0.5,
        "last_peer_beacon_age_seconds": 0.5,
        "own_screen_seen_age_seconds": None,
        "peer_role": "receiver",
        "peer_build": BUILD_TEXT,
        "peer_process_restarts": 0,
    }
    presence.update(changes)
    return presence


def code(capture=None, presence=None, **kwargs) -> str:
    kwargs.setdefault("role", "sender")
    kwargs.setdefault("handshake_state", "CONNECTING")
    return diagnose(
        capture=healthy_capture() if capture is None else capture,
        presence=healthy_presence() if presence is None else presence,
        **kwargs,
    ).code


class DiagnoseCodeTests(unittest.TestCase):
    def test_each_code_for_its_observation(self):
        cases = {
            "CAPTURE_WORKER_STOPPED": dict(capture=healthy_capture(
                worker_alive=False, last_worker_error="RuntimeError: boom")),
            "CAPTURE_NOT_READING": dict(capture=healthy_capture(last_read_age_seconds=None)),
            "CAPTURE_WRONG_MODE": dict(capture=healthy_capture(last_frame_shape=[480, 640, 3])),
            "OWN_SCREEN_CAPTURED": dict(presence=healthy_presence(own_screen_seen_age_seconds=1.0)),
            "PEER_OTHER_VERSION": dict(
                capture=healthy_capture(foreign_version_frames=3, last_foreign_version=5),
                presence=healthy_presence(last_peer_frame_age_seconds=None)),
            "CAPTURE_BLACK": dict(
                capture=healthy_capture(last_frame_mean_brightness=BLACK_MEAN - 1),
                presence=healthy_presence(last_peer_frame_age_seconds=None)),
            "PEER_SCREEN_NOT_SEEN": dict(presence=healthy_presence(
                last_peer_frame_age_seconds=None, peer_sees_us=None)),
            "PEER_SCREEN_LOST": dict(presence=healthy_presence(
                last_peer_frame_age_seconds=STALE_SECONDS + 10)),
            "PEER_DOES_NOT_SEE_US": dict(presence=healthy_presence(peer_sees_us=False)),
            "KEY_MISMATCH": dict(last_handshake_error="AUTHENTICATION_FAILED: key mismatch or damaged link"),
            "SAME_ROLE": dict(last_handshake_error="both endpoints are configured as sender"),
            "BUILD_MISMATCH": dict(last_handshake_error="peer runs build aa, this PC runs bb"),
            "HANDSHAKE_SLOW": dict(handshake_seconds=SLOW_HANDSHAKE_SECONDS,
                                   authentication_failures=4),
            "HANDSHAKE_IN_PROGRESS": dict(handshake_seconds=SLOW_HANDSHAKE_SECONDS - 1),
        }
        for expected, kwargs in cases.items():
            with self.subTest(expected=expected):
                self.assertEqual(code(**kwargs), expected)

    def test_summaries_and_actions_are_text(self):
        result = diagnose(role="receiver", handshake_state="WAIT_PING",
                          capture=healthy_capture(),
                          presence=healthy_presence(last_peer_frame_age_seconds=20.0))
        self.assertEqual(result.code, "PEER_SCREEN_LOST")
        self.assertIn("送信側", result.summary)
        self.assertIn("20", result.summary)
        self.assertEqual(set(result.as_dict()), {"code", "summary", "action"})
        self.assertIn("受信側", diagnose(
            role="sender", handshake_state="CONNECTING", capture=healthy_capture(),
            presence=healthy_presence(last_peer_frame_age_seconds=None)).summary)
        slow = diagnose(role="sender", handshake_state="WAIT_READY",
                        capture=healthy_capture(), presence=healthy_presence(),
                        handshake_seconds=45.0, authentication_failures=3)
        self.assertIn("WAIT_READY", slow.summary)
        self.assertIn("3", slow.summary)

    def test_priority_order(self):
        everything_wrong_capture = healthy_capture(
            worker_alive=False, last_read_age_seconds=None,
            last_frame_shape=[480, 640, 3], foreign_version_frames=2,
            last_frame_mean_brightness=0.0,
        )
        everything_wrong_presence = healthy_presence(
            own_screen_seen_age_seconds=0.0, last_peer_frame_age_seconds=None,
            peer_sees_us=False,
        )
        order = [
            ("worker_alive", True, "CAPTURE_WORKER_STOPPED"),
            ("last_read_age_seconds", 0.1, "CAPTURE_NOT_READING"),
            ("last_frame_shape", [HEIGHT, WIDTH, 3], "CAPTURE_WRONG_MODE"),
        ]
        capture = dict(everything_wrong_capture)
        presence = dict(everything_wrong_presence)
        kwargs = dict(last_handshake_error="AUTHENTICATION_FAILED", handshake_seconds=99.0)
        for key, fixed, expected in order:
            with self.subTest(expected=expected):
                self.assertEqual(code(capture, presence, **kwargs), expected)
            capture[key] = fixed
        self.assertEqual(code(capture, presence, **kwargs), "OWN_SCREEN_CAPTURED")
        presence["own_screen_seen_age_seconds"] = STALE_SECONDS + 1  # old: ignored
        self.assertEqual(code(capture, presence, **kwargs), "PEER_OTHER_VERSION")
        capture["foreign_version_frames"] = 0
        self.assertEqual(code(capture, presence, **kwargs), "CAPTURE_BLACK")
        capture["last_frame_mean_brightness"] = 100.0
        self.assertEqual(code(capture, presence, **kwargs), "PEER_SCREEN_NOT_SEEN")
        presence["last_peer_frame_age_seconds"] = 0.2
        self.assertEqual(code(capture, presence, **kwargs), "PEER_DOES_NOT_SEE_US")
        presence["peer_sees_us"] = None  # unknown is not "does not see"
        self.assertEqual(code(capture, presence, **kwargs), "KEY_MISMATCH")
        kwargs["last_handshake_error"] = None
        self.assertEqual(code(capture, presence, **kwargs), "HANDSHAKE_SLOW")
        kwargs["handshake_seconds"] = None
        self.assertEqual(code(capture, presence, **kwargs), "HANDSHAKE_IN_PROGRESS")

    def test_boundaries(self):
        self.assertEqual(code(capture=healthy_capture(last_read_age_seconds=STALE_SECONDS)),
                         "HANDSHAKE_IN_PROGRESS")
        self.assertEqual(code(capture=healthy_capture(last_read_age_seconds=STALE_SECONDS + 0.1)),
                         "CAPTURE_NOT_READING")
        # A tuple shape and a shape without channels are both accepted.
        self.assertEqual(code(capture=healthy_capture(last_frame_shape=(HEIGHT, WIDTH))),
                         "HANDSHAKE_IN_PROGRESS")
        self.assertEqual(code(capture=healthy_capture(last_frame_shape=None)),
                         "HANDSHAKE_IN_PROGRESS")
        # Foreign frames while the peer is also seen: the peer is current.
        self.assertEqual(code(capture=healthy_capture(foreign_version_frames=9)),
                         "HANDSHAKE_IN_PROGRESS")
        # A black mean only matters when the peer is not seen.
        self.assertEqual(code(capture=healthy_capture(last_frame_mean_brightness=0.0)),
                         "HANDSHAKE_IN_PROGRESS")
        # Unknown brightness falls through to the not-seen diagnosis.
        self.assertEqual(code(capture=healthy_capture(last_frame_mean_brightness=None),
                              presence=healthy_presence(last_peer_frame_age_seconds=None)),
                         "PEER_SCREEN_NOT_SEEN")
        self.assertEqual(code(presence=healthy_presence(own_screen_seen_age_seconds=STALE_SECONDS)),
                         "OWN_SCREEN_CAPTURED")

    def test_empty_inputs_do_not_raise(self):
        self.assertEqual(code(capture={}, presence={}), "CAPTURE_NOT_READING")
        self.assertEqual(code(capture=healthy_capture(), presence={}), "PEER_SCREEN_NOT_SEEN")


class DiagnoseErrorTests(unittest.TestCase):
    def test_classification(self):
        same = diagnose_error("both endpoints are configured as receiver")
        self.assertEqual(same.code, "SAME_ROLE")
        self.assertIn("receiver", same.summary)
        self.assertEqual(diagnose_error("peer runs build 00, this PC runs 11").code,
                         "BUILD_MISMATCH")
        self.assertEqual(diagnose_error("AUTHENTICATION_FAILED: key mismatch").code,
                         "KEY_MISMATCH")
        other = diagnose_error("something else")
        self.assertEqual(other.code, "HANDSHAKE_ERROR")
        self.assertIn("something else", other.summary)

    def test_accepts_exceptions(self):
        self.assertEqual(diagnose_error(HandshakeError("both endpoints are configured as sender")).code,
                         "SAME_ROLE")


class FactsLineTests(unittest.TestCase):
    def test_never_raises(self):
        inputs = [
            ({}, {}),
            (healthy_capture(), healthy_presence()),
            (healthy_capture(format=None, last_frame_shape=[1], reads_per_second=None),
             healthy_presence(peer_sees_us=None, peer_build=None)),
            (healthy_capture(), healthy_presence(peer_sees_us=False, we_see_peer=False)),
        ]
        for capture, presence in inputs:
            with self.subTest(capture=capture, presence=presence):
                self.assertIsInstance(facts_line(capture, presence), str)

    def test_content(self):
        line = facts_line(healthy_capture(), healthy_presence())
        self.assertIn(f"{WIDTH}x{HEIGHT}", line)
        self.assertIn("YUY2", line)
        self.assertIn(BUILD_TEXT, line)
        self.assertIn("未取得", facts_line({}, {}))
        self.assertIn("不明", facts_line({}, {}))
        self.assertIn("受信できていない", facts_line({}, {"peer_sees_us": False}))


# ----------------------------------------------------------------- watchdog


class LoopWatchdogTests(unittest.TestCase):
    def test_beat_reports_long_pauses(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "logs" / "hang.log"
            watchdog = LoopWatchdog(path)
            watchdog.start()
            try:
                self.assertIsNone(watchdog.beat(100.0))
                self.assertIsNone(watchdog.beat(100.5))
                self.assertAlmostEqual(watchdog.max_pause_seconds, 0.5)
                pause = watchdog.beat(100.5 + PAUSE_REPORT_SECONDS + 0.5)
                self.assertAlmostEqual(pause, PAUSE_REPORT_SECONDS + 0.5)
                self.assertEqual(watchdog.long_pauses, 1)
                self.assertAlmostEqual(watchdog.max_pause_seconds, PAUSE_REPORT_SECONDS + 0.5)
                self.assertIsNone(watchdog.beat(104.5))
                self.assertAlmostEqual(watchdog.max_pause_seconds, PAUSE_REPORT_SECONDS + 0.5)
            finally:
                watchdog.stop()
            self.assertIsNone(watchdog._stream)
            self.assertIn("watchdog armed", path.read_text(encoding="utf-8"))
            watchdog.stop()  # idempotent

    def test_beat_without_start_never_arms_faulthandler(self):
        watchdog = LoopWatchdog(Path("unused") / "hang.log")
        with mock.patch.object(faulthandler, "dump_traceback_later") as arm:
            self.assertIsNone(watchdog.beat(0.0))
            self.assertEqual(watchdog.beat(10.0), 10.0)
        arm.assert_not_called()
        watchdog.stop()

    def test_rearm_is_rate_limited(self):
        with tempfile.TemporaryDirectory() as directory:
            watchdog = LoopWatchdog(Path(directory) / "hang.log")
            watchdog.start()
            try:
                with mock.patch.object(faulthandler, "dump_traceback_later") as arm:
                    for step in range(10):
                        watchdog.beat(step * 0.25)  # 0 .. 2.25 s
                    self.assertEqual(arm.call_count, 3)  # at 0, 1.0 and 2.0 s
            finally:
                watchdog.stop()

    def test_unwritable_log_path_is_tolerated(self):
        with tempfile.TemporaryDirectory() as directory:
            blocker = Path(directory) / "file"
            blocker.write_text("x", encoding="utf-8")
            watchdog = LoopWatchdog(blocker / "hang.log")
            watchdog.start()
            self.assertIsNone(watchdog._stream)
            self.assertIsNone(watchdog.beat(0.0))
            watchdog.stop()


# ----------------------------------------------------------------- hardware


class _ScriptedCapture:
    """read() results in order; an Exception instance is raised instead."""

    def __init__(self, owner: HdmiFrameIO, reads):
        self.owner = owner
        self.reads = deque(reads)

    def read(self):
        if self.reads:
            item = self.reads.popleft()
            if isinstance(item, BaseException):
                raise item
            return item
        self.owner._stop.set()
        return False, None


def frame(value: int = 100):
    return np.full((8, 8, 3), value, dtype=np.uint8)


class CaptureStatsTests(unittest.TestCase):
    PACKET = PhysicalPacket(PhysicalKind.SECURE, b"s" * 16, 1, 0, 1, 1, b"x")

    def run_loop(self, io: HdmiFrameIO, reads, decoded):
        io._capture = _ScriptedCapture(io, reads)
        with mock.patch("src.hardware.decode_image_detail", side_effect=decoded):
            io._capture_loop()

    def test_metrics_before_any_read(self):
        io = HdmiFrameIO(3)
        metrics = io.capture_metrics(10.0)
        self.assertEqual(metrics["device"], 3)
        self.assertTrue(metrics["worker_alive"])
        self.assertEqual(metrics["reads"], 0)
        self.assertIsNone(metrics["last_read_age_seconds"])
        self.assertIsNone(metrics["last_frame_shape"])
        self.assertEqual(metrics["foreign_version_frames"], 0)
        self.assertEqual(code(capture=metrics), "CAPTURE_NOT_READING")

    def test_metrics_ages_and_copies(self):
        io = HdmiFrameIO(1)
        io.stats.last_read_at = 9.0
        io.stats.last_decoded_at = 7.55
        io.stats.last_frame_shape = (HEIGHT, WIDTH, 3)
        io.stats.format = {"fourcc": "YUY2"}
        metrics = io.capture_metrics(10.0)
        self.assertEqual(metrics["last_read_age_seconds"], 1.0)
        self.assertEqual(metrics["last_decoded_age_seconds"], 2.5)
        self.assertEqual(metrics["last_frame_shape"], [HEIGHT, WIDTH, 3])
        metrics["format"]["fourcc"] = "MJPG"
        self.assertEqual(io.stats.format["fourcc"], "YUY2")

    def test_dead_worker_is_reported(self):
        io = HdmiFrameIO(1)
        thread = threading.Thread(target=lambda: None)
        thread.start()
        thread.join()
        io._thread = thread
        self.assertFalse(io.capture_alive())
        metrics = io.capture_metrics(0.0)
        self.assertIs(metrics["worker_alive"], False)
        self.assertEqual(code(capture=metrics), "CAPTURE_WORKER_STOPPED")

    def test_reads_decoded_and_foreign_frames_are_counted(self):
        io = HdmiFrameIO(1)
        reads = [(True, frame(100)), (True, frame(0)), (True, frame(50)), (True, frame(60))]
        decoded = [
            (self.PACKET, (0, 0, WIDTH, HEIGHT), None),
            (None, None, PROTOCOL_VERSION - 1),
            (None, None, None),
            (None, None, PROTOCOL_VERSION + 1),
        ]
        self.run_loop(io, reads, decoded)
        stats = io.stats
        self.assertEqual(stats.reads, 4)
        self.assertEqual(stats.decoded_frames, 1)
        self.assertEqual(stats.foreign_version_frames, 2)
        self.assertEqual(stats.last_foreign_version, PROTOCOL_VERSION + 1)
        self.assertEqual(io.undecodable_capture_frames, 3)
        self.assertEqual(stats.last_frame_shape, (8, 8, 3))
        self.assertEqual(stats.worker_errors, 0)
        self.assertIsNotNone(stats.last_read_at)
        self.assertIsNotNone(stats.last_decoded_at)
        # The first read sampled the mean; later reads within 1 s did not.
        self.assertEqual(stats.last_frame_mean, 100.0)
        self.assertEqual(io.receive(), [(self.PACKET, (0, 0, WIDTH, HEIGHT))])
        metrics = io.capture_metrics(stats.last_read_at)
        self.assertEqual(metrics["foreign_version_frames"], 2)
        self.assertEqual(metrics["last_foreign_version"], PROTOCOL_VERSION + 1)

    def test_real_foreign_frame_through_capture_loop(self):
        io = HdmiFrameIO(1)
        with mock.patch("src.wire.PROTOCOL_VERSION", PROTOCOL_VERSION - 1):
            image = packet_image(self.PACKET)
        io._capture = _ScriptedCapture(io, [(True, image)])
        io._capture_loop()
        self.assertEqual(io.stats.foreign_version_frames, 1)
        self.assertEqual(io.stats.last_foreign_version, PROTOCOL_VERSION - 1)
        self.assertEqual(io.stats.decoded_frames, 0)
        self.assertEqual(io.receive(), [])
        diagnosis = code(capture=io.capture_metrics(io.stats.last_read_at),
                         presence=healthy_presence(last_peer_frame_age_seconds=None))
        self.assertEqual(diagnosis, "PEER_OTHER_VERSION")

    def test_exception_in_worker_is_recorded_and_loop_continues(self):
        io = HdmiFrameIO(1)
        reads = [RuntimeError("driver exploded"), (True, frame())]
        self.run_loop(io, reads, [(self.PACKET, None, None)])
        self.assertEqual(io.stats.worker_errors, 1)
        self.assertEqual(io.stats.last_worker_error, "RuntimeError: driver exploded")
        self.assertEqual(io.stats.reads, 1)
        self.assertEqual(io.stats.decoded_frames, 1)
        self.assertEqual(io.receive(), [(self.PACKET, None)])

    def test_decoder_exception_does_not_count_as_worker_error(self):
        io = HdmiFrameIO(1)
        self.run_loop(io, [(True, frame())], [ValueError("bad frame")])
        self.assertEqual(io.stats.worker_errors, 0)
        self.assertEqual(io.stats.reads, 1)
        self.assertEqual(io.undecodable_capture_frames, 1)

    def run_no_decode(self, *, link_down: bool, since: float, now: float = 1000.0,
                      decoded_at: float | None = None):
        io = HdmiFrameIO(1)
        io.link_down = link_down
        io.stats.opened_at_hint = since
        io.stats.last_decoded_at = decoded_at
        clock = types.SimpleNamespace(monotonic=lambda: now)
        with mock.patch.object(hardware, "time", clock), \
                mock.patch.object(io, "_reopen_capture") as reopen:
            self.run_loop(io, [(True, frame())], [(None, None, None)])
        return reopen

    def test_link_down_without_decode_reopens_capture(self):
        reopen = self.run_no_decode(link_down=True, since=1000.0 - NO_DECODE_REOPEN_SECONDS)
        reopen.assert_called_once_with()

    def test_no_reopen_while_link_up_or_before_the_limit(self):
        self.run_no_decode(link_down=False, since=0.0).assert_not_called()
        self.run_no_decode(link_down=True,
                           since=1000.0 - NO_DECODE_REOPEN_SECONDS + 1).assert_not_called()
        self.run_no_decode(link_down=True, since=0.0,
                           decoded_at=1000.0 - 1).assert_not_called()

    def test_reopen_counts_and_restarts_the_clock(self):
        io = HdmiFrameIO(1)
        old = mock.Mock()
        io._capture = old
        io.stats.last_decoded_at = 5.0
        replacement = mock.Mock()
        replacement.isOpened.return_value = True
        with mock.patch.object(hardware, "open_capture", return_value=replacement), \
                mock.patch.object(hardware, "capture_format", return_value={"fourcc": "YUY2"}):
            io._reopen_capture()
        old.release.assert_called_once_with()
        self.assertIs(io._capture, replacement)
        self.assertEqual(io.stats.reopens, 1)
        self.assertEqual(io.stats.reopen_failures, 0)
        self.assertIsNone(io.stats.last_decoded_at)
        self.assertIsNotNone(io.stats.opened_at_hint)
        self.assertEqual(io.stats.format, {"fourcc": "YUY2"})

    def test_failed_reopen_is_counted(self):
        io = HdmiFrameIO(1)
        replacement = mock.Mock()
        replacement.isOpened.return_value = False
        with mock.patch.object(hardware, "open_capture", return_value=replacement):
            io._reopen_capture()
        self.assertIsNone(io._capture)
        self.assertEqual(io.stats.reopens, 1)
        self.assertEqual(io.stats.reopen_failures, 1)
        replacement.release.assert_called_once_with()


# -------------------------------------------------------------------- build


class BuildIdTests(unittest.TestCase):
    def test_shape(self):
        self.assertEqual(BUILD_ID_BYTES, 8)
        self.assertEqual(len(BUILD_ID), BUILD_ID_BYTES)
        self.assertRegex(BUILD_TEXT, r"^[0-9a-f]{16}$")
        self.assertEqual(BUILD_TEXT, BUILD_ID.hex())

    @staticmethod
    def make_tree(root: Path, newline: bytes, extra: bytes = b"") -> None:
        (root / "src").mkdir(parents=True, exist_ok=True)
        (root / "pixelduplex.py").write_bytes(b"import src" + newline + b"run()" + newline)
        (root / "src" / "a.py").write_bytes(b"A = 1" + newline + extra)
        (root / "src" / "b.py").write_bytes(b"B = 2" + newline)
        # Not part of the build: only pixelduplex.py and src/*.py are.
        (root / "src" / "notes.txt").write_bytes(os.urandom(8))

    def test_line_endings_do_not_change_the_id(self):
        with tempfile.TemporaryDirectory() as lf, tempfile.TemporaryDirectory() as crlf:
            self.make_tree(Path(lf), b"\n")
            self.make_tree(Path(crlf), b"\r\n")
            first = compute_build_id(Path(lf))
            self.assertEqual(len(first), BUILD_ID_BYTES)
            self.assertEqual(first, compute_build_id(Path(crlf)))

    def test_code_and_file_names_change_the_id(self):
        with tempfile.TemporaryDirectory() as base, tempfile.TemporaryDirectory() as edited, \
                tempfile.TemporaryDirectory() as renamed:
            self.make_tree(Path(base), b"\n")
            self.make_tree(Path(edited), b"\n", extra=b"C = 3\n")
            self.make_tree(Path(renamed), b"\n")
            (Path(renamed) / "src" / "b.py").rename(Path(renamed) / "src" / "c.py")
            ids = {compute_build_id(Path(p)) for p in (base, edited, renamed)}
            self.assertEqual(len(ids), 3)

    def test_source_files_are_the_entry_point_and_src(self):
        files = build_module.source_files()
        self.assertEqual(files[0].name, "pixelduplex.py")
        self.assertTrue(all(re.fullmatch(r".+\.py", path.name) for path in files))
        self.assertIn("build.py", {path.name for path in files[1:]})
        self.assertEqual(files[1:], sorted(files[1:]))


if __name__ == "__main__":
    unittest.main()
