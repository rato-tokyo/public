"""Release packaging tests; no hardware or credentials required."""

from __future__ import annotations

import importlib.util
import json
import shutil
import tempfile
import unittest
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("build_release", ROOT / "tools" / "build_release.py")
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class BuildReleaseTests(unittest.TestCase):
    def test_package_allowlist_without_config(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "out"
            version = MODULE.protocol_version(ROOT)
            folder, archive = MODULE.build_release(ROOT, output, version)
            self.assertEqual(folder.name, f"PixelDuplex-v{version}")
            # Each PC's start script creates config.json for its own role.
            self.assertFalse((folder / "config.json").exists())
            expected = set(MODULE.RELEASE_FILES)
            self.assertIn("start-sender.bat", expected)
            self.assertIn("start-receiver.bat", expected)
            self.assertEqual(
                {p.relative_to(folder).as_posix() for p in folder.rglob("*") if p.is_file()},
                expected,
            )
            with zipfile.ZipFile(archive) as package:
                self.assertEqual(
                    set(package.namelist()),
                    {f"{folder.name}/{name}" for name in expected},
                )
            self.assertNotIn("key.txt", expected)
            self.assertNotIn("pixelduplex-ledger.json", expected)

    def test_version_mismatch_and_existing_output_are_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "out"
            version = MODULE.protocol_version(ROOT)
            with self.assertRaisesRegex(ValueError, "一致しません"):
                MODULE.build_release(ROOT, output, version + 1)
            folder, archive = MODULE.build_release(ROOT, output, version)
            original = archive.read_bytes()
            with self.assertRaises(FileExistsError):
                MODULE.build_release(ROOT, output, version)
            self.assertTrue(folder.exists())
            self.assertEqual(archive.read_bytes(), original)

    def test_output_under_synced_folders_is_refused(self) -> None:
        version = MODULE.protocol_version(ROOT)
        for synced in ("target", "received"):
            output = ROOT / synced / "releases-test-never-created"
            with self.assertRaisesRegex(ValueError, synced):
                MODULE.build_release(ROOT, output, version)
            self.assertFalse(output.exists())

    def test_unlisted_python_module_prevents_release(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "source"
            for relative in MODULE.RELEASE_FILES:
                source = ROOT / relative
                destination = root / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, destination)
            extra = root / "tools" / "forgotten_tool.py"
            extra.write_text("pass\n", encoding="utf-8")
            output = Path(temporary) / "out"
            with self.assertRaisesRegex(ValueError, "tools/forgotten_tool.py"):
                MODULE.build_release(root, output, MODULE.protocol_version(root))
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
