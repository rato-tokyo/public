"""Regression tests for the sync review findings.

Each test reproduces a condition that previously flooded the display queue,
destroyed a received file, stalled the queue, misrecorded the ledger or raised
out of ``run``.
"""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from src import ledger as ledger_module
from src.constants import MessageKind
from src.diagnostic import DiagnosticSession
from src.duplex import DuplexEngine
from src.files import scan_regular_files
from src.ledger import Ledger, atomic_json
from src.messages import decode_data, encode_data, json_bytes, parse_json
from src.sync import MANIFEST_RETRY_SECONDS, ReceiverEngine, SenderEngine


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def kinds(messages) -> list[int]:
    return [kind for kind, _ in messages]


class Workspace:
    def __init__(self, test: unittest.TestCase):
        directory = tempfile.TemporaryDirectory()
        test.addCleanup(directory.cleanup)
        self.base = Path(directory.name)
        self.target = self.base / "target"
        self.received = self.base / "received"
        self.target.mkdir()
        self.received.mkdir()

    def sender(self, test: unittest.TestCase, **kwargs) -> SenderEngine:
        ledger = Ledger(self.base / "sender-ledger.json", "sender")
        engine = SenderEngine(
            self.target, ledger.scope("outgoing"),
            scan_interval=1.0, stable_seconds=1.0, **kwargs,
        )
        test.addCleanup(engine.close)
        return engine

    def receiver(self, test: unittest.TestCase) -> ReceiverEngine:
        ledger = Ledger(self.base / "receiver-ledger.json", "receiver")
        engine = ReceiverEngine(
            self.received, ledger.scope("incoming"), session_id="s",
            report_path=self.base / "report.json",
        )
        test.addCleanup(engine.close)
        return engine

    def report(self) -> dict:
        return json.loads((self.base / "report.json").read_text(encoding="utf-8"))


def meta(path: str, data: bytes, *, transfer_id: bytes = b"\x01" * 16,
         digest: str | None = None, chunk_bytes: int = 60_000) -> bytes:
    return json_bytes({
        "transfer_id": transfer_id.hex(), "path": path, "size": len(data),
        "sha256": digest or sha(data),
        "chunk_count": max(1, -(-len(data) // chunk_bytes)), "chunk_bytes": chunk_bytes,
    })


def queue_for(receiver: ReceiverEngine, path: str, data: bytes) -> None:
    receiver.handle(MessageKind.FILE_ANNOUNCE, json_bytes({
        "path": path, "size": len(data), "sha256": sha(data), "sendable": True,
    }), 0.0)


class AnnouncementFloodTests(unittest.TestCase):
    """Finding 1: every scan re-announced every incomplete file."""

    def test_each_stable_file_is_announced_once(self):
        workspace = Workspace(self)
        for index in range(100):
            (workspace.target / f"f{index:03}.txt").write_bytes(b"x" * 10)
        sender = workspace.sender(self)
        counts = [len(sender.scan(float(now))) for now in range(0, 8)]
        # First scan observes, second confirms stability and announces once.
        self.assertEqual(counts, [0, 100, 0, 0, 0, 0, 0, 0])
        # The manifest still lists every stable file as sendable.
        manifest = sender.manifest()
        self.assertEqual(len(manifest), 100)
        self.assertTrue(all(item["sendable"] for item in manifest))

    def test_changed_file_is_announced_again(self):
        workspace = Workspace(self)
        source = workspace.target / "a.txt"
        source.write_bytes(b"one")
        sender = workspace.sender(self)
        sender.scan(0.0)
        self.assertEqual(len(sender.scan(1.0)), 1)
        source.write_bytes(b"two, longer")
        os.utime(source, ns=(1, 10**18))
        self.assertEqual(sender.scan(2.0), [])
        self.assertEqual(len(sender.scan(3.0)), 1)

    def test_rejected_path_is_not_announced_again_in_the_session(self):
        workspace = Workspace(self)
        (workspace.target / "held.txt").write_bytes(b"mine")
        sender = workspace.sender(self)
        sender.scan(0.0)
        sender.scan(1.0)
        sender.handle(MessageKind.FILE_REJECTED, json_bytes({
            "path": "held.txt", "reason": "destination exists with different content",
        }), 1.5)
        os.utime(workspace.target / "held.txt", ns=(1, 10**18))
        for now in (2.0, 3.0, 4.0):
            self.assertEqual(sender.scan(now), [])
        [item] = sender.manifest()
        self.assertFalse(item["sendable"])

    def test_conflict_is_hashed_and_recorded_once_per_session(self):
        workspace = Workspace(self)
        (workspace.received / "same.txt").write_bytes(b"theirs")
        receiver = workspace.receiver(self)
        item = {"path": "same.txt", "size": 4, "sha256": sha(b"mine"), "sendable": True}
        first = receiver.handle(MessageKind.MANIFEST, json_bytes([item]), 0.0)
        self.assertEqual(kinds(first), [MessageKind.FILE_REJECTED])
        self.assertEqual(receiver.ledger.get("same.txt")["status"], "CONFLICT")
        with mock.patch("src.sync.sha256_file") as hashing, \
                mock.patch.object(receiver.ledger, "record") as record:
            again = receiver.handle(MessageKind.MANIFEST, json_bytes([item]), 5.0)
        self.assertEqual(again, [])
        hashing.assert_not_called()
        record.assert_not_called()
        self.assertEqual((workspace.received / "same.txt").read_bytes(), b"theirs")

    def test_lost_announcements_are_recovered_by_the_manifest(self):
        workspace = Workspace(self)
        files = {f"dir/{index:02}.bin": os.urandom(100 + index) for index in range(30)}
        for relative, data in files.items():
            path = workspace.target / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        a = DuplexEngine(workspace.target, workspace.base / "a-received",
                         Ledger(workspace.base / "a.json", "sender"), "sender",
                         scan_interval=1.0, stable_seconds=1.0, retransmit_seconds=0.5)
        b = DuplexEngine(workspace.base / "b-target", workspace.received,
                         Ledger(workspace.base / "b.json", "receiver"), "receiver",
                         scan_interval=1.0, stable_seconds=1.0, retransmit_seconds=0.5)
        self.addCleanup(a.close)
        self.addCleanup(b.close)
        queues = {"a": [], "b": []}
        announcements = 0
        now = 0.0
        while now < 600.0:
            now += 0.1
            queues["b"].extend(a.tick(now))
            queues["a"].extend(b.tick(now))
            for name, engine, peer in (("a", a, "b"), ("b", b, "a")):
                inbox, queues[name] = queues[name], []
                for kind, payload in inbox:
                    if kind == MessageKind.FILE_ANNOUNCE:
                        announcements += 1
                        continue  # every announcement is lost
                    queues[peer].extend(engine.handle(kind, payload, now))
            if all(a.outbound.ledger.is_complete(relative) for relative in files):
                break
        self.assertEqual(announcements, len(files))
        for relative, data in files.items():
            self.assertEqual((workspace.received / relative).read_bytes(), data)
            self.assertTrue(b.inbound.ledger.is_complete(relative))


class TemporaryFileTests(unittest.TestCase):
    """Finding 2: the receive temporary was <name>.part, a possible received file."""

    def test_receiving_foo_leaves_received_foo_part_untouched(self):
        workspace = Workspace(self)
        existing = workspace.received / "foo.part"
        existing.write_bytes(b"previously received content")
        receiver = workspace.receiver(self)
        data = b"new"
        queue_for(receiver, "foo", data)
        receiver.handle(MessageKind.FILE_META, meta("foo", data), 0.0)
        self.assertEqual(existing.read_bytes(), b"previously received content")
        receiver.close()  # abort, e.g. reconnect
        self.assertEqual(existing.read_bytes(), b"previously received content")
        self.assertEqual(sorted(p.name for p in workspace.received.iterdir()), ["foo.part"])

        receiver = workspace.receiver(self)
        queue_for(receiver, "foo", data)
        receiver.handle(MessageKind.FILE_META, meta("foo", data, transfer_id=b"\x02" * 16), 0.0)
        receiver.handle(MessageKind.FILE_DATA, encode_data(b"\x02" * 16, 0, data), 0.1)
        self.assertEqual((workspace.received / "foo").read_bytes(), data)
        self.assertEqual(existing.read_bytes(), b"previously received content")
        self.assertEqual(sorted(p.name for p in workspace.received.iterdir()), ["foo", "foo.part"])

    def test_temporary_is_created_exclusively(self):
        workspace = Workspace(self)
        receiver = workspace.receiver(self)
        tag = b"\x03" * 16
        squatter = workspace.received / f".x.bin.{tag.hex()}.pdtmp"
        squatter.write_bytes(b"not ours")
        queue_for(receiver, "x.bin", b"abc")
        messages = receiver.handle(MessageKind.FILE_META, meta("x.bin", b"abc", transfer_id=tag), 0.0)
        self.assertEqual(kinds(messages), [MessageKind.FILE_REJECTED])
        self.assertIsNone(receiver.transfer)
        self.assertEqual(squatter.read_bytes(), b"not ours")


class ReceiverFailureTests(unittest.TestCase):
    """Findings 3/5 (receive side): these used to raise out of ``run``."""

    def test_parent_path_is_an_existing_file(self):
        workspace = Workspace(self)
        (workspace.received / "a").write_bytes(b"old file named a")
        receiver = workspace.receiver(self)
        messages = receiver.handle(MessageKind.FILE_ANNOUNCE, json_bytes({
            "path": "a/b.txt", "size": 1, "sha256": "b" * 64, "sendable": True,
        }), 0.0)
        self.assertEqual(kinds(messages), [MessageKind.FILE_REJECTED])
        self.assertEqual(receiver.ledger.get("a/b.txt")["status"], "FAILURE")
        self.assertEqual(receiver.pending, [])
        self.assertEqual((workspace.received / "a").read_bytes(), b"old file named a")
        self.assertEqual(workspace.report()["status"], "FAILURE")

    def test_windows_invalid_name(self):
        workspace = Workspace(self)
        receiver = workspace.receiver(self)
        messages = receiver.handle(MessageKind.MANIFEST, json_bytes([
            {"path": "bad:name.txt", "size": 1, "sha256": "c" * 64, "sendable": True},
            {"path": "good.txt", "size": 1, "sha256": "d" * 64, "sendable": True},
        ]), 0.0)
        self.assertEqual(kinds(messages), [MessageKind.FILE_REJECTED])
        self.assertEqual([item["path"] for item in receiver.pending], ["good.txt"])

    def test_sha256_mismatch_at_publish(self):
        workspace = Workspace(self)
        receiver = workspace.receiver(self)
        data = b"payload"
        queue_for(receiver, "p.bin", data)
        receiver.handle(MessageKind.FILE_META, meta("p.bin", data, digest="0" * 64), 0.0)
        messages = receiver.handle(MessageKind.FILE_DATA, encode_data(b"\x01" * 16, 0, data), 0.1)
        self.assertIn(MessageKind.FILE_REJECTED, kinds(messages))
        self.assertNotIn(MessageKind.FILE_COMPLETE, kinds(messages))
        self.assertIsNone(receiver.transfer)
        self.assertEqual(list(workspace.received.iterdir()), [])
        self.assertFalse(receiver.ledger.is_complete("p.bin"))
        self.assertEqual(workspace.report()["status"], "FAILURE")

    def test_destination_appeared_during_transfer_is_kept(self):
        workspace = Workspace(self)
        receiver = workspace.receiver(self)
        data = b"payload"
        queue_for(receiver, "p.bin", data)
        receiver.handle(MessageKind.FILE_META, meta("p.bin", data), 0.0)
        (workspace.received / "p.bin").write_bytes(b"user file")
        messages = receiver.handle(MessageKind.FILE_DATA, encode_data(b"\x01" * 16, 0, data), 0.1)
        self.assertIn(MessageKind.FILE_REJECTED, kinds(messages))
        self.assertEqual((workspace.received / "p.bin").read_bytes(), b"user file")
        self.assertEqual(receiver.ledger.get("p.bin")["status"], "CONFLICT")
        self.assertEqual(sorted(p.name for p in workspace.received.iterdir()), ["p.bin"])

    def test_chunk_length_mismatch(self):
        workspace = Workspace(self)
        receiver = workspace.receiver(self)
        data = b"payload"
        queue_for(receiver, "p.bin", data)
        receiver.handle(MessageKind.FILE_META, meta("p.bin", data), 0.0)
        messages = receiver.handle(MessageKind.FILE_DATA, encode_data(b"\x01" * 16, 0, b"pay"), 0.1)
        self.assertEqual(kinds(messages), [MessageKind.FILE_REJECTED])
        self.assertIsNone(receiver.transfer)
        self.assertEqual(list(workspace.received.iterdir()), [])

    def test_malformed_messages_are_dropped_by_the_duplex_engine(self):
        workspace = Workspace(self)
        engine = DuplexEngine(workspace.target, workspace.received,
                              Ledger(workspace.base / "l.json", "receiver"), "receiver")
        self.addCleanup(engine.close)
        for kind, payload in (
            (MessageKind.MANIFEST, b"{not json"),
            (MessageKind.FILE_ANNOUNCE, b"\xff\xfe"),
            (MessageKind.FILE_REQUEST, json_bytes(["list"])),
            (MessageKind.FILE_ACK, b"short"),
            (MessageKind.SYNC_TOKEN, json_bytes(["x"])),
            (MessageKind.COMPLETE_CONFIRM, json_bytes([1])),
        ):
            self.assertEqual(engine.handle(kind, payload, 0.0), [], kind.name)


class SenderFailureTests(unittest.TestCase):
    """Findings 3/5 (send side)."""

    def test_file_vanishing_during_scan(self):
        workspace = Workspace(self)
        sender = workspace.sender(self)
        with mock.patch("src.sync.scan_regular_files",
                        return_value=[workspace.target / "gone.txt"]):
            self.assertEqual(sender.scan(0.0), [])

    def test_directory_vanishing_during_walk(self):
        workspace = Workspace(self)
        (workspace.target / "kept.txt").write_bytes(b"k")
        real_walk = os.walk

        def walk(root, followlinks=False):
            for directory, names, files in real_walk(root, followlinks=followlinks):
                names.append("vanished-directory")
                yield directory, names, files

        with mock.patch("src.files.os.walk", new=walk):
            self.assertEqual([p.name for p in scan_regular_files(workspace.target)], ["kept.txt"])

    def _announced(self, name: str, data: bytes) -> SenderEngine:
        workspace = Workspace(self)
        (workspace.target / name).write_bytes(data)
        sender = workspace.sender(self)
        sender.scan(0.0)
        sender.scan(1.0)
        self.workspace = workspace
        return sender

    def test_request_after_file_was_deleted(self):
        sender = self._announced("gone.txt", b"data")
        (self.workspace.target / "gone.txt").unlink()
        messages = sender.handle(MessageKind.FILE_REQUEST, json_bytes({"path": "gone.txt"}), 2.0)
        self.assertEqual(kinds(messages), [MessageKind.FILE_UNAVAILABLE])
        self.assertIsNone(sender.transfer)

    def test_request_while_file_is_locked(self):
        sender = self._announced("locked.txt", b"data")
        with mock.patch("pathlib.Path.open", side_effect=PermissionError("locked")):
            messages = sender.handle(MessageKind.FILE_REQUEST, json_bytes({"path": "locked.txt"}), 2.0)
        self.assertEqual(kinds(messages), [MessageKind.FILE_UNAVAILABLE])
        self.assertIsNone(sender.transfer)

    def test_truncated_read_is_never_sent(self):
        data = os.urandom(150_000)
        sender = self._announced("big.bin", data)
        sender.handle(MessageKind.FILE_REQUEST, json_bytes({"path": "big.bin"}), 2.0)
        self.assertIsNotNone(sender.transfer)
        with mock.patch.object(type(sender.transfer), "read", return_value=b"short"):
            messages = sender.tick(2.1)
        self.assertNotIn(MessageKind.FILE_DATA, kinds(messages))
        self.assertIn(MessageKind.CONFLICT, kinds(messages))
        self.assertIsNone(sender.transfer)
        self.assertFalse(sender.ledger.is_complete("big.bin"))

    def test_receiver_rejection_cancels_the_running_transfer(self):
        sender = self._announced("p.bin", b"data")
        sender.handle(MessageKind.FILE_REQUEST, json_bytes({"path": "p.bin"}), 2.0)
        self.assertIsNotNone(sender.transfer)
        sender.handle(MessageKind.FILE_REJECTED, json_bytes({"path": "p.bin", "reason": "x"}), 2.1)
        self.assertIsNone(sender.transfer)
        self.assertFalse(sender.ledger.is_complete("p.bin"))


class DirectionRoutingTests(unittest.TestCase):
    """Finding 6: ALREADY_COMPLETE / CONFLICT carried two meanings."""

    def test_reply_for_completed_path_does_not_complete_our_own_outgoing(self):
        workspace = Workspace(self)
        # Requester's own target has the same relative path, never sent.
        (workspace.target / "same.txt").write_bytes(b"mine, unsent")
        ledger = Ledger(workspace.base / "l.json", "receiver")
        engine = DuplexEngine(workspace.target, workspace.received, ledger, "receiver")
        self.addCleanup(engine.close)
        engine.outbound.scan(0.0)
        queue_for(engine.inbound, "same.txt", b"theirs")

        peer_workspace = Workspace(self)
        (peer_workspace.target / "same.txt").write_bytes(b"theirs")
        peer = peer_workspace.sender(self)
        peer.ledger.record("same.txt", status="SUCCESS", size=6, sha256=sha(b"theirs"))
        [reply] = peer.handle(MessageKind.FILE_REQUEST, json_bytes({"path": "same.txt"}), 1.0)
        self.assertEqual(reply[0], MessageKind.FILE_UNAVAILABLE)

        engine.handle(*reply, 1.0)
        self.assertIsNone(ledger.get("same.txt", "outgoing"))
        self.assertIsNone(ledger.get("same.txt", "incoming"))
        self.assertEqual(engine.inbound.pending, [])

    def test_receiver_conflict_does_not_abort_our_incoming_transfer(self):
        workspace = Workspace(self)
        engine = DuplexEngine(workspace.target, workspace.received,
                              Ledger(workspace.base / "l.json", "sender"), "sender")
        self.addCleanup(engine.close)
        data = b"incoming data"
        queue_for(engine.inbound, "same.txt", data)
        engine.handle(MessageKind.FILE_META, meta("same.txt", data), 0.0)
        self.assertIsNotNone(engine.inbound.transfer)
        # The peer's receive side reports a conflict for OUR outgoing same.txt.
        engine.handle(MessageKind.FILE_REJECTED, json_bytes({
            "path": "same.txt", "reason": "destination exists with different content",
        }), 0.1)
        self.assertIsNotNone(engine.inbound.transfer)
        self.assertIn("same.txt", engine.outbound.rejected)
        # The sender's own cancellation still aborts the incoming transfer.
        engine.handle(MessageKind.CONFLICT, json_bytes({
            "path": "same.txt", "reason": "source changed during transfer",
        }), 0.2)
        self.assertIsNone(engine.inbound.transfer)


class ManifestRetryTests(unittest.TestCase):
    """Finding 8: MANIFEST_REQUEST was repeated every second."""

    def test_manifest_request_waits_at_least_three_seconds(self):
        receiver = Workspace(self).receiver(self)
        sent = []
        now = 0.0
        while now < 9.0:
            sent.extend(now for kind, _ in receiver.tick(now) if kind == MessageKind.MANIFEST_REQUEST)
            now = round(now + 0.1, 1)
        self.assertEqual(MANIFEST_RETRY_SECONDS, 3.0)
        self.assertEqual(sent, [0.0, 3.0, 6.0])

    def test_token_round_requests_immediately(self):
        receiver = Workspace(self).receiver(self)
        receiver.tick(0.0)
        receiver.handle(MessageKind.MANIFEST, json_bytes([]), 0.5)
        receiver.start_round()
        self.assertEqual(kinds(receiver.tick(1.0)), [MessageKind.MANIFEST_REQUEST])


class AtomicJsonRetryTests(unittest.TestCase):
    """Finding 5: a reader holding the target open made os.replace fail."""

    def test_permission_error_is_retried(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "status.json"
            real_replace = os.replace
            calls = []

            def flaky(source, destination):
                calls.append(1)
                if len(calls) < 3:
                    raise PermissionError("target is open")
                real_replace(source, destination)

            with mock.patch.object(ledger_module.os, "replace", new=flaky), \
                    mock.patch.object(ledger_module.time, "sleep") as sleep:
                atomic_json(path, {"status": "READY"})
            self.assertEqual(json.loads(path.read_text(encoding="utf-8")), {"status": "READY"})
            self.assertEqual(len(calls), 3)
            self.assertEqual(sleep.call_count, 2)

    def test_persistent_permission_error_raises_and_keeps_old_ledger(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ledger.json"
            ledger = Ledger(path, "receiver")
            ledger.record("a.bin", direction="incoming", status="SUCCESS", size=1, sha256="a")
            before = path.read_bytes()
            with mock.patch.object(ledger_module.os, "replace",
                                   side_effect=PermissionError("locked")), \
                    mock.patch.object(ledger_module.time, "sleep"):
                with self.assertRaises(PermissionError):
                    ledger.record("b.bin", direction="incoming", status="SUCCESS", size=1, sha256="b")
            self.assertEqual(path.read_bytes(), before)


class DiagnosticRobustnessTests(unittest.TestCase):
    def test_malformed_blob_messages_do_not_raise(self):
        session = DiagnosticSession("sender", window_size=8, retransmit_seconds=1.0)
        self.assertEqual(session.handle(MessageKind.BLOB_META, json_bytes({"purpose": "self-test"}), 0.0), [])
        self.assertEqual(session.handle(MessageKind.BLOB_DATA, b"x", 0.0), [])
        self.assertEqual(session.handle(MessageKind.BLOB_COMPLETE, b"{", 0.0), [])

    def test_responder_drops_a_blob_that_fails_verification(self):
        session = DiagnosticSession("sender", window_size=8, retransmit_seconds=1.0)
        transfer_id = b"\x05" * 16
        session.handle(MessageKind.BLOB_META, json_bytes({
            "transfer_id": transfer_id.hex(), "purpose": "self-test", "phase": "outbound",
            "size": 3, "sha256": "0" * 64, "chunk_count": 1, "chunk_bytes": 60_000,
        }), 0.0)
        self.assertEqual(session.handle(MessageKind.BLOB_DATA, encode_data(transfer_id, 0, b"abc"), 0.1), [])
        self.assertIsNone(session.receive)
        self.assertIsNone(session.send)


if __name__ == "__main__":
    unittest.main()
