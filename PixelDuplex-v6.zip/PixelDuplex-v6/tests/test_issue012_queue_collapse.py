"""ISSUE-012 regression: the v4 display-queue collapse must not recur.

v4 stalled a 35 MB transfer for over an hour while READY. With window 8,
retransmit 1.0 s and frame interval 0.125 s, one window takes exactly 1.0 s to
display, so undisplayed chunks were re-queued before they ever appeared and
per-receipt ACKs piled up behind them. These tests drive two real ``Runner``
endpoints (real handshake, AES-GCM, duplex sync, Selective Repeat and
``HdmiFrameIO`` queue) on a simulated clock; only the screen and the capture
device are replaced by a lossy in-memory channel.
"""

from __future__ import annotations

import hashlib
import os
import random
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from src import app as app_module
from src.app import Runner, Settings
from src.constants import FILE_CHUNK_BYTES, MessageKind, PhysicalKind
from src.hardware import HdmiFrameIO
from src.link import LinkSession
from src.messages import decode_ack, decode_data, encode_ack, encode_data
from src.reliable import SelectiveRepeatReceiver, SelectiveRepeatSender
from src.wire import PhysicalPacket


# The exact v4 values that produced the collapse.
WINDOW_SIZE = 8
RETRANSMIT_SECONDS = 1.0
FRAME_INTERVAL_SECONDS = 0.125
# Four loop steps per display slot keeps every timestamp exactly representable.
STEP_SECONDS = FRAME_INTERVAL_SECONDS / 4
# Queued frames allowed beyond the data window: the coalesced ACK plus
# KEEPALIVE, SYNC_TOKEN, FILE_ANNOUNCE and repeated FILE_COMPLETE traffic.
CONTROL_ALLOWANCE = 6
QUEUE_LIMIT = WINDOW_SIZE + CONTROL_ALLOWANCE


def settings(role: str) -> Settings:
    return Settings(
        role=role, capture_device=0, monitor_device=None,
        scan_interval_seconds=1.0, file_stable_seconds=1.0,
        handshake_timeout_seconds=300.0,
        frame_interval_seconds=FRAME_INTERVAL_SECONDS,
        retransmit_seconds=RETRANSMIT_SECONDS, window_size=WINDOW_SIZE,
    )


class Clock:
    def __init__(self) -> None:
        self.now = 1000.0

    def __call__(self) -> float:
        return self.now


class LossyScreenChannel:
    """Two runners whose displayed frames reach the peer capture queue lossily."""

    def __init__(self, base: Path, rng: random.Random, *, data_loss: float,
                 ack_loss: float, control_loss: float, repeat_rate: float):
        self.rng = rng
        self.data_loss = data_loss
        self.ack_loss = ack_loss
        self.control_loss = control_loss
        self.repeat_rate = repeat_rate
        self.blackout: tuple[float, float] | None = None
        self.clock = Clock()
        # (session_id, message_id) -> (message kind, transfer_id, chunk index)
        self.sent: dict[tuple[bytes, int], tuple[int, bytes | None, int | None]] = {}
        self.displayed: dict[int | None, int] = {}
        self.dropped: dict[int | None, int] = {}
        self.data_sends = 0
        self.resets = 0
        self.max_depth = 0
        self.max_unacked_data = 0
        self.max_stale_data = 0
        self.console: list[str] = []
        self.runners: dict[str, Runner] = {}
        self.peer: dict[str, Runner] = {}
        self.base = base

    def build(self) -> tuple[Runner, Runner]:
        for role in ("sender", "receiver"):
            root = self.base / role
            for name in ("target", "received", "artifacts/logs", "artifacts/reports"):
                (root / name).mkdir(parents=True, exist_ok=True)
            runner = Runner(root, settings(role), "issue012 password", "run")
            runner.io.window = role
            self.runners[role] = runner
        self.peer = {"sender": self.runners["receiver"], "receiver": self.runners["sender"]}
        return self.runners["sender"], self.runners["receiver"]

    def patches(self) -> list:
        channel = self
        original_secure = LinkSession.secure
        original_discard = Runner._discard_session_state

        def tracking_secure(link, kind, payload, **kwargs):
            packets = original_secure(link, kind, payload, **kwargs)
            transfer_id = index = None
            if kind == MessageKind.FILE_DATA:
                transfer_id, index, _ = decode_data(payload)
                channel.data_sends += 1
            for item in packets:
                channel.sent[(item.session_id, item.message_id)] = (int(kind), transfer_id, index)
            return packets

        def counting_discard(runner):
            channel.resets += 1
            original_discard(runner)

        return [
            mock.patch("src.hardware.time.monotonic", new=self.clock),
            mock.patch("src.hardware.packet_image", new=lambda packet: packet),
            mock.patch("src.hardware.cv2.imshow", new=self.show),
            mock.patch("src.hardware.cv2.waitKey", return_value=-1),
            mock.patch.object(app_module, "console", new=self.console.append),
            mock.patch.object(LinkSession, "secure", new=tracking_secure),
            mock.patch.object(Runner, "_discard_session_state", new=counting_discard),
        ]

    def kind_of(self, packet: PhysicalPacket) -> int | None:
        if packet.kind != PhysicalKind.SECURE:
            return None  # plaintext handshake frame
        return self.sent.get((packet.session_id, packet.message_id), (None,))[0]

    def show(self, window: str, packet: PhysicalPacket) -> None:
        kind = self.kind_of(packet)
        self.displayed[kind] = self.displayed.get(kind, 0) + 1
        now = self.clock.now
        if self.blackout is not None and self.blackout[0] <= now < self.blackout[1]:
            loss = 1.0
        elif kind == MessageKind.FILE_DATA:
            loss = self.data_loss
        elif kind == MessageKind.FILE_ACK:
            loss = self.ack_loss
        else:
            loss = self.control_loss
        if self.rng.random() < loss:
            self.dropped[kind] = self.dropped.get(kind, 0) + 1
            return
        incoming = self.peer[window].io._incoming
        incoming.put_nowait((packet, None))
        if self.rng.random() < self.repeat_rate:
            # A repeat that survived capture de-duplication (e.g. after a torn frame).
            incoming.put_nowait((packet, None))

    def step(self, runner: Runner) -> None:
        """One iteration of ``Runner.run`` without window, sleep or status I/O."""
        now = self.clock.now
        runner.io.pump_display()
        runner.io.send(runner.link.periodic(now))
        runner._receive_packets(now)
        runner._check_session_change()
        if not runner.link.connected:
            return
        runner.engine.update_session_id(runner.link.session_id.hex())
        runner.ever_connected = True
        runner.reconnecting = False
        if now - runner.last_keepalive >= 2.0:
            runner.last_keepalive = now
            runner._send_app([(MessageKind.KEEPALIVE, b"")])
        runner._profile_tick(now)
        if not runner.link.connected:
            return
        if runner.profile is not None and runner.profile.state == "ACTIVE":
            runner._send_app(runner.diagnostic.tick(now))
            if not runner.diagnostic.active:
                runner._send_app(runner.engine.tick(now))
        if now - runner.last_valid_packet >= 15.0:
            runner._reset_link()

    def queued_chunks(self, runner: Runner) -> list[int]:
        transfer = runner.engine.outbound.transfer
        if transfer is None:
            return []
        chunks = []
        for item in runner.io.queued_packets():
            kind, transfer_id, index = self.sent.get(
                (item.session_id, item.message_id), (None, None, None),
            )
            if kind == MessageKind.FILE_DATA and transfer_id == transfer.transfer_id:
                chunks.append(index)
        return chunks

    def advance(self, test: unittest.TestCase | None) -> None:
        for runner in self.runners.values():
            self.step(runner)
        for runner in self.runners.values():
            self.max_depth = max(self.max_depth, len(runner.io._outgoing))
            chunks = self.queued_chunks(runner)
            transfer = runner.engine.outbound.transfer
            # A queued retry whose earlier copy was ACKed meanwhile is stale but
            # harmless; only unacknowledged chunks are bounded by the window.
            stale = [index for index in chunks if transfer and index in transfer.reliable.acked]
            self.max_unacked_data = max(self.max_unacked_data, len(chunks) - len(stale))
            self.max_stale_data = max(self.max_stale_data, len(stale))
            if test is not None:
                test.assertEqual(
                    len(chunks), len(set(chunks)),
                    f"t={self.clock.now:.3f} {runner.settings.role} queued a chunk twice: {chunks}",
                )
                test.assertLessEqual(
                    len(runner.io._outgoing), QUEUE_LIMIT,
                    f"t={self.clock.now:.3f} {runner.settings.role} display queue grew",
                )
        self.clock.now += STEP_SECONDS


class QueueCollapseRegressionTests(unittest.TestCase):
    def test_v4_parameters_transfer_hundreds_of_chunks_with_bounded_queue(self):
        forward = os.urandom(FILE_CHUNK_BYTES * 480 + 12_345)
        reverse = os.urandom(FILE_CHUNK_BYTES * 40 + 777)
        forward_chunks = -(-len(forward) // FILE_CHUNK_BYTES)
        with tempfile.TemporaryDirectory() as directory:
            channel = LossyScreenChannel(
                Path(directory), random.Random(12012),
                data_loss=0.10, ack_loss=0.30, control_loss=0.05, repeat_rate=0.05,
            )
            patches = channel.patches()
            for patch in patches:
                patch.start()
            try:
                sender, receiver = channel.build()
                (sender.base / "target" / "big.bin").write_bytes(forward)
                (receiver.base / "target" / "back.bin").write_bytes(reverse)
                started = channel.clock.now
                # A 6 s total outage mid-transfer (below the 15 s reconnect
                # threshold) is when v4's per-receipt re-queueing exploded.
                channel.blackout = (started + 40.0, started + 46.0)
                finished_at = None
                limit = started + 3600.0
                while channel.clock.now < limit:
                    channel.advance(self)
                    done = (
                        (receiver.base / "received" / "big.bin").exists()
                        and (sender.base / "received" / "back.bin").exists()
                        and sender.engine.transfer is None
                        and receiver.engine.transfer is None
                    )
                    if done and finished_at is None:
                        finished_at = channel.clock.now
                        # Keep running idle so late ACKs and periodic control
                        # traffic still cannot grow the queues.
                        limit = min(limit, finished_at + 120.0)
                self.assertIsNotNone(finished_at, "transfer did not finish in one simulated hour")
                elapsed = finished_at - started
                # 522 chunks at 8 frames/s need at least 65 s even without loss.
                self.assertLess(elapsed, 600.0)
                self.assertEqual(
                    hashlib.sha256((receiver.base / "received" / "big.bin").read_bytes()).digest(),
                    hashlib.sha256(forward).digest(),
                )
                self.assertEqual((sender.base / "received" / "back.bin").read_bytes(), reverse)
                self.assertTrue(sender.ledger.is_complete("big.bin", "outgoing"))
                self.assertTrue(receiver.ledger.is_complete("big.bin", "incoming"))
                self.assertTrue(receiver.ledger.is_complete("back.bin", "outgoing"))
                self.assertTrue(sender.ledger.is_complete("back.bin", "incoming"))
                # One session throughout: no silent-link reconnect was needed.
                self.assertEqual(channel.resets, 0)
                self.assertLessEqual(channel.max_unacked_data, WINDOW_SIZE)
                self.assertLessEqual(channel.max_stale_data, WINDOW_SIZE)
                self.assertLessEqual(channel.max_depth, QUEUE_LIMIT)
                # The scenario really contained loss, retries and control traffic.
                self.assertGreater(channel.dropped.get(MessageKind.FILE_DATA, 0), 20)
                self.assertGreater(channel.dropped.get(MessageKind.FILE_ACK, 0), 20)
                self.assertGreater(channel.data_sends, forward_chunks + 41)
                for kind in (MessageKind.KEEPALIVE, MessageKind.SYNC_TOKEN,
                             MessageKind.PING, MessageKind.PROFILE_CONTROL):
                    self.assertGreater(channel.displayed.get(kind, 0), 0, kind.name)
                self.assertGreater(receiver.io.coalesced_frames, 0)
                self.assertTrue(any("DONE" in line and "big.bin" in line
                                    for line in channel.console))
            finally:
                for runner in channel.runners.values():
                    runner.engine.close()
                for patch in reversed(patches):
                    patch.stop()

    def test_v4_retry_clock_in_same_harness_grows_the_queue(self):
        """Control: restoring v4 semantics must make this harness detect collapse."""
        original_due = SelectiveRepeatSender.due

        def v4_due(reliable, now, max_transmissions=None):
            result = original_due(reliable, now, max_transmissions)
            for item in result:
                # v4 started the retry clock when the chunk was queued.
                reliable.pending.discard(item.index)
                reliable.sent_at[item.index] = now
            return result

        original_send = HdmiFrameIO.send
        forward = os.urandom(FILE_CHUNK_BYTES * 480)
        with tempfile.TemporaryDirectory() as directory:
            channel = LossyScreenChannel(
                Path(directory), random.Random(12012),
                data_loss=0.10, ack_loss=0.30, control_loss=0.05, repeat_rate=0.05,
            )

            def v4_send(io, packets, *, priority=False, on_display=None,
                        profile="baseline", coalesce_key=None):
                # v4 queued every ACK at the tail and only KEEPALIVE jumped ahead.
                kind = channel.kind_of(packets[0]) if packets else None
                original_send(io, packets, priority=kind == MessageKind.KEEPALIVE,
                              on_display=on_display, profile=profile)

            patches = channel.patches() + [
                mock.patch.object(SelectiveRepeatSender, "due", new=v4_due),
                mock.patch.object(HdmiFrameIO, "send", new=v4_send),
            ]
            for patch in patches:
                patch.start()
            try:
                sender, _receiver = channel.build()
                (sender.base / "target" / "big.bin").write_bytes(forward)
                stop = channel.clock.now + 120.0
                while channel.clock.now < stop and channel.max_depth <= 4 * QUEUE_LIMIT:
                    channel.advance(None)
                self.assertGreater(channel.max_depth, 4 * QUEUE_LIMIT)
            finally:
                for runner in channel.runners.values():
                    runner.engine.close()
                for patch in reversed(patches):
                    patch.stop()


class HourLongSelectiveRepeatQueueTests(unittest.TestCase):
    def test_heavy_ack_loss_finishes_within_an_hour_with_each_chunk_queued_once(self):
        """Real sender/receiver/display queues with v4 timing, capped at one hour, no crypto."""
        rng = random.Random(1212)
        clock = Clock()
        chunk_count = 400
        transfer_id = b"t" * 16
        ios = {
            "sender": HdmiFrameIO(0, frame_interval=FRAME_INTERVAL_SECONDS),
            "receiver": HdmiFrameIO(0, frame_interval=FRAME_INTERVAL_SECONDS),
        }
        for role, io in ios.items():
            io.window = role
        reliable = SelectiveRepeatSender(chunk_count, WINDOW_SIZE, RETRANSMIT_SECONDS)
        receiver = SelectiveRepeatReceiver(chunk_count)
        # message_id -> message kind; the packet payload carries the real message.
        kinds: dict[int, int] = {}
        arrived: dict[str, list[PhysicalPacket]] = {"sender": [], "receiver": []}
        loss = {MessageKind.FILE_DATA: 0.2, MessageKind.FILE_ACK: 0.5, MessageKind.KEEPALIVE: 0.2}
        next_id = iter(range(1, 10_000_000))
        last_keepalive = {"sender": float("-inf"), "receiver": float("-inf")}
        data_displays = 0
        max_depth = 0
        finished_at = None

        def frame(kind: int, payload: bytes) -> PhysicalPacket:
            message_id = next(next_id)
            kinds[message_id] = kind
            return PhysicalPacket(PhysicalKind.SECURE, b"s" * 16, message_id, 0, 1,
                                  len(payload), payload)

        def show(window: str, packet: PhysicalPacket) -> None:
            nonlocal data_displays
            kind = kinds[packet.message_id]
            data_displays += kind == MessageKind.FILE_DATA
            if rng.random() >= loss[kind]:
                peer = arrived["receiver" if window == "sender" else "sender"]
                peer.append(packet)
                if rng.random() < 0.1:
                    peer.append(packet)  # capture repeat -> two ACKs in one slot

        with mock.patch("src.hardware.time.monotonic", new=clock), \
             mock.patch("src.hardware.packet_image", new=lambda packet: packet), \
             mock.patch("src.hardware.cv2.imshow", new=show), \
             mock.patch("src.hardware.cv2.waitKey", return_value=-1):
            stop = clock.now + 3600.0
            while clock.now < stop:
                now = clock.now
                for io in ios.values():
                    io.pump_display()
                for item in arrived["sender"]:
                    if kinds[item.message_id] == MessageKind.FILE_ACK:
                        _, base, bitmap = decode_ack(item.payload)
                        reliable.acknowledge(base, bitmap)
                for item in arrived["receiver"]:
                    if kinds[item.message_id] != MessageKind.FILE_DATA:
                        continue
                    _, index, _ = decode_data(item.payload)
                    receiver.accept(index)
                    # Every receipt, duplicates included, produces an ACK as in sync.py.
                    base, bitmap = receiver.ack()
                    ios["receiver"].send(
                        [frame(MessageKind.FILE_ACK, encode_ack(transfer_id, base, bitmap))],
                        priority=True, coalesce_key=(int(MessageKind.FILE_ACK), transfer_id),
                    )
                arrived = {"sender": [], "receiver": []}
                for role, io in ios.items():
                    if now - last_keepalive[role] >= 2.0:
                        last_keepalive[role] = now
                        io.send([frame(MessageKind.KEEPALIVE, b"")], priority=True)
                for transmission in reliable.due(now):
                    ios["sender"].send(
                        [frame(MessageKind.FILE_DATA,
                               encode_data(transfer_id, transmission.index, b"x"))],
                        on_display=lambda at, index=transmission.index:
                            reliable.mark_displayed(index, at),
                    )
                queued = [
                    decode_data(item.payload)[1] for item in ios["sender"].queued_packets()
                    if kinds[item.message_id] == MessageKind.FILE_DATA
                ]
                self.assertEqual(len(queued), len(set(queued)), f"t={now:.3f} {queued}")
                max_depth = max(max_depth, *(len(io._outgoing) for io in ios.values()))
                self.assertLessEqual(max_depth, QUEUE_LIMIT, f"t={now:.3f}")
                if reliable.done and finished_at is None:
                    finished_at = now
                    stop = min(stop, now + 60.0)
                clock.now += STEP_SECONDS
        self.assertIsNotNone(finished_at, "400 chunks did not finish in one simulated hour")
        self.assertTrue(receiver.done)
        self.assertLessEqual(max_depth, WINDOW_SIZE + 2)
        self.assertGreater(ios["receiver"].coalesced_frames, 0)
        # With 20 % data loss about 1.25 displays per chunk are needed; v4 spent
        # the display on stale re-queued copies instead.
        self.assertLess(data_displays, chunk_count * 2)


if __name__ == "__main__":
    unittest.main()
