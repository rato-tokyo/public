from __future__ import annotations

import unittest

from src import band_codec
from src.wire import FragmentAssembler, PhysicalPacket


class FragmentBoundsTests(unittest.TestCase):
    def packet(self, message_id: int, index: int, count: int, total: int,
               payload: bytes) -> PhysicalPacket:
        return PhysicalPacket(4, b"s" * 16, message_id, index, count, total, payload)

    def test_band_chunk_fits_one_band_and_reassembles(self):
        for layout in band_codec.LAYOUTS.values():
            payload = b"a" * layout.payload_bytes
            packets = band_codec.fragment_message(layout, 4, b"s" * 16, 1, payload)
            self.assertEqual(len(packets), 1)
            assembler = FragmentAssembler()
            self.assertEqual(assembler.add(packets[0]), payload)
            self.assertEqual(assembler._buffered_bytes, 0)

    def test_oversized_and_absurd_metadata_rejected_without_state(self):
        assembler = FragmentAssembler()
        for packet in (
            self.packet(1, 0, 1, assembler.max_message_bytes + 1, b"x"),
            self.packet(2, 0, assembler.max_fragments + 1, 10, b"x"),
            self.packet(3, 1, 1, 1, b"x"),
        ):
            self.assertIsNone(assembler.add(packet))
        self.assertFalse(assembler._parts)
        self.assertEqual(assembler._buffered_bytes, 0)

    def test_duplicate_does_not_increase_buffered_bytes(self):
        assembler = FragmentAssembler()
        first = self.packet(1, 0, 2, 6, b"abc")
        self.assertIsNone(assembler.add(first))
        self.assertIsNone(assembler.add(first))
        self.assertEqual(assembler._buffered_bytes, 3)
        self.assertEqual(assembler.add(self.packet(1, 1, 2, 6, b"def")), b"abcdef")
        self.assertEqual(assembler._buffered_bytes, 0)

    def test_global_buffer_budget_evicts_oldest(self):
        assembler = FragmentAssembler(max_buffered_bytes=6)
        self.assertIsNone(assembler.add(self.packet(1, 0, 2, 6, b"aaa")))
        self.assertIsNone(assembler.add(self.packet(2, 0, 2, 6, b"bbb")))
        self.assertIsNone(assembler.add(self.packet(3, 0, 2, 6, b"ccc")))
        self.assertNotIn((b"s" * 16, 4, 1), assembler._parts)
        self.assertEqual(assembler._buffered_bytes, 6)


if __name__ == "__main__":
    unittest.main()
