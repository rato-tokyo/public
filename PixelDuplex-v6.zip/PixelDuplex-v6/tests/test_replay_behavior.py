"""Regression tests for repeated captured frames and secure-message replay handling."""

from __future__ import annotations

import unittest
from collections import deque
import queue
import threading
import time
from unittest import mock

from src.app import Runner
from src.constants import MessageKind
from src.hardware import HdmiFrameIO
from src.handshake import Presence
from src.link import LinkSession
from src.wire import PhysicalPacket


class OutgoingPriorityTests(unittest.TestCase):
    def test_keepalive_can_pass_a_long_fragment_backlog_without_reordering_fragments(self):
        io = HdmiFrameIO(0)
        data = [PhysicalPacket(4, b"s" * 16, 1, index, 3, 3, b"d") for index in range(3)]
        keepalive = [PhysicalPacket(4, b"s" * 16, 2, 0, 1, 1, b"k")]
        io.send(data)
        io.send(keepalive, priority=True)
        self.assertEqual(io.queued_packets(), keepalive + data)


def connected_links() -> tuple[LinkSession, LinkSession]:
    """Establish a link without hardware, using the normal physical packets."""
    sender = LinkSession("sender", "shared password")
    receiver = LinkSession("receiver", "shared password")
    to_sender: list[PhysicalPacket] = []
    to_receiver: list[PhysicalPacket] = []
    for step in range(30):
        now = step * 0.6
        to_receiver.extend(sender.periodic(now))
        to_sender.extend(receiver.periodic(now))
        while to_sender:
            outgoing, _ = sender.receive(to_sender.pop(0))
            to_receiver.extend(outgoing)
        while to_receiver:
            outgoing, _ = receiver.receive(to_receiver.pop(0))
            to_sender.extend(outgoing)
        if sender.connected and receiver.connected:
            return sender, receiver
    raise AssertionError("test handshake did not connect")


class CapturedFrameReplayTests(unittest.TestCase):
    def test_repeated_single_fragment_is_delivered_once(self):
        sender, receiver = connected_links()
        packet = sender.secure(MessageKind.KEEPALIVE, b"one frame")[0]

        first_outgoing, first_messages = receiver.receive(packet)
        second_outgoing, second_messages = receiver.receive(packet)

        self.assertEqual(first_outgoing, [])
        self.assertEqual(first_messages, [(MessageKind.KEEPALIVE, b"one frame")])
        self.assertEqual(second_outgoing, [])
        self.assertEqual(second_messages, [])
        self.assertEqual(receiver.duplicate_secure_messages, 1)
        self.assertEqual(receiver.authentication_failures, 0)

    def test_multi_fragment_message_completes_after_duplicate_fragments(self):
        sender, receiver = connected_links()
        payload = b"fragmented" * 20_000
        packets = sender.secure(MessageKind.KEEPALIVE, payload)
        self.assertGreater(len(packets), 1)

        delivered: list[tuple[int, bytes]] = []
        order = [packets[1], packets[1], packets[0], *packets[2:]]
        for packet in order:
            _outgoing, messages = receiver.receive(packet)
            delivered.extend(messages)

        self.assertEqual(delivered, [(MessageKind.KEEPALIVE, payload)])
        self.assertEqual(receiver.authentication_failures, 0)

    def test_packet_from_another_session_is_ignored_without_auth_failure(self):
        sender, receiver = connected_links()
        packet = sender.secure(MessageKind.KEEPALIVE, b"foreign session")[0]
        foreign = PhysicalPacket(
            packet.kind,
            b"X" * 16,
            packet.message_id,
            packet.fragment_index,
            packet.fragment_count,
            packet.total_length,
            packet.payload,
        )

        outgoing, messages = receiver.receive(foreign)

        self.assertEqual((outgoing, messages), ([], []))
        self.assertEqual(receiver.authentication_failures, 0)
        self.assertEqual(receiver.duplicate_secure_messages, 0)

    def test_duplicate_physical_frame_does_not_refresh_silence_liveness(self):
        runner = Runner.__new__(Runner)
        runner._seen_packet_order = deque()
        runner._seen_packets = set()
        packet = PhysicalPacket(4, b"s" * 16, 7, 0, 1, 1, b"x")
        last_valid_packet = 12.5

        if runner._is_new_physical_packet(packet):
            last_valid_packet = 20.0
        if runner._is_new_physical_packet(packet):
            last_valid_packet = 25.0

        self.assertEqual(last_valid_packet, 20.0)

    def test_authenticated_packet_outside_replay_window_is_duplicate(self):
        sender, receiver = connected_links()
        packet = sender.secure(MessageKind.KEEPALIVE, b"old but authentic")[0]
        channel = receiver.handshake.channel
        self.assertIsNotNone(channel)
        channel.highest_received_sequence = 5000

        outgoing, messages = receiver.receive(packet)

        self.assertEqual((outgoing, messages), ([], []))
        self.assertEqual(receiver.authentication_failures, 0)
        self.assertEqual(receiver.duplicate_secure_messages, 1)

    def test_forged_stale_sequence_counts_as_authentication_failure(self):
        sender, receiver = connected_links()
        packet = sender.secure(MessageKind.KEEPALIVE, b"authentic")[0]
        channel = receiver.handshake.channel
        self.assertIsNotNone(channel)
        channel.highest_received_sequence = 5000
        forged = PhysicalPacket(
            packet.kind, packet.session_id, packet.message_id,
            packet.fragment_index, packet.fragment_count, packet.total_length,
            packet.payload[:-1] + bytes([packet.payload[-1] ^ 1]),
        )

        receiver.receive(forged)

        self.assertEqual(receiver.authentication_failures, 1)
        self.assertEqual(receiver.duplicate_secure_messages, 0)

    def test_only_new_authenticated_secure_message_is_live(self):
        sender, receiver = connected_links()
        packet = sender.secure(MessageKind.KEEPALIVE, b"alive")[0]
        foreign = PhysicalPacket(
            packet.kind, b"X" * 16, packet.message_id,
            packet.fragment_index, packet.fragment_count, packet.total_length,
            packet.payload,
        )
        receiver.receive(foreign)
        self.assertFalse(receiver.last_authenticated_packet)
        receiver.receive(packet)
        self.assertTrue(receiver.last_authenticated_packet)
        receiver.receive(packet)
        self.assertFalse(receiver.last_authenticated_packet)

    def test_reset_link_preserves_diagnostic_counters(self):
        runner = Runner.__new__(Runner)
        runner.settings = mock.Mock(role="receiver", window_size=8, retransmit_seconds=1.0)
        runner.password = "shared password"
        runner.link = mock.Mock(authentication_failures=3, duplicate_secure_messages=7)
        runner.engine = mock.Mock()
        runner.io = mock.Mock()
        runner._new_engine = mock.Mock()
        runner.mode = "run"
        runner.authentication_failures_total = 2
        runner.duplicate_secure_messages_total = 4
        runner._seen_packet_order = deque()
        runner._seen_packets = set()
        runner.applied_profile = "baseline"
        runner.candidate_failed = False
        runner.presence = Presence()

        runner._reset_link()

        self.assertEqual(runner.authentication_failures_total, 5)
        self.assertEqual(runner.duplicate_secure_messages_total, 11)


class _FiniteCapture:
    def __init__(self, owner: HdmiFrameIO, reads: list[tuple[bool, object]]):
        self.owner = owner
        self.reads = deque(reads)

    def read(self):
        if self.reads:
            return self.reads.popleft()
        self.owner._stop.set()
        return False, None


class CaptureLoopDeduplicationTests(unittest.TestCase):
    @staticmethod
    def packet(*, session: bytes = b"s" * 16, message: int = 7,
               fragment: int = 0, fragments: int = 1) -> PhysicalPacket:
        return PhysicalPacket(4, session, message, fragment, fragments, 1, b"x")

    def run_loop(self, decoded, *, reads=None, incoming=None) -> HdmiFrameIO:
        io = HdmiFrameIO(0)
        if incoming is not None:
            io._incoming = incoming
        if reads is None:
            reads = [(True, object()) for _ in decoded]
        io._capture = _FiniteCapture(io, reads)
        detailed = [(packet, rect, None) for packet, rect in decoded]
        with mock.patch("src.hardware.decode_image_detail", side_effect=detailed):
            io._capture_loop()
        return io

    def test_consecutive_identical_identity_is_enqueued_once(self):
        packet = self.packet()
        io = self.run_loop([(packet, (1, 2, 3, 4))] * 3)

        self.assertEqual(io.receive(), [(packet, (1, 2, 3, 4))])

    def test_read_failure_gap_allows_same_identity_again(self):
        packet = self.packet()
        io = self.run_loop(
            [(packet, None), (packet, None)],
            reads=[(True, object()), (False, None), (True, object())],
        )

        self.assertEqual(io.receive(), [(packet, None), (packet, None)])

    def test_decode_none_gap_allows_same_identity_again(self):
        packet = self.packet()
        io = self.run_loop([(packet, None), (None, None), (packet, None)])

        self.assertEqual(io.receive(), [(packet, None), (packet, None)])

    def test_full_queue_does_not_suppress_retry_of_same_identity(self):
        packet = self.packet()
        incoming = mock.Mock()
        incoming.put_nowait.side_effect = [queue.Full, None]

        self.run_loop([(packet, None), (packet, None)], incoming=incoming)

        self.assertEqual(incoming.put_nowait.call_count, 2)
        incoming.put_nowait.assert_called_with((packet, None))

    def test_session_message_and_fragment_identity_changes_are_enqueued(self):
        packets = [
            self.packet(),
            self.packet(session=b"t" * 16),
            self.packet(session=b"t" * 16, message=8),
            self.packet(session=b"t" * 16, message=8, fragment=1, fragments=2),
        ]
        io = self.run_loop([(packet, None) for packet in packets])

        self.assertEqual([packet for packet, _ in io.receive()], packets)


class _BlockingCapture:
    def __init__(self, events: list[str] | None = None):
        self.events = events
        self.entered = threading.Event()
        self.released = threading.Event()
        self.release_count = 0

    def read(self):
        self.entered.set()
        self.released.wait()
        return False, None

    def release(self):
        if self.events is not None:
            self.events.append("release")
        self.release_count += 1
        self.released.set()


class _OrderedThread:
    def __init__(self, events: list[str], alive_results: list[bool]):
        self.events = events
        self.alive_results = deque(alive_results)
        self.alive = True

    def join(self, timeout=None):
        self.events.append("join")

    def is_alive(self):
        if self.alive_results:
            self.alive = self.alive_results.popleft()
        return self.alive


class CaptureShutdownTests(unittest.TestCase):
    @mock.patch("src.hardware.cv2.destroyAllWindows")
    def test_close_joins_releases_once_then_joins_again(self, _destroy):
        events: list[str] = []
        io = HdmiFrameIO(0)
        capture = _BlockingCapture(events)
        io._capture = capture
        io._thread = _OrderedThread(events, [True, False, False])

        io.close()
        io.close()

        self.assertEqual(events, ["join", "release", "join"])
        self.assertEqual(capture.release_count, 1)
        self.assertIsNone(io._capture)
        self.assertIsNone(io._thread)

    @mock.patch("src.hardware.cv2.destroyAllWindows")
    def test_close_reports_worker_that_remains_alive(self, _destroy):
        events: list[str] = []
        io = HdmiFrameIO(0)
        capture = _BlockingCapture(events)
        io._capture = capture
        thread = _OrderedThread(events, [True, True])
        io._thread = thread

        with self.assertRaisesRegex(RuntimeError, "capture worker did not stop"):
            io.close()

        self.assertEqual(events, ["join", "release", "join"])
        self.assertEqual(capture.release_count, 1)
        self.assertIs(io._thread, thread)

    @mock.patch("src.hardware.cv2.destroyAllWindows")
    def test_release_unblocks_real_worker_with_bounded_close(self, _destroy):
        io = HdmiFrameIO(0)
        capture = _BlockingCapture()
        io._capture = capture
        io._thread = threading.Thread(target=io._capture_loop, daemon=True)
        io._thread.start()
        self.assertTrue(capture.entered.wait(timeout=0.5))

        started = time.monotonic()
        with mock.patch("src.hardware._CAPTURE_CLOSE_JOIN_SECONDS", 0.02):
            io.close()

        self.assertLess(time.monotonic() - started, 0.25)
        self.assertEqual(capture.release_count, 1)
        self.assertIsNone(io._thread)


if __name__ == "__main__":
    unittest.main()
