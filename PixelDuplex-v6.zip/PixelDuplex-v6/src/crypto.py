"""Password-based authentication and compact authenticated encryption."""

from __future__ import annotations

import hashlib
import hmac
import struct
from dataclasses import dataclass, field

from .constants import PROTOCOL_VERSION

try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
except ModuleNotFoundError as error:  # pragma: no cover - environment guard
    raise SystemExit(
        "Missing dependency: cryptography\n"
        "Install dependencies with:\n  python -m pip install -r requirements.txt"
    ) from error


SCRYPT_N, SCRYPT_R, SCRYPT_P = 1 << 14, 8, 1
SALT_BYTES, CHALLENGE_BYTES, PROOF_BYTES = 16, 16, 32
ENVELOPE_HEADER = struct.Struct("<BQ")  # application kind, per-direction sequence
REPLAY_WINDOW = 4096
# 4-byte nonce prefixes; each direction also has its own key.
S2R_NONCE_PREFIX, R2S_NONCE_PREFIX = b"S2R-", b"R2S-"


class AuthenticationError(ValueError):
    """Raised when a proof or encrypted message cannot be authenticated."""


class ReplayError(AuthenticationError):
    """Raised for an already received or stale authenticated message."""


def derive_root_key(password: str, salt: bytes) -> bytes:
    if not password:
        raise ValueError("key.txt must not be empty")
    if len(salt) != SALT_BYTES:
        raise ValueError("invalid handshake salt length")
    return hashlib.scrypt(
        password.encode("utf-8"), salt=salt, n=SCRYPT_N, r=SCRYPT_R,
        p=SCRYPT_P, dklen=32,
    )


def _expand(root_key: bytes, session_id: bytes, label: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(), length=32, salt=session_id,
        info=f"PixelDuplex-v{PROTOCOL_VERSION}/".encode("ascii") + label,
    ).derive(root_key)


def _proof(root_key: bytes, label: bytes, session_id: bytes,
           receiver_challenge: bytes, sender_challenge: bytes) -> bytes:
    return hmac.digest(
        root_key,
        label + session_id + receiver_challenge + sender_challenge,
        "sha256",
    )


def sender_proof(root_key: bytes, session_id: bytes, receiver_challenge: bytes,
                 sender_challenge: bytes) -> bytes:
    return _proof(root_key, b"sender-proof", session_id, receiver_challenge, sender_challenge)


def receiver_proof(root_key: bytes, session_id: bytes, receiver_challenge: bytes,
                   sender_challenge: bytes) -> bytes:
    return _proof(root_key, b"receiver-proof", session_id, receiver_challenge, sender_challenge)


@dataclass
class SecureChannel:
    """AES-GCM channel with independent keys and counters per direction."""

    role: str
    session_id: bytes
    send_key: bytes
    receive_key: bytes
    send_prefix: bytes
    receive_prefix: bytes
    send_sequence: int = 0
    highest_received_sequence: int = -1
    received_sequences: set[int] = field(default_factory=set)

    @classmethod
    def create(cls, role: str, root_key: bytes, session_id: bytes) -> "SecureChannel":
        if role not in {"sender", "receiver"}:
            raise ValueError("role must be sender or receiver")
        s2r = _expand(root_key, session_id, b"sender-to-receiver")
        r2s = _expand(root_key, session_id, b"receiver-to-sender")
        if role == "sender":
            return cls(role, session_id, s2r, r2s, S2R_NONCE_PREFIX, R2S_NONCE_PREFIX)
        return cls(role, session_id, r2s, s2r, R2S_NONCE_PREFIX, S2R_NONCE_PREFIX)

    def seal(self, kind: int, payload: bytes) -> bytes:
        sequence = self.send_sequence
        if sequence >= (1 << 64):
            raise OverflowError("secure message sequence exhausted")
        self.send_sequence += 1
        header = ENVELOPE_HEADER.pack(kind, sequence)
        nonce = self.send_prefix + sequence.to_bytes(8, "big")
        aad = self.session_id + header
        return header + AESGCM(self.send_key).encrypt(nonce, payload, aad)

    def open(self, envelope: bytes) -> tuple[int, bytes]:
        if len(envelope) < ENVELOPE_HEADER.size + 16:
            raise AuthenticationError("encrypted envelope is too short")
        kind, sequence = ENVELOPE_HEADER.unpack_from(envelope)
        header = envelope[:ENVELOPE_HEADER.size]
        nonce = self.receive_prefix + sequence.to_bytes(8, "big")
        try:
            payload = AESGCM(self.receive_key).decrypt(
                nonce, envelope[ENVELOPE_HEADER.size:], self.session_id + header,
            )
        except Exception as error:
            raise AuthenticationError("message authentication failed") from error
        if sequence in self.received_sequences:
            raise ReplayError("replayed secure message")
        if self.highest_received_sequence >= 0 and sequence + REPLAY_WINDOW < self.highest_received_sequence:
            raise ReplayError("secure message is outside the replay window")
        self.received_sequences.add(sequence)
        self.highest_received_sequence = max(self.highest_received_sequence, sequence)
        floor = self.highest_received_sequence - REPLAY_WINDOW
        if floor > 0:
            self.received_sequences = {
                item for item in self.received_sequences if item >= floor
            }
        return kind, payload
