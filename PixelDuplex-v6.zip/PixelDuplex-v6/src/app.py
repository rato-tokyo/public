"""PixelDuplex command-line application and hardware event loop."""

from __future__ import annotations

import json
import hashlib
import os
import sys
import tempfile
import time
import uuid
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

from .constants import (
    FILE_CHUNK_BYTES, DEFAULT_FRAME_INTERVAL_SECONDS, DEFAULT_HANDSHAKE_TIMEOUT_SECONDS,
    DEFAULT_RETRANSMIT_SECONDS, DEFAULT_SCAN_INTERVAL_SECONDS,
    DEFAULT_STABLE_SECONDS, DEFAULT_WINDOW_SIZE, PROTOCOL_VERSION, MessageKind,
)
from .build import BUILD_TEXT
from .diagnosis import HINT_INTERVAL_SECONDS, Diagnosis, diagnose, diagnose_error, facts_line
from .diagnostic import DiagnosticSession
from .duplex import DuplexEngine
from .files import safe_output_path, sha256_file
from .handshake import HandshakeError, Presence
from .hardware import CaptureFailedError, DisplayLostError, HdmiFrameIO
from .ledger import Ledger, atomic_json
from .link import LinkSession
from .messages import decode_ack, decode_data, json_bytes
from . import band_codec
from .messages import parse_json
from .profile_negotiation import (
    ALLOWED_PROFILES, BASELINE_PROFILE, ProfileAgreementError,
    ProfileNegotiator,
)
from .watchdog import LoopWatchdog


# In-memory diagnostic blob sizes for self-test / profile-test.
DEFAULT_TEST_BYTES = 180_000
MIN_TEST_BYTES = 1_000
MAX_TEST_BYTES = 16_000_000
DEFAULT_TEST_PROFILE = "mono-band4"
# Selective ACKs carry a 64-bit bitmap above the base.
MAX_WINDOW_SIZE = 64
ACK_KINDS = frozenset({MessageKind.FILE_ACK, MessageKind.BLOB_ACK})
DATA_KINDS = frozenset({MessageKind.FILE_DATA, MessageKind.BLOB_DATA})
# No new authenticated frame for this long: discard the session and reconnect.
LINK_SILENCE_SECONDS = 15.0
# An active file transfer whose unique chunk count stays flat this long is
# abandoned with its session and resent from the start (PD-DEC-011).
TRANSFER_STALL_SECONDS = 120.0
# Exit code when the peer is found but cannot be joined (role, build or key).
EXIT_PEER_MISMATCH = 5


def chunk_bytes_for(profile: str) -> int:
    """File/blob chunk that fills one physical unit (full frame or one band)."""
    if profile == BASELINE_PROFILE:
        return FILE_CHUNK_BYTES
    return band_codec.layout_for(profile).chunk_bytes


def console(line: str) -> None:
    """Print one line; a path the console codepage cannot show must not crash run."""
    try:
        print(line, flush=True)
    except UnicodeEncodeError:
        encoding = getattr(sys.stdout, "encoding", None) or "ascii"
        print(line.encode(encoding, "replace").decode(encoding), flush=True)


@dataclass(frozen=True)
class Settings:
    role: str
    capture_device: int
    monitor_device: str | None
    scan_interval_seconds: float
    file_stable_seconds: float
    handshake_timeout_seconds: float
    frame_interval_seconds: float
    retransmit_seconds: float
    window_size: int
    preferred_profile: str = BASELINE_PROFILE


def load_settings(base: Path) -> Settings:
    path = base / "config.json"
    if not path.exists():
        raise RuntimeError(
            f"Missing config: {path}\nCopy config.sender.json or config.receiver.json to config.json."
        )
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise RuntimeError(f"Invalid config.json: {error}") from error
    role = value.get("role")
    if role not in {"sender", "receiver"}:
        raise RuntimeError("config.json role must be sender or receiver")
    settings = Settings(
        role=role,
        capture_device=int(value.get("capture_device", 1)),
        monitor_device=value.get("monitor_device"),
        scan_interval_seconds=float(value.get("scan_interval_seconds", DEFAULT_SCAN_INTERVAL_SECONDS)),
        file_stable_seconds=float(value.get("file_stable_seconds", DEFAULT_STABLE_SECONDS)),
        handshake_timeout_seconds=float(value.get("handshake_timeout_seconds", DEFAULT_HANDSHAKE_TIMEOUT_SECONDS)),
        frame_interval_seconds=float(value.get("frame_interval_seconds", DEFAULT_FRAME_INTERVAL_SECONDS)),
        retransmit_seconds=float(value.get("retransmit_seconds", DEFAULT_RETRANSMIT_SECONDS)),
        window_size=int(value.get("window_size", DEFAULT_WINDOW_SIZE)),
        preferred_profile=value.get("preferred_profile", BASELINE_PROFILE),
    )
    if min(
        settings.scan_interval_seconds, settings.file_stable_seconds,
        settings.handshake_timeout_seconds, settings.frame_interval_seconds,
        settings.retransmit_seconds, settings.window_size,
    ) <= 0:
        raise RuntimeError("all timing values and window_size must be positive")
    if settings.window_size > MAX_WINDOW_SIZE:
        raise RuntimeError(f"window_size must be at most {MAX_WINDOW_SIZE} (ACK bitmap width)")
    if settings.preferred_profile not in ALLOWED_PROFILES:
        raise RuntimeError(
            "preferred_profile must be one of " + ", ".join(sorted(ALLOWED_PROFILES))
        )
    return settings


def load_password(base: Path) -> str:
    path = base / "key.txt"
    if not path.exists():
        raise RuntimeError(f"Missing key file: {path}\nCreate key.txt and enter the shared password.")
    password = path.read_text(encoding="utf-8").rstrip("\r\n")
    if not password:
        raise RuntimeError("key.txt must not be empty")
    return password


class InstanceLock:
    def __init__(self, path: Path):
        self.path = path
        self.stream = None

    def __enter__(self):
        import msvcrt
        self.stream = self.path.open("a+b")
        self.stream.seek(0, os.SEEK_END)
        if self.stream.tell() == 0:
            self.stream.write(b"0")
            self.stream.flush()
        self.stream.seek(0)
        try:
            msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as error:
            self.stream.close()
            raise RuntimeError("PixelDuplex is already running from this directory") from error
        return self

    def __exit__(self, *_args):
        import msvcrt
        if self.stream is not None:
            self.stream.seek(0)
            try:
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            finally:
                self.stream.close()


@contextmanager
def runtime_pid(base: Path, role: str, mode: str):
    """Publish the process only while the instance lock is held."""
    name = f"{mode}.pid" if mode in {"self-test", "file-test", "profile-test"} else f"{role}-run.pid"
    path = base / "artifacts" / "logs" / name
    temporary = path.with_name(f".{name}.{os.getpid()}.tmp")
    pid = str(os.getpid())
    try:
        temporary.write_text(pid + "\n", encoding="ascii")
        os.replace(temporary, path)
        yield
    finally:
        temporary.unlink(missing_ok=True)
        # Do not remove a PID file replaced by another process or an operator.
        try:
            if path.read_text(encoding="ascii").strip() == pid:
                path.unlink()
        except (OSError, UnicodeError):
            pass


STOP_WAIT_SECONDS = 30.0


def stop_request_path(base: Path) -> Path:
    return base / "artifacts" / "logs" / "stop.request"


def instance_running(base: Path) -> bool:
    try:
        with InstanceLock(base / ".pixelduplex.lock"):
            return False
    except RuntimeError:
        return True


def request_stop(base: Path, wait_seconds: float = STOP_WAIT_SECONDS) -> int:
    """Ask a running instance (e.g. started in the background) to stop cleanly.

    The instance ends through the same path as Escape; this never kills it.
    """
    if not instance_running(base):
        print("NOT_RUNNING: no PixelDuplex instance holds the lock in this directory", flush=True)
        return 1
    path = stop_request_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("stop\n", encoding="ascii")
    deadline = time.monotonic() + wait_seconds
    while time.monotonic() < deadline:
        if not instance_running(base):
            print("STOPPED: the running instance ended cleanly", flush=True)
            return 0
        time.sleep(0.2)
    print(f"TIMEOUT: the instance did not stop within {wait_seconds:.0f} seconds; "
          "the request stays and is honored once it reaches its display loop", flush=True)
    return 2


class Runner:
    def __init__(self, base: Path, settings: Settings, password: str, mode: str,
                 test_profile: str = DEFAULT_TEST_PROFILE,
                 test_bytes: int = DEFAULT_TEST_BYTES):
        self.base = base
        self.settings = settings
        self.password = password
        self.mode = mode
        self.test_profile = test_profile
        if mode == "profile-test" and test_profile not in ALLOWED_PROFILES:
            raise ValueError("unsupported test profile")
        if not MIN_TEST_BYTES <= test_bytes <= MAX_TEST_BYTES:
            raise ValueError(
                f"test size must be between {MIN_TEST_BYTES} and {MAX_TEST_BYTES} bytes"
            )
        self.test_bytes = test_bytes
        self.status_path = base / "artifacts" / "reports" / "status.json"
        self.self_test_path = base / "artifacts" / "reports" / "self_test.json"
        self.profile_test_path = base / "artifacts" / "reports" / "profile_test.json"
        self.connect_report_path = base / "artifacts" / "reports" / "connect_diagnosis.json"
        self.ledger = Ledger(base / "pixelduplex-ledger.json", settings.role)
        # Outlives link sessions: what each side sees of the other's screen.
        self.presence = Presence()
        self.link = LinkSession(settings.role, password, self.presence)
        self.io = HdmiFrameIO(
            settings.capture_device, settings.monitor_device,
            settings.frame_interval_seconds,
        )
        self.engine = self._new_engine()
        self.diagnostic = self._new_diagnostic()
        self.started = time.monotonic()
        self.link_down_since = self.started
        self.last_hint = self.started
        self.last_handshake_error: str | None = None
        self.watchdog = LoopWatchdog(base / "artifacts" / "logs" / "hang.log")
        self.ever_connected = False
        self.reconnecting = False
        self.last_valid_packet = self.started
        self.handshake_started_at: float | None = None
        self.progress_marker: tuple | None = None
        self.progress_changed_at = self.started
        self.authentication_failures_total = 0
        self.handshake_errors_total = 0
        self.duplicate_secure_messages_total = 0
        self.unique_physical_frames_total = 0
        self.duplicate_physical_frames_total = 0
        self.last_keepalive = float("-inf")
        self.last_status = float("-inf")
        self._seen_packet_order: deque[tuple] = deque()
        self._seen_packets: set[tuple] = set()
        self.self_test_payload: bytes | None = None
        self.self_test_started: float | None = None
        self.profile_test_metrics_start: dict[str, int] | None = None
        self.file_test_id = uuid.uuid4().hex if mode == "file-test" else None
        self.file_test_payload = os.urandom(64_000) if self.file_test_id else None
        self.file_test_request = ({
            "id": self.file_test_id,
            "path": f"pixelduplex-test/{self.file_test_id}/forward.bin",
            "return_path": f"pixelduplex-test/{self.file_test_id}/return.bin",
            "size": len(self.file_test_payload),
            "sha256": hashlib.sha256(self.file_test_payload).hexdigest(),
        } if self.file_test_id else None)
        self.file_test_created = False
        self.file_test_started: float | None = None
        self.last_file_test_arm = float("-inf")
        self.profile: ProfileNegotiator | None = None
        self.last_profile_send = float("-inf")
        self.applied_profile = BASELINE_PROFILE
        self.candidate_failed = False

    def _new_engine(self):
        return DuplexEngine(
            self.base / "target", self.base / "received", self.ledger,
            self.settings.role,
            window_size=self.settings.window_size,
            scan_interval=self.settings.scan_interval_seconds,
            stable_seconds=self.settings.file_stable_seconds,
            retransmit_seconds=self.settings.retransmit_seconds,
            session_id=self.link.session_id.hex(),
            report_path=self.base / "artifacts" / "reports" / "last_transfer.json",
            metrics_provider=self._physical_metrics,
            progress_sink=console,
        )

    def _physical_metrics(self) -> dict[str, int]:
        return {
            "unique_physical_frames": self.unique_physical_frames_total,
            "duplicate_physical_frames": (
                self.io.repeated_capture_frames + self.duplicate_physical_frames_total
            ),
            "discarded_physical_frames": (
                self.io.undecodable_capture_frames + self.io.dropped_queue_frames
            ),
            "authentication_failures": (
                self.authentication_failures_total + self.link.authentication_failures
            ),
        }

    def _new_diagnostic(self) -> DiagnosticSession:
        return DiagnosticSession(
            self.settings.role,
            window_size=self.settings.window_size,
            retransmit_seconds=self.settings.retransmit_seconds,
        )

    def _status(self, state: str, reason: str = "") -> None:
        try:
            self._write_status(state, reason)
        except OSError:
            # A reader holding status.json open must not stop run; the next
            # status write replaces it.
            pass

    def _ready(self) -> bool:
        return (self.link.connected and self.profile is not None
                and self.profile.state == "ACTIVE")

    def _diagnosis(self, now: float) -> Diagnosis:
        return diagnose(
            role=self.settings.role,
            handshake_state=self.link.handshake.state,
            capture=self.io.capture_metrics(now),
            presence=self.presence.as_dict(now),
            handshake_seconds=now - self.link_down_since,
            authentication_failures=(
                self.authentication_failures_total + self.link.authentication_failures
            ),
            last_handshake_error=self.last_handshake_error,
        )

    def _hint_tick(self, now: float) -> None:
        """While the link is down, say why every HINT_INTERVAL_SECONDS."""
        if self._ready():
            self.last_hint = now
            return
        if now - self.last_hint < HINT_INTERVAL_SECONDS:
            return
        self.last_hint = now
        diagnosis = self._diagnosis(now)
        state = "RECONNECTING" if self.reconnecting else "CONNECTING"
        console(f"{time.strftime('%H:%M:%S')} WAITING {state} {now - self.link_down_since:.0f}s "
                f"[{diagnosis.code}] {diagnosis.summary}")
        console(f"  次の操作: {diagnosis.action}")
        console(f"  観測: {facts_line(self.io.capture_metrics(now), self.presence.as_dict(now))}")

    def _connect_failure(self, reason: str, diagnosis: Diagnosis, now: float) -> None:
        """Save everything needed to find the cause without the other PC."""
        report = {
            "status": "FAILURE",
            "reason": reason,
            "diagnosis": diagnosis.as_dict(),
            "role": self.settings.role,
            "mode": self.mode,
            "protocol_version": PROTOCOL_VERSION,
            "build": BUILD_TEXT,
            "elapsed_seconds": round(now - self.started, 1),
            "handshake_state": self.link.handshake.state,
            "authentication_failures": (
                self.authentication_failures_total + self.link.authentication_failures
            ),
            "last_handshake_error": self.last_handshake_error,
            "presence": self.presence.as_dict(now),
            "capture": self.io.capture_metrics(now),
            "display": self.io.display_metrics(),
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        try:
            atomic_json(self.connect_report_path, report)
        except OSError:
            pass
        console(f"FAILURE: {reason}")
        console(f"  原因の候補 [{diagnosis.code}]: {diagnosis.summary}")
        console(f"  次の操作: {diagnosis.action}")
        console(f"  詳細: {self.connect_report_path}")

    def _write_status(self, state: str, reason: str) -> None:
        transfer = getattr(self.engine, "transfer", None)
        now = time.monotonic()
        atomic_json(self.status_path, {
            "status": state,
            "reason": reason,
            "role": self.settings.role,
            "mode": self.mode,
            "protocol_version": PROTOCOL_VERSION,
            "build": BUILD_TEXT,
            "diagnosis": None if self._ready() else self._diagnosis(now).as_dict(),
            "presence": self.presence.as_dict(now),
            "capture": self.io.capture_metrics(now),
            "main_loop_max_pause_seconds": round(self.watchdog.max_pause_seconds, 2),
            "connected": self.link.connected,
            "profile_state": self.profile.state if self.profile else "WAIT_LINK",
            "active_profile": self.applied_profile,
            "handshake_state": self.link.handshake.state,
            "session_id": self.link.session_id.hex(),
            "active_transfer": (
                getattr(getattr(transfer, "snapshot", None), "relative_path", None)
                or getattr(transfer, "relative_path", None)
            ),
            "active_transfer_direction": (
                self.engine.transfer_direction
            ),
            "sync_token_owner": self.engine.token_owner,
            "sync_token_epoch": self.engine.token_epoch,
            "authentication_failures": self.authentication_failures_total + self.link.authentication_failures,
            "ignored_handshake_errors": self.handshake_errors_total,
            "transfer_progress_marker_age_seconds": (
                round(time.monotonic() - self.progress_changed_at, 1)
                if self.progress_marker is not None else None
            ),
            "duplicate_secure_messages": self.duplicate_secure_messages_total + self.link.duplicate_secure_messages,
            "transport": {
                **self.io.display_metrics(),
                "retransmitted_chunks": getattr(
                    getattr(self.engine.outbound, "transfer", None),
                    "retransmitted_chunks", 0,
                ),
                "repeated_capture_frames": self.io.repeated_capture_frames,
                "undecodable_capture_frames": self.io.undecodable_capture_frames,
                "dropped_capture_queue_frames": self.io.dropped_queue_frames,
            },
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        })

    def _send_app(self, messages) -> None:
        for kind, payload in messages:
            on_display = None
            if kind in DATA_KINDS:
                transfer_id, index, _ = decode_data(payload)
                transfer = (
                    self.engine.outbound.transfer if kind == MessageKind.FILE_DATA
                    else self.diagnostic.send
                )
                if transfer is not None and transfer.transfer_id == transfer_id:
                    on_display = (
                        lambda displayed_at, reliable=transfer.reliable, chunk_index=index:
                        reliable.mark_displayed(chunk_index, displayed_at)
                    )
            coalesce_key = None
            if kind in ACK_KINDS:
                # A newer selective ACK supersedes an undisplayed older one.
                try:
                    coalesce_key = (int(kind), decode_ack(payload)[0])
                except ValueError:
                    coalesce_key = None
            elif kind not in DATA_KINDS:
                # Periodic control retries (token, requests, announcements) must
                # not pile up while an identical copy is still undisplayed.
                coalesce_key = (int(kind), hashlib.sha256(payload).digest())
            self.io.send(
                self.link.secure(kind, payload),
                priority=kind == MessageKind.KEEPALIVE or kind in ACK_KINDS,
                on_display=on_display,
                profile=self.link.send_profile,
                coalesce_key=coalesce_key,
            )

    def _new_profile(self) -> ProfileNegotiator:
        return ProfileNegotiator(
            "initiator" if self.settings.role == "receiver" else "responder",
            self.link.session_id.hex(),
            supported_profiles=ALLOWED_PROFILES,
            sync_profile=self._sync_profile(),
        )

    def _sync_profile(self) -> str:
        # A candidate whose session was lost is not trusted again by this
        # process; file sync falls back to the proven baseline.
        return BASELINE_PROFILE if self.candidate_failed else self.settings.preferred_profile

    def _sync_allowed(self) -> bool:
        """File sync runs on baseline or on a profile agreed for sync."""
        return self.applied_profile == BASELINE_PROFILE or (
            self.profile is not None and self.profile.purpose == "sync"
        )

    def _send_profile(self, message: dict) -> None:
        payload = json_bytes(message)
        self.io.send(
            self.link.secure(MessageKind.PROFILE_CONTROL, payload, force_baseline=True),
            profile=BASELINE_PROFILE,
            coalesce_key=(int(MessageKind.PROFILE_CONTROL), hashlib.sha256(payload).digest()),
        )

    def _profile_tick(self, now: float) -> None:
        if self.profile is None:
            self.profile = self._new_profile()
        profile = self.profile
        profile.tick(now)
        if profile.state == "FAILED":
            self._status("RECONNECTING", profile.error or "profile agreement failed")
            self._reset_link()
            return
        if profile.state == "IDLE" and self.settings.role == "receiver":
            if self.mode == "profile-test" and not self.candidate_failed:
                proposal = profile.propose(self.test_profile, uuid.uuid4().hex, now, purpose="trial")
            else:
                proposal = profile.propose(self._sync_profile(), uuid.uuid4().hex, now, purpose="sync")
            self._send_profile(proposal)
            self.last_profile_send = now
        elif profile.state != "ACTIVE" and now - self.last_profile_send >= 1.0:
            pending = profile.pending_message(now)
            if pending is not None:
                self._send_profile(pending)
                self.last_profile_send = now
        if profile.state == "ACTIVE" and self.applied_profile != profile.active_profile:
            chunk_bytes = chunk_bytes_for(profile.active_profile)
            self.engine.set_chunk_bytes(chunk_bytes)
            self.diagnostic.set_chunk_bytes(chunk_bytes)
            self.link.set_send_profile(profile.active_profile)
            self.applied_profile = profile.active_profile

    def _reset_link(self) -> None:
        if self.applied_profile != BASELINE_PROFILE:
            self.candidate_failed = True
        self.io.clear_outgoing()
        self.authentication_failures_total += self.link.authentication_failures
        self.duplicate_secure_messages_total += self.link.duplicate_secure_messages
        self.link = LinkSession(self.settings.role, self.password, self.presence)
        self._discard_session_state()

    def _discard_session_state(self) -> None:
        """Drop transfer and profile state that belongs to the previous session."""
        # Undisplayed frames of the old session only delay the new handshake;
        # handshake replies are re-sent periodically.
        self.io.clear_outgoing()
        self.engine.close()
        self.engine = self._new_engine()
        self.diagnostic = self._new_diagnostic()
        self.profile = None
        self.last_profile_send = float("-inf")
        self.applied_profile = BASELINE_PROFILE
        self.link.set_send_profile(BASELINE_PROFILE)
        if self.mode in {"self-test", "profile-test"}:
            self.self_test_payload = None
            self.self_test_started = None
            self.profile_test_metrics_start = None
        self.last_valid_packet = time.monotonic()
        self.handshake_started_at = None
        self.progress_marker = None
        self._seen_packet_order.clear()
        self._seen_packets.clear()
        self.reconnecting = True

    def _progress_marker(self) -> tuple | None:
        """Unique chunks of the active file transfers; None when nothing is moving."""
        outbound = self.engine.outbound.transfer
        inbound = self.engine.inbound.transfer
        if outbound is None and inbound is None:
            return None
        return (
            (outbound.transfer_id, len(outbound.reliable.acked)) if outbound else None,
            (inbound.transfer_id, len(inbound.reliable.received)) if inbound else None,
        )

    def _transfer_stalled(self, now: float) -> bool:
        # Liveness (KEEPALIVE) is not progress (ISSUE-012): a transfer whose
        # unique chunk count stays flat is abandoned and resent from the start.
        marker = self._progress_marker()
        if marker is None or marker != self.progress_marker:
            self.progress_marker = marker
            self.progress_changed_at = now
            return False
        return now - self.progress_changed_at >= TRANSFER_STALL_SECONDS

    def _check_session_change(self) -> None:
        # The sender re-handshakes in place when a restarted receiver announces
        # a new session; state and codec agreed for the old session must go.
        if (self.profile is not None
                and self.profile.session_id != self.link.session_id.hex()):
            self._status("RECONNECTING", "peer started a new session")
            self._discard_session_state()

    def _is_new_physical_packet(self, packet) -> bool:
        identity = (
            packet.session_id, packet.kind, packet.message_id,
            packet.fragment_index, packet.fragment_count,
        )
        if identity in self._seen_packets:
            return False
        self._seen_packets.add(identity)
        self._seen_packet_order.append(identity)
        while len(self._seen_packet_order) > 4096:
            self._seen_packets.discard(self._seen_packet_order.popleft())
        return True

    def _receive_packets(self, now: float) -> None:
        for packet, _active_rect in self.io.receive():
            is_new = self._is_new_physical_packet(packet)
            try:
                outgoing, messages = self.link.receive(packet, now)
            except HandshakeError as error:
                # Before the first READY a key, role or build mismatch is a
                # startup error. Afterwards the app must keep reconnecting.
                self.last_handshake_error = str(error)
                if not self.ever_connected:
                    raise
                self.handshake_errors_total += 1
                continue
            if is_new and self.link.last_authenticated_packet:
                self.last_valid_packet = now
            if is_new:
                self.unique_physical_frames_total += 1
            else:
                self.duplicate_physical_frames_total += 1
            self.io.send(outgoing)
            for kind, payload in messages:
                if kind == MessageKind.KEEPALIVE:
                    continue
                if kind == MessageKind.PROFILE_CONTROL:
                    if not self.link.connected:
                        continue
                    self._check_session_change()
                    if self.profile is None:
                        self.profile = self._new_profile()
                    try:
                        response = self.profile.receive(parse_json(payload), now)
                    except (ProfileAgreementError, ValueError, TypeError) as error:
                        self._status("RECONNECTING", f"profile agreement failed: {error}")
                        self._reset_link()
                        return
                    if response is not None:
                        self._send_profile(response)
                    if self.profile.state == "ACTIVE":
                        self._profile_tick(now)
                    continue
                if self.profile is None or self.profile.state != "ACTIVE":
                    continue
                if self.applied_profile != self.profile.active_profile:
                    continue
                if not self.diagnostic.handles(kind) and (
                        not self._sync_allowed()
                        or self.mode in {"self-test", "profile-test"}):
                    # Explicit candidate trials must not start ordinary file sync,
                    # and diagnostics never touch received/ or the ledger (PD-DEC-026).
                    continue
                handler = self.diagnostic if self.diagnostic.handles(kind) else self.engine
                self._send_app(handler.handle(kind, payload, now))

    def _finish_self_test(self, now: float) -> int:
        elapsed = now - (self.self_test_started or now)
        verified = self.diagnostic.result == self.self_test_payload
        selected_profile = self.profile.active_profile if self.profile else BASELINE_PROFILE
        requested_profile = self.test_profile if self.mode == "profile-test" else self.settings.preferred_profile
        verified = verified and (self.mode != "profile-test" or selected_profile == requested_profile)
        report = {
            "status": "SUCCESS" if verified else "FAILURE",
            "sha256_verified": verified,
            "transport": "selective-repeat-blob",
            "bytes_each_direction": len(self.diagnostic.result),
            "round_trip_seconds": elapsed,
            "directions": self.diagnostic.direction_metrics,
            "requested_profile": requested_profile,
            "active_profile": selected_profile,
            # Settings under test, so AI and operator can compare runs (PD-DEC-039/040).
            "frame_interval_seconds": self.settings.frame_interval_seconds,
            "window_size": self.settings.window_size,
            "retransmit_seconds": self.settings.retransmit_seconds,
            "chunk_bytes": chunk_bytes_for(selected_profile),
            "display_transport": self.io.display_metrics(),
            "physical_metrics_delta": (
                {key: value - self.profile_test_metrics_start.get(key, 0)
                 for key, value in self._physical_metrics().items()}
                if self.profile_test_metrics_start is not None else None
            ),
            "round_trip_goodput_bytes_per_second": (
                len(self.diagnostic.result) * 2 / elapsed if elapsed > 0 else None
            ),
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        atomic_json(self.profile_test_path if self.mode == "profile-test" else self.self_test_path, report)
        self._status(report["status"], "self-test passed" if verified else "self-test mismatch")
        print(json.dumps(report, ensure_ascii=False), flush=True)
        return 0 if verified else 4

    def _fail_profile_test(self, reason: str) -> int:
        report = {
            "status": "FAILURE",
            "reason": reason,
            "requested_profile": (
                self.test_profile if self.mode == "profile-test" else self.settings.preferred_profile
            ),
            "active_profile": self.applied_profile,
            "sha256_verified": False,
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        atomic_json(self.profile_test_path if self.mode == "profile-test" else self.self_test_path, report)
        self._status("FAILURE", f"{self.mode}: {reason}")
        print(json.dumps(report, ensure_ascii=True), flush=True)
        return 4

    def _finish_file_test(self, status: str, reason: str, now: float) -> int:
        request = self.file_test_request
        assert request is not None
        report = {
            "status": status,
            "reason": reason,
            "path": request["path"],
            "return_path": request["return_path"],
            "size": request["size"],
            "sha256": request.get("sha256"),
            "sha256_verified": status == "SUCCESS",
            "round_trip_seconds": (
                now - self.file_test_started if self.file_test_started is not None else None
            ),
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        atomic_json(self.base / "artifacts" / "reports" / "file_test.json", report)
        self._status(status, f"file-test: {reason}")
        print(json.dumps(report, ensure_ascii=True), flush=True)
        return 0 if status == "SUCCESS" else 4

    def _file_test_tick(self, now: float) -> int | None:
        request = self.file_test_request
        if request is None:
            return None
        if self.file_test_started is None:
            self.file_test_started = now
        if now - self.file_test_started >= 600.0:
            return self._finish_file_test("FAILURE", "round trip timed out", now)
        if now - self.last_file_test_arm >= 1.0:
            self.last_file_test_arm = now
            self._send_app([(MessageKind.FILE_ECHO_ARM, json_bytes(request))])
        response = self.engine.file_echo_status
        if response is not None and response.get("id") == request["id"]:
            if response.get("status") == "FAILURE":
                return self._finish_file_test(
                    "FAILURE", str(response.get("reason") or "peer could not return file"), now,
                )
            if response.get("status") in {"ARMED", "COPIED"} and not self.file_test_created:
                assert self.file_test_payload is not None
                try:
                    destination = safe_output_path(self.base / "target", request["path"])
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    descriptor, temporary_name = tempfile.mkstemp(
                        prefix="file-test-", suffix=".tmp",
                        dir=self.base / "artifacts" / "reports",
                    )
                    try:
                        with os.fdopen(descriptor, "wb") as stream:
                            stream.write(self.file_test_payload)
                            stream.flush()
                            os.fsync(stream.fileno())
                        os.link(temporary_name, destination)
                    finally:
                        Path(temporary_name).unlink(missing_ok=True)
                except (OSError, ValueError) as error:
                    return self._finish_file_test(
                        "FAILURE", f"could not create test source: {error}", now,
                    )
                self.file_test_created = True
        if not self.file_test_created:
            return None
        try:
            returned = safe_output_path(self.base / "received", request["return_path"])
            exists = returned.exists()
            verified = (exists and returned.stat().st_size == request["size"]
                        and sha256_file(returned) == request["sha256"])
        except (OSError, ValueError) as error:
            return self._finish_file_test("FAILURE", f"could not inspect returned file: {error}", now)
        if exists:
            if not verified:
                return self._finish_file_test("FAILURE", "returned file size or SHA-256 mismatch", now)
            if (
                self.ledger.is_complete(request["path"], "outgoing")
                and self.ledger.is_complete(request["return_path"], "incoming")
                and self.engine.inbound.transfer is None
                and self.engine.inbound.completed_message is None
            ):
                return self._finish_file_test("SUCCESS", "file returned with matching SHA-256", now)
        return None

    def run(self) -> int:
        try:
            console(f"PixelDuplex protocol v{PROTOCOL_VERSION} build {BUILD_TEXT} "
                    f"role={self.settings.role} mode={self.mode} "
                    f"capture_device={self.settings.capture_device}")
            self.io.start()
            self.watchdog.start()
            self._status("CONNECTING")
            while self.io.pump_display():
                now = time.monotonic()
                pause = self.watchdog.beat(now)
                if pause is not None:
                    console(f"WARNING: main loop paused {pause:.1f}s "
                            "(stacks of pauses over 10 s are in artifacts/logs/hang.log)")
                if not self.io.capture_alive():
                    raise CaptureFailedError("capture worker stopped")
                if (self.mode in {"self-test", "profile-test"}
                        and now - self.started >= self.settings.handshake_timeout_seconds):
                    return self._fail_profile_test(f"{self.mode} timed out")
                if (not self.ever_connected
                        and now - self.started >= self.settings.handshake_timeout_seconds):
                    self._status("FAILURE", "startup connection timeout")
                    self._connect_failure("startup connection timeout", self._diagnosis(now), now)
                    return 3
                self.io.send(self.link.periodic(now))
                self._receive_packets(now)
                self._check_session_change()
                if self.link.connected:
                    self.handshake_started_at = None
                    self.engine.update_session_id(self.link.session_id.hex())
                    if now - self.last_keepalive >= 2.0:
                        self.last_keepalive = now
                        self._send_app([(MessageKind.KEEPALIVE, b"")])
                    self._profile_tick(now)
                    if not self.link.connected:
                        continue
                    profile_ready = self.profile is not None and self.profile.state == "ACTIVE"
                    if profile_ready and (not self.ever_connected or self.reconnecting):
                        # Startup ends only when role, key, protocol and profile agree.
                        self.ever_connected = True
                        self.reconnecting = False
                        self.last_handshake_error = None
                        console(f"CONNECTED role={self.settings.role} "
                                f"session={self.link.session_id.hex()} "
                                f"({now - self.link_down_since:.0f}s)")
                        console("接続しました。target/ のファイルは相手の received/ へ同期されます。")
                    if (profile_ready and self.mode in {"self-test", "profile-test"}
                            and self.settings.role == "receiver" and self.self_test_payload is None):
                        self.self_test_payload = os.urandom(self.test_bytes)
                        self.self_test_started = now
                        if self.mode == "profile-test":
                            self.profile_test_metrics_start = self._physical_metrics()
                        self._send_app(self.diagnostic.start(self.self_test_payload, now))
                    if profile_ready:
                        self._send_app(self.diagnostic.tick(now))
                    if (profile_ready and self._sync_allowed()
                            and self.mode not in {"self-test", "profile-test"}
                            and not self.diagnostic.active):
                        self._send_app(self.engine.tick(now))
                    if self.mode in {"self-test", "profile-test"} and self.diagnostic.finished:
                        return self._finish_self_test(now)
                    if profile_ready and self.mode == "file-test":
                        result = self._file_test_tick(now)
                        if result is not None:
                            return result
                    if now - self.last_valid_packet >= LINK_SILENCE_SECONDS:
                        console("RECONNECTING: no valid captured protocol frame for 15 seconds")
                        self._reset_link()
                        self._status("RECONNECTING", "link silent")
                    elif self._transfer_stalled(now):
                        console("RECONNECTING: transfer made no progress")
                        self._reset_link()
                        self._status("RECONNECTING", "transfer stalled")
                elif (self.link.handshake.state == "CONNECTING"
                        or self.settings.role != "receiver"):
                    # Only the receiver owns the session. A sender that resets
                    # itself only changes its challenge, which a receiver already
                    # in WAIT_PING must ignore (nonce safety): both would wait.
                    self.handshake_started_at = None
                elif self.handshake_started_at is None:
                    self.handshake_started_at = now
                elif now - self.handshake_started_at >= LINK_SILENCE_SECONDS:
                    # The sender never finished this session (e.g. it restarted
                    # after AUTH); a fresh session lets the current sender join.
                    console("RECONNECTING: handshake did not complete")
                    self._reset_link()
                    self._status("RECONNECTING", "handshake did not complete")
                ready = self._ready()
                self.io.link_down = not ready
                if ready:
                    self.link_down_since = now
                self._hint_tick(now)
                if now - self.last_status >= 1.0:
                    self.last_status = now
                    request = stop_request_path(self.base)
                    if request.exists():
                        request.unlink(missing_ok=True)
                        self._status("CANCELLED", "stop requested")
                        console("STOPPED: stop requested")
                        return 130
                    state = "READY" if ready else (
                        "RECONNECTING" if self.reconnecting else "CONNECTING"
                    )
                    self._status(state)
                time.sleep(0.002)
            self._status("CANCELLED", "Escape pressed")
            return 130
        except KeyboardInterrupt:
            self._status("CANCELLED", "Ctrl+C")
            return 130
        except HandshakeError as error:
            # Only raised before the first connection: the peer was found but
            # cannot be joined. Waiting longer would not help.
            now = time.monotonic()
            self._status("FAILURE", str(error))
            self._connect_failure(str(error), diagnose_error(str(error)), now)
            return EXIT_PEER_MISMATCH
        except DisplayLostError as error:
            # The data window must never stay on the primary screen.
            self._status("FAILURE", str(error))
            console(f"FAILURE: {error}")
            console("Restore the extended desktop (Win+P > Extend) and start again.")
            return 1
        except CaptureFailedError as error:
            detail = self.io.capture_metrics(time.monotonic()).get("last_worker_error")
            self._status("FAILURE", f"{error}: {detail}")
            console(f"FAILURE: {error}: {detail}")
            return 1
        finally:
            self.watchdog.stop()
            self.engine.close()
            self.io.close()


def run_command(base: Path, mode: str, *, test_profile: str = DEFAULT_TEST_PROFILE,
                test_bytes: int = DEFAULT_TEST_BYTES) -> int:
    if not MIN_TEST_BYTES <= test_bytes <= MAX_TEST_BYTES:
        raise RuntimeError(
            f"--bytes must be between {MIN_TEST_BYTES} and {MAX_TEST_BYTES}"
        )
    settings = load_settings(base)
    if mode in {"self-test", "file-test", "profile-test"} and settings.role != "receiver":
        raise RuntimeError(f"{mode} must be started on the receiver; run sender normally")
    password = load_password(base)
    for directory in (base / "target", base / "received", base / "artifacts" / "logs", base / "artifacts" / "reports"):
        directory.mkdir(parents=True, exist_ok=True)
    with InstanceLock(base / ".pixelduplex.lock"):
        # A request left from an earlier instance must not stop this one.
        stop_request_path(base).unlink(missing_ok=True)
        with runtime_pid(base, settings.role, mode):
            return Runner(
                base, settings, password, mode,
                test_profile=test_profile, test_bytes=test_bytes,
            ).run()


def print_status(base: Path) -> int:
    path = base / "artifacts" / "reports" / "status.json"
    if not path.exists():
        print(json.dumps({"status": "NOT_RUNNING", "reason": "no status report"}))
        return 1
    print(path.read_text(encoding="utf-8"), end="")
    return 0
