"""Banded physical frames, used only after an authenticated profile agreement.

The screen is split into horizontal bands. Each band is an independent
physical packet with its own header and CRC, and the display replaces one band
at a time (staggered). A capture that straddles a repaint therefore loses at
most the band being replaced, never the whole screen (PD-DEC-040).

Bands keep the proven 2x2 cell geometry. ``mono-band4`` stores 1 bit per cell
(black/white, like the baseline); ``gray4-band4`` stores 2 bits per cell as four
luminance levels, avoiding YUY2 chroma. Each layout has its own magic, so an
unnegotiated decoder never mistakes it for the full-frame baseline format.
"""

from __future__ import annotations

import math
import struct
import zlib
from dataclasses import dataclass
from functools import cached_property

import numpy as np

from .constants import CELL, GRID_H, GRID_W, HEIGHT, PROTOCOL_VERSION, WIDTH
from .crypto import ENVELOPE_HEADER
from .messages import DATA_HEADER
from .wire import PhysicalPacket, normalize_active_image


BANDS = 4
BAND_ROWS = GRID_H // BANDS
BAND_PIXEL_ROWS = BAND_ROWS * CELL
HEADER_BYTES = 64
CRC_BYTES = 4
GCM_TAG_BYTES = 16
HEADER = struct.Struct("<8sBBH16sQIIII")
FULL_RECT = (0, 0, WIDTH, HEIGHT)
PHASES = ((0, 0), (0, 1), (1, 0), (1, 1))
GRAY_LEVELS = np.array([0, 85, 170, 255], dtype=np.uint8)


@dataclass(frozen=True)
class BandLayout:
    profile_id: str
    bits: int
    magic: bytes

    @property
    def band_bytes(self) -> int:
        return GRID_W * BAND_ROWS * self.bits // 8

    @property
    def payload_bytes(self) -> int:
        return self.band_bytes - HEADER_BYTES - CRC_BYTES

    @property
    def chunk_bytes(self) -> int:
        """Largest round file/blob chunk whose sealed message fits one band."""
        room = self.payload_bytes - ENVELOPE_HEADER.size - GCM_TAG_BYTES - DATA_HEADER.size
        return room // 1000 * 1000

    @cached_property
    def whiten(self) -> np.ndarray:
        return np.resize(np.array([0xAA, 0x55], dtype=np.uint8), self.band_bytes)


MONO = BandLayout("mono-band4", 1, b"PXDB5M01")
GRAY4 = BandLayout("gray4-band4", 2, b"PXDB5G01")
LAYOUTS = {layout.profile_id: layout for layout in (MONO, GRAY4)}
PROFILE_IDS = frozenset(LAYOUTS)


def layout_for(profile: str) -> BandLayout:
    try:
        return LAYOUTS[profile]
    except KeyError:
        raise ValueError(f"unsupported band profile: {profile}") from None


def encode_packet(layout: BandLayout, packet: PhysicalPacket) -> bytes:
    if len(packet.session_id) != 16:
        raise ValueError("session_id must be 16 bytes")
    if not 0 <= packet.kind <= 255 or not 0 <= packet.message_id < 1 << 64:
        raise ValueError("packet identifier out of range")
    if not 0 < packet.fragment_count <= 0xFFFFFFFF:
        raise ValueError("invalid fragment_count")
    if not 0 <= packet.fragment_index < packet.fragment_count:
        raise ValueError("invalid fragment_index")
    if len(packet.payload) > layout.payload_bytes:
        raise ValueError("physical payload too large")
    if not 0 <= packet.total_length <= packet.fragment_count * layout.payload_bytes:
        raise ValueError("invalid total_length")
    header = HEADER.pack(
        layout.magic, PROTOCOL_VERSION, packet.kind, HEADER_BYTES,
        packet.session_id, packet.message_id, packet.fragment_index,
        packet.fragment_count, packet.total_length, len(packet.payload),
    )
    body = header.ljust(HEADER_BYTES, b"\0") + packet.payload.ljust(layout.payload_bytes, b"\0")
    return body + struct.pack("<I", zlib.crc32(body))


def decode_packet(layout: BandLayout, raw: bytes) -> PhysicalPacket | None:
    if len(raw) != layout.band_bytes:
        return None
    body, checksum = raw[:-CRC_BYTES], raw[-CRC_BYTES:]
    if zlib.crc32(body) != struct.unpack("<I", checksum)[0]:
        return None
    (magic, version, kind, header_bytes, session_id, message_id,
     index, count, total_length, length) = HEADER.unpack_from(body)
    if magic != layout.magic or version != PROTOCOL_VERSION or header_bytes != HEADER_BYTES:
        return None
    capacity = layout.payload_bytes
    if not count or index >= count or length > capacity:
        return None
    if not (count - 1) * capacity < total_length <= count * capacity:
        if not (count == 1 and total_length == 0 and length == 0):
            return None
    if length != min(capacity, max(0, total_length - index * capacity)):
        return None
    payload = body[HEADER_BYTES:HEADER_BYTES + length]
    return PhysicalPacket(kind, session_id, message_id, index, count, total_length, payload)


def fragment_message(layout: BandLayout, kind: int, session_id: bytes,
                     message_id: int, payload: bytes) -> list[PhysicalPacket]:
    size = layout.payload_bytes
    count = max(1, math.ceil(len(payload) / size))
    return [PhysicalPacket(kind, session_id, message_id, index, count, len(payload),
                           payload[index * size:(index + 1) * size])
            for index in range(count)]


def band_image(layout: BandLayout, packet: PhysicalPacket) -> np.ndarray:
    """Grayscale pixels for one band: BAND_PIXEL_ROWS x WIDTH."""
    raw = np.frombuffer(encode_packet(layout, packet), dtype=np.uint8) ^ layout.whiten
    if layout.bits == 1:
        cells = np.unpackbits(raw, bitorder="big") * np.uint8(255)
    else:
        symbols = np.empty((raw.size, 4), dtype=np.uint8)
        for index, shift in enumerate((6, 4, 2, 0)):
            symbols[:, index] = (raw >> shift) & 3
        cells = GRAY_LEVELS[symbols.reshape(-1)]
    grid = cells.reshape(BAND_ROWS, GRID_W)
    return np.repeat(np.repeat(grid, CELL, axis=0), CELL, axis=1)


def blank_canvas() -> np.ndarray:
    return np.zeros((HEIGHT, WIDTH, 3), dtype=np.uint8)


def paint_band(canvas: np.ndarray, band: int, layout: BandLayout,
               packet: PhysicalPacket) -> None:
    """Replace one band of a BGR canvas in place; other bands stay untouched."""
    if not 0 <= band < BANDS:
        raise ValueError("band index out of range")
    top = band * BAND_PIXEL_ROWS
    canvas[top:top + BAND_PIXEL_ROWS] = band_image(layout, packet)[:, :, None]


def _band_bytes(layout: BandLayout, sampled: np.ndarray, band: int) -> bytes:
    rows = sampled[band * BAND_ROWS:(band + 1) * BAND_ROWS]
    if layout.bits == 1:
        packed = np.packbits((rows >= 128).reshape(-1), bitorder="big")
    else:
        symbols = np.minimum((rows.astype(np.uint16) + 42) // 85, 3).astype(np.uint8)
        groups = symbols.reshape(-1, 4)
        packed = ((groups[:, 0] << 6) | (groups[:, 1] << 4)
                  | (groups[:, 2] << 2) | groups[:, 3]).astype(np.uint8)
    return (packed ^ layout.whiten).tobytes()


def _decode_exact(frame: np.ndarray) -> dict[int, PhysicalPacket]:
    found: dict[int, PhysicalPacket] = {}
    # Try each phase because display scaling can shift cell boundaries by 1px.
    for y, x in PHASES:
        sampled = frame[y::CELL, x::CELL, 0][:GRID_H, :GRID_W]
        if sampled.shape != (GRID_H, GRID_W):
            continue
        for band in range(BANDS):
            if band in found:
                continue
            for layout in LAYOUTS.values():
                packet = decode_packet(layout, _band_bytes(layout, sampled, band))
                if packet is not None:
                    found[band] = packet
                    break
        if len(found) == BANDS:
            break
    return found


def decode_bands(frame: np.ndarray) -> tuple[list[PhysicalPacket], tuple[int, int, int, int] | None]:
    """Return every band packet that passes its own CRC, top to bottom."""
    if getattr(frame, "shape", ())[:2] != (HEIGHT, WIDTH):
        return [], None
    found = _decode_exact(frame)
    rect = FULL_RECT if found else None
    if len(found) < BANDS:
        # A slightly scaled image can pass for some bands 1:1; the others
        # still need the active-area normalization.
        normalized, normalized_rect = normalize_active_image(frame)
        if normalized is not None:
            extra = _decode_exact(normalized)
            if extra and rect is None:
                rect = normalized_rect
            for band, packet in extra.items():
                found.setdefault(band, packet)
    return [found[band] for band in sorted(found)], (rect if found else None)


def render_frame(layout: BandLayout, packets: list[PhysicalPacket]) -> np.ndarray:
    """Whole frame with up to BANDS packets; for tests and offline benchmarks."""
    canvas = blank_canvas()
    for band, packet in enumerate(packets[:BANDS]):
        paint_band(canvas, band, layout, packet)
    return canvas
