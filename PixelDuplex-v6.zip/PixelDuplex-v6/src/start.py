"""One-command start: prepare this folder, check the hardware, then run.

Both PCs extract the same release ZIP and run start-sender.bat or
start-receiver.bat. Everything a first start needs (config.json, key.txt,
folders) is created here, and every check prints the next action in Japanese.
"""

from __future__ import annotations

import getpass
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

from .build import BUILD_TEXT
from .constants import HEIGHT, PROTOCOL_VERSION, PhysicalKind, WIDTH


FIND_CAPTURE_INDICES = range(0, 6)
FIND_CAPTURE_WARMUP_SECONDS = 2.0
FIND_CAPTURE_SAMPLE_SECONDS = 3.0


class StartError(RuntimeError):
    """A setup problem the operator can fix; the message says how."""


def ensure_config(base: Path, role: str) -> bool:
    """Create config.json from the role template, or confirm the existing role.

    Returns True when config.json was created now (first start).
    """
    path = base / "config.json"
    template = base / f"config.{role}.json"
    if not path.exists():
        if not template.exists():
            raise StartError(f"設定テンプレートがありません: {template}")
        shutil.copyfile(template, path)
        print(f"SETUP: {template.name} から config.json を作成しました", flush=True)
        return True
    try:
        current = json.loads(path.read_text(encoding="utf-8")).get("role")
    except (OSError, UnicodeError, json.JSONDecodeError, AttributeError) as error:
        raise StartError(f"config.json を読めません: {error}") from error
    if current != role:
        raise StartError(
            f"config.json の role は {current!r} です。この起動は {role} 用です。"
            f"正しいbatを使うか、config.json を削除して起動し直してください"
        )
    return False


def ensure_key(base: Path, prompt=getpass.getpass, interactive: bool | None = None) -> None:
    """Ask for the shared password once when key.txt is missing or empty."""
    path = base / "key.txt"
    try:
        existing = path.read_text(encoding="utf-8").rstrip("\r\n") if path.exists() else ""
    except (OSError, UnicodeError) as error:
        raise StartError(f"key.txt を読めません: {error}") from error
    if existing:
        return
    if interactive is None:
        interactive = sys.stdin is not None and sys.stdin.isatty()
    if not interactive:
        raise StartError("key.txt がありません。両PCで同じパスワードを1行だけ書いた key.txt を置いてください")
    print("両PCで同じパスワードを入力してください（画面には表示されません）。", flush=True)
    for _ in range(3):
        first = prompt("パスワード: ")
        second = prompt("もう一度: ")
        if first and first == second:
            path.write_text(first, encoding="utf-8")
            print("SETUP: key.txt を保存しました", flush=True)
            return
        print("空か、2回の入力が一致しません。もう一度入力してください。", flush=True)
    raise StartError("パスワードを設定できませんでした")


def run_preflight(base: Path) -> int:
    """Run the read-only preflight and show only what needs attention."""
    completed = subprocess.run(
        [sys.executable, str(base / "tools" / "preflight.py"), "--json"],
        cwd=base, capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    try:
        report = json.loads(completed.stdout)
    except json.JSONDecodeError:
        print(completed.stdout + completed.stderr, flush=True)
        raise StartError("事前診断の結果を読めませんでした")
    for check in report.get("checks", []):
        status = check.get("status")
        if status != "PASS":
            print(f"PREFLIGHT {status} {check.get('name')}: {check.get('summary')}", flush=True)
    overall = report.get("overall_status")
    print(f"PREFLIGHT {overall}", flush=True)
    return {"PASS": 0, "WARN": 1}.get(overall, 2)


def _beacon_facts(packet) -> dict | None:
    from .handshake import BEACON, FLAG_HEARD, ROLE_NAME
    if packet.kind != PhysicalKind.BEACON or len(packet.payload) != BEACON.size:
        return None
    fields = BEACON.unpack(packet.payload)
    return {
        "role": ROLE_NAME.get(fields[1], "unknown"),
        "build": fields[6].hex(),
        "sees_its_peer": bool(fields[2] & FLAG_HEARD),
    }


def probe_capture(index: int, *, warmup: float = FIND_CAPTURE_WARMUP_SECONDS,
                  sample: float = FIND_CAPTURE_SAMPLE_SECONDS) -> dict:
    """Open one DirectShow index briefly and say whether it shows PixelDuplex."""
    from .band_codec import decode_bands
    from .hardware import capture_format, open_capture
    from .wire import decode_image_detail

    capture = open_capture(index)
    try:
        if not capture.isOpened():
            return {"index": index, "opened": False}
        result = {"index": index, "opened": True, "format": capture_format(capture),
                  "reads": 0, "decoded_frames": 0, "foreign_version_frames": 0,
                  "mean_brightness": None, "shape": None, "peer": None}
        started = time.monotonic()
        while time.monotonic() - started < warmup + sample:
            ok, frame = capture.read()
            if not ok or frame is None:
                time.sleep(0.05)
                continue
            if time.monotonic() - started < warmup:
                continue
            result["reads"] += 1
            result["shape"] = list(frame.shape)
            result["mean_brightness"] = round(float(frame[::16, ::16].mean()), 1)
            packet, _rect, foreign = decode_image_detail(frame)
            packets = [packet] if packet is not None else decode_bands(frame)[0]
            if foreign is not None:
                result["foreign_version_frames"] += 1
            if packets:
                result["decoded_frames"] += 1
            for item in packets:
                facts = _beacon_facts(item)
                if facts is not None:
                    result["peer"] = facts
        return result
    finally:
        capture.release()


def describe_probe(item: dict) -> str:
    if not item["opened"]:
        return f"index {item['index']}: 開けません（デバイスなし）"
    fmt = item["format"]
    text = (f"index {item['index']}: {fmt.get('width')}x{fmt.get('height')} "
            f"{fmt.get('fourcc')} 読取{item['reads']} 復号{item['decoded_frames']} "
            f"平均輝度{item['mean_brightness']}")
    if item["decoded_frames"]:
        text += " → PixelDuplexの画面が見えています"
        peer = item.get("peer")
        if peer:
            same = "一致" if peer["build"] == BUILD_TEXT else f"不一致（相手 {peer['build']}）"
            text += f"（相手 role={peer['role']}、build {same}）"
    elif item["foreign_version_frames"]:
        text += " → 別のバージョンのPixelDuplexが見えています（相手も同じZIPにしてください）"
    elif (fmt.get("width"), fmt.get("height")) != (WIDTH, HEIGHT):
        text += " → 1920x1080ではありません（Webカメラ等の可能性）"
    elif item["reads"] == 0:
        text += " → 映像が届きません"
    else:
        text += " → 映像はあるがPixelDuplexではありません（相手が未起動か、通常デスクトップ）"
    return text


def find_capture(base: Path, *, write: bool = False, indices=FIND_CAPTURE_INDICES) -> int:
    """Scan capture indices; the peer's PixelDuplex window must be showing."""
    from .app import instance_running
    if instance_running(base):
        print("REFUSED: このフォルダの run が動作中です。キャプチャ競合を避けるため停止してから実行してください", flush=True)
        return 2
    print("キャプチャ番号を調べます。相手PCで PixelDuplex を起動しておくと判定できます。", flush=True)
    results = []
    for index in indices:
        item = probe_capture(index)
        results.append(item)
        print("  " + describe_probe(item), flush=True)
        if not item["opened"]:
            break  # DirectShow numbers devices without gaps
    report = base / "artifacts" / "reports" / "find_capture.json"
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps({"protocol_version": PROTOCOL_VERSION, "build": BUILD_TEXT,
                                  "results": results}, ensure_ascii=False, indent=2),
                      encoding="utf-8")
    matches = [item["index"] for item in results if item.get("decoded_frames")]
    full_hd = [item["index"] for item in results if item.get("opened")
               and (item["format"].get("width"), item["format"].get("height")) == (WIDTH, HEIGHT)]
    if len(matches) == 1:
        index = matches[0]
        print(f"RESULT: capture_device は {index} です（相手の画面で確認済み）", flush=True)
        code = 0
    elif not matches and len(full_hd) == 1:
        # Without the peer's screen the only 1920x1080 device is the best guess;
        # the run's diagnosis confirms it once the peer starts.
        index = full_hd[0]
        print(f"RESULT: 1920x1080のキャプチャは {index} だけです。相手の画面では未確認のため、"
              "相手PCでPixelDuplexを起動してからもう一度実行すると確定できます", flush=True)
        code = 3
    elif not matches:
        print("RESULT: PixelDuplexの画面が見えるキャプチャはありません。"
              "相手PCでPixelDuplexが起動しているか、HDMIケーブルの接続先を確認してください", flush=True)
        return 1
    else:
        print(f"RESULT: 候補が複数あります {matches}。config.json の capture_device を手で設定してください", flush=True)
        return 1
    if write:
        path = base / "config.json"
        value = json.loads(path.read_text(encoding="utf-8"))
        value["capture_device"] = index
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"SETUP: config.json の capture_device を {index} にしました", flush=True)
    return code


def start(base: Path, role: str, *, check_only: bool = False) -> int:
    """Prepare this folder and run; the same steps on both PCs."""
    from .app import run_command
    print(f"PixelDuplex v{PROTOCOL_VERSION} build {BUILD_TEXT} ({role})", flush=True)
    print("相手PCでも同じ build が表示されることを確認してください。", flush=True)
    try:
        first_start = ensure_config(base, role)
        ensure_key(base)
    except StartError as error:
        print(f"FAILURE: {error}", flush=True)
        return 2
    if first_start:
        # The template's capture_device is only a default; pick this PC's
        # 1920x1080 capture before the first run.
        find_capture(base, write=True)
    for name in ("target", "received"):
        (base / name).mkdir(exist_ok=True)
    preflight = run_preflight(base)
    if preflight == 2:
        print("FAILURE: 事前診断が失敗しました。上の FAIL 行の内容を直してから起動し直してください", flush=True)
        return 2
    print(f"送信するファイルの置き場所: {base / 'target'}", flush=True)
    print(f"受信したファイルの保存先: {base / 'received'}", flush=True)
    if check_only:
        return 0
    print("起動します。停止はデータ画面で Esc、またはこの画面で Ctrl+C。", flush=True)
    return run_command(base, "run")
