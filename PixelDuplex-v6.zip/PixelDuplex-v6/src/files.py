"""Filesystem boundary and file-integrity helpers."""

from __future__ import annotations

import hashlib
import os
import stat
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from .constants import FILE_CHUNK_BYTES


WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


class HashCancelled(RuntimeError):
    """A background hash stopped because the engine is closing."""


def sha256_file(path: Path, stop: threading.Event | None = None) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            if stop is not None and stop.is_set():
                raise HashCancelled(f"hash cancelled: {path}")
            digest.update(block)
    return digest.hexdigest()


def normalized_relative(root: Path, path: Path) -> str:
    relative = path.relative_to(root)
    return PurePosixPath(*relative.parts).as_posix()


def is_regular_without_reparse(path: Path) -> bool:
    try:
        info = path.lstat()
    except OSError:
        return False
    if path.is_symlink() or not stat.S_ISREG(info.st_mode):
        return False
    reparse = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    attributes = getattr(info, "st_file_attributes", 0)
    return not bool(attributes & reparse)


def _is_plain_directory(path: Path) -> bool:
    """A directory that may vanish while scanning is skipped, not an error."""
    try:
        info = path.lstat()
    except OSError:
        return False
    return (stat.S_ISDIR(info.st_mode)
            and not bool(getattr(info, "st_file_attributes", 0) & 0x400))


def scan_regular_files(root: Path) -> list[Path]:
    root.mkdir(parents=True, exist_ok=True)
    result: list[Path] = []
    for directory, directory_names, filenames in os.walk(root, followlinks=False):
        base = Path(directory)
        directory_names[:] = [
            name for name in directory_names if _is_plain_directory(base / name)
        ]
        for name in filenames:
            candidate = base / name
            if is_regular_without_reparse(candidate):
                result.append(candidate)
    return sorted(result, key=lambda path: normalized_relative(root, path).casefold())


@dataclass(frozen=True)
class FileSnapshot:
    relative_path: str
    size: int
    mtime_ns: int
    sha256: str


def snapshot_file(root: Path, path: Path, stop: threading.Event | None = None) -> FileSnapshot:
    before = path.stat()
    digest = sha256_file(path, stop)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise RuntimeError(f"file changed while hashing: {path}")
    return FileSnapshot(
        normalized_relative(root, path), after.st_size, after.st_mtime_ns, digest,
    )


class StabilityTracker:
    def __init__(self, stable_seconds: float):
        self.stable_seconds = stable_seconds
        self._seen: dict[str, tuple[int, int, float]] = {}

    def observe(self, relative_path: str, size: int, mtime_ns: int,
                now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        previous = self._seen.get(relative_path)
        if previous is None or previous[:2] != (size, mtime_ns):
            self._seen[relative_path] = (size, mtime_ns, now)
            return False
        return now - previous[2] >= self.stable_seconds


def validate_relative_path(value: str) -> PurePosixPath:
    if not value or "\\" in value or "\0" in value:
        raise ValueError("invalid relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError("path must be a normalized relative path")
    for part in path.parts:
        stem = part.rstrip(" .").split(".", 1)[0].upper()
        if stem in WINDOWS_RESERVED or part.endswith((" ", ".")):
            raise ValueError("path contains a Windows-reserved component")
        if any(character in '<>:"|?*' for character in part):
            raise ValueError("path contains a Windows-invalid character")
    return path


def safe_output_path(root: Path, relative_path: str) -> Path:
    relative = validate_relative_path(relative_path)
    root_resolved = root.resolve()
    current = root_resolved
    for part in relative.parts[:-1]:
        current = current / part
        if current.exists() and (current.is_symlink() or not current.is_dir()):
            raise ValueError("output parent is not a safe directory")
    output = root_resolved.joinpath(*relative.parts)
    if output.exists() and output.is_symlink():
        raise ValueError("output path is a symbolic link")
    if os.path.commonpath([str(root_resolved), str(output.resolve(strict=False))]) != str(root_resolved):
        raise ValueError("output path escapes received directory")
    return output


def file_chunks(path: Path, chunk_bytes: int = FILE_CHUNK_BYTES):
    with path.open("rb") as stream:
        index = 0
        while True:
            block = stream.read(chunk_bytes)
            if not block:
                break
            yield index, block
            index += 1
        if index == 0:
            yield 0, b""


TEMPORARY_SUFFIX = ".pdtmp"


class AtomicReceiver:
    """Random-access temporary writer published only after size and SHA-256 match.

    The SHA-256 advances while chunks arrive: each time the contiguous prefix
    grows, the new chunks are read back from the temporary file and hashed.
    Publishing a large file therefore never stalls the display loop for a
    whole-file hash (ISSUE-014).

    The temporary name carries a per-transfer tag and is created exclusively, so
    it can never be an already received file; abort removes only that file.
    """

    def __init__(self, destination: Path, expected_size: int, expected_sha256: str,
                 chunk_count: int, chunk_bytes: int = FILE_CHUNK_BYTES,
                 temp_tag: str | None = None):
        self.destination = destination
        tag = temp_tag or uuid.uuid4().hex
        self.part = destination.with_name(f".{destination.name}.{tag}{TEMPORARY_SUFFIX}")
        self.expected_size = expected_size
        self.expected_sha256 = expected_sha256
        self.chunk_count = chunk_count
        self.chunk_bytes = chunk_bytes
        self.received: set[int] = set()
        self._digest = hashlib.sha256()
        self._hashed_chunks = 0
        destination.parent.mkdir(parents=True, exist_ok=True)
        self._stream = self.part.open("x+b")
        self._owned = True
        try:
            self._stream.truncate(expected_size)
        except OSError:
            self.abort()
            raise

    def write(self, index: int, payload: bytes) -> bool:
        if not 0 <= index < self.chunk_count:
            raise ValueError("chunk index out of range")
        expected = (
            self.expected_size - self.chunk_bytes * index
            if index == self.chunk_count - 1 else self.chunk_bytes
        )
        if len(payload) != expected:
            raise ValueError("chunk length does not match metadata")
        self._stream.seek(index * self.chunk_bytes)
        if index in self.received:
            if self._stream.read(len(payload)) != payload:
                raise ValueError("duplicate chunk has different bytes")
            return False
        self._stream.write(payload)
        self.received.add(index)
        self._advance_digest()
        return True

    def _advance_digest(self) -> None:
        while self._hashed_chunks in self.received:
            index = self._hashed_chunks
            self._stream.seek(index * self.chunk_bytes)
            length = (self.expected_size - self.chunk_bytes * index
                      if index == self.chunk_count - 1 else self.chunk_bytes)
            block = self._stream.read(length)
            if len(block) != length:
                raise ValueError("temporary file is shorter than its chunks")
            self._digest.update(block)
            self._hashed_chunks += 1

    def complete(self) -> bool:
        return len(self.received) == self.chunk_count

    def publish(self) -> None:
        if not self.complete():
            raise RuntimeError("cannot publish incomplete file")
        self._stream.flush()
        os.fsync(self._stream.fileno())
        self._stream.close()
        if self.part.stat().st_size != self.expected_size:
            self.abort()
            raise RuntimeError("received size mismatch")
        if self._hashed_chunks != self.chunk_count or self._digest.hexdigest() != self.expected_sha256:
            self.abort()
            raise RuntimeError("received SHA-256 mismatch")
        if self.destination.exists():
            self.abort()
            raise FileExistsError("destination appeared during transfer")
        os.replace(self.part, self.destination)
        self._owned = False

    def abort(self) -> None:
        if not self._stream.closed:
            self._stream.close()
        if self._owned:
            self._owned = False
            self.part.unlink(missing_ok=True)
