"""Explain, from one PC, why the link is not up and what to do next (ISSUE-017).

Everything here is a pure function of observations the running process
already has: capture statistics, what the peer's beacon says, and handshake
errors. The result is shown on the console every HINT_INTERVAL_SECONDS while
not connected, written into status.json, and saved as a report on failure.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass

from .constants import HEIGHT, WIDTH


HINT_INTERVAL_SECONDS = 10.0
# A read or a peer frame older than this counts as "not now".
STALE_SECONDS = 5.0
# Mean capture brightness below this looks like no HDMI signal.
BLACK_MEAN = 8.0
# Both screens are seen but the handshake has not finished for this long.
SLOW_HANDSHAKE_SECONDS = 30.0

FIND_CAPTURE = ("このPCのPixelDuplexを Esc で止め、相手PCは起動したまま find-capture.bat を実行して"
                "capture_device を自動設定する")


@dataclass(frozen=True)
class Diagnosis:
    code: str
    summary: str
    action: str

    def as_dict(self) -> dict:
        return asdict(self)


def _age(value) -> float | None:
    return value if isinstance(value, (int, float)) else None


def diagnose_error(error: str) -> Diagnosis:
    """Startup errors that stop the process: role, build or key mismatch."""
    text = str(error)
    if "both endpoints are configured as" in text:
        role = text.rsplit(" ", 1)[-1]
        return Diagnosis(
            "SAME_ROLE",
            f"両方のPCが {role} として起動している。",
            "片方の config.json を config.sender.json、もう片方を config.receiver.json の内容にする"
            "（start-sender.bat / start-receiver.bat を使い分ける）。",
        )
    if "peer runs build" in text:
        return Diagnosis(
            "BUILD_MISMATCH",
            f"相手PCと、このPCのプログラムが異なる（{text}）。",
            "両方のPCで同じv6のZIPを展開し、そのフォルダから起動する。",
        )
    if "AUTHENTICATION_FAILED" in text:
        return Diagnosis(
            "KEY_MISMATCH",
            "相手の認証要求を検証できなかった。key.txt のパスワードが相手と違う可能性が高い"
            "（通信の破損でも起こり得る）。",
            "両方のPCの key.txt を同じパスワードにして再起動する。",
        )
    return Diagnosis("HANDSHAKE_ERROR", f"接続処理でエラー: {text}", "両方のPCで再起動する。")


def diagnose(*, role: str, handshake_state: str, capture: dict, presence: dict,
             handshake_seconds: float | None = None,
             authentication_failures: int = 0,
             last_handshake_error: str | None = None) -> Diagnosis:
    """The most likely reason the link is down, checked from our end outward."""
    peer = "受信側" if role == "sender" else "送信側"
    if capture.get("worker_alive") is False:
        return Diagnosis(
            "CAPTURE_WORKER_STOPPED",
            f"キャプチャ処理が停止した（{capture.get('last_worker_error')}）。",
            "PixelDuplexを再起動する。再発する場合は artifacts/logs/ を添えて報告する。",
        )
    read_age = _age(capture.get("last_read_age_seconds"))
    if read_age is None or read_age > STALE_SECONDS:
        return Diagnosis(
            "CAPTURE_NOT_READING",
            "USBキャプチャから映像を読めていない"
            + ("（一度も読めていない）。" if read_age is None else f"（最後の読み取りは{read_age:.0f}秒前）。"),
            "USBキャプチャの接続を確認し、PixelDuplexを再起動する。直らなければ、"
            f"{FIND_CAPTURE}。",
        )
    shape = capture.get("last_frame_shape")
    if shape and tuple(shape[:2]) != (HEIGHT, WIDTH):
        return Diagnosis(
            "CAPTURE_WRONG_MODE",
            f"キャプチャ映像が {shape[1]}x{shape[0]} で、1920x1080ではない。"
            "capture_device がUSBキャプチャ以外（内蔵カメラ等）を指している可能性がある。",
            f"{FIND_CAPTURE}。",
        )
    own_age = _age(presence.get("own_screen_seen_age_seconds"))
    if own_age is not None and own_age <= STALE_SECONDS:
        return Diagnosis(
            "OWN_SCREEN_CAPTURED",
            "このPC自身のデータ画面が、このPCのキャプチャに映っている。",
            "HDMIケーブルを確認する。このPCのHDMI出力は相手PCのキャプチャへ、"
            "相手PCのHDMI出力はこのPCのキャプチャへつなぐ。",
        )
    peer_age = _age(presence.get("last_peer_frame_age_seconds"))
    if capture.get("foreign_version_frames") and (peer_age is None or peer_age > STALE_SECONDS):
        return Diagnosis(
            "PEER_OTHER_VERSION",
            f"相手PCは別の版（プロトコルv{capture.get('last_foreign_version')}）で動いている。",
            "両方のPCで同じv6のZIPを展開し、そのフォルダから起動する。",
        )
    if peer_age is None or peer_age > STALE_SECONDS:
        lost = "" if peer_age is None else f"{peer_age:.0f}秒前から"
        mean = _age(capture.get("last_frame_mean_brightness"))
        if mean is not None and mean < BLACK_MEAN:
            return Diagnosis(
                "CAPTURE_BLACK",
                f"キャプチャ映像が{lost}真っ黒（無信号の可能性）。",
                f"相手PCの電源、HDMIケーブル（相手の出力→このPCのキャプチャ）、"
                "相手PCの表示モードが「拡張」かを確認する。",
            )
        if peer_age is None:
            return Diagnosis(
                "PEER_SCREEN_NOT_SEEN",
                f"キャプチャに{peer}のデータ画面が映っていない（通常のデスクトップ等が映っている）。",
                f"{peer}のPCでPixelDuplexが起動し、白黒のデータ画面がHDMI出力側の画面に出ているかを確認する。"
                f"相手が起動済みなら capture_device の番号違いの可能性がある。{FIND_CAPTURE}。",
            )
        return Diagnosis(
            "PEER_SCREEN_LOST",
            f"{peer}のデータ画面が{lost}届かない。",
            f"{peer}のPCでPixelDuplexが動いているか（終了・停止していないか）を確認する。",
        )
    if presence.get("peer_sees_us") is False:
        return Diagnosis(
            "PEER_DOES_NOT_SEE_US",
            f"{peer}の画面は見えているが、{peer}はこのPCの画面を受信できていない。",
            f"このPCのHDMI出力→{peer}PCのUSBキャプチャの経路を確認する。"
            f"{peer}PCの画面の WAITING 行に原因が出る。番号違いなら{peer}PCで find-capture.bat を実行する。",
        )
    if last_handshake_error:
        return diagnose_error(last_handshake_error)
    if (handshake_seconds is not None and handshake_seconds >= SLOW_HANDSHAKE_SECONDS):
        return Diagnosis(
            "HANDSHAKE_SLOW",
            f"双方の画面は見えているが、認証が{handshake_seconds:.0f}秒終わらない"
            f"（状態 {handshake_state}、認証失敗 {authentication_failures} 回）。",
            "映像の乱れ（ケーブル・スケーリング）を確認し、両方のPCで再起動する。"
            "認証失敗が増える場合は key.txt が同じかを確認する。",
        )
    return Diagnosis(
        "HANDSHAKE_IN_PROGRESS",
        f"双方の画面が見えている。認証中（状態 {handshake_state}）。",
        "そのまま待つ。",
    )


def facts_line(capture: dict, presence: dict) -> str:
    """One line of raw observations to back the diagnosis."""
    fmt = capture.get("format") or {}
    shape = capture.get("last_frame_shape")
    size = f"{shape[1]}x{shape[0]}" if shape and len(shape) >= 2 else "未取得"
    seen = presence.get("we_see_peer")
    heard = presence.get("peer_sees_us")
    return (
        f"キャプチャ番号{capture.get('device')} {size} {fmt.get('fourcc') or '?'} "
        f"読取{capture.get('reads_per_second') or 0}回/秒 復号{capture.get('decoded_frames', 0)}枚 "
        f"平均輝度{capture.get('last_frame_mean_brightness')} 再オープン{capture.get('reopens', 0)}回"
        f" / 相手の画面: {'見えている' if seen else '見えていない'}"
        f" / 相手はこちらを: {'受信中' if heard else ('受信できていない' if heard is False else '不明')}"
        + (f" / 相手ビルド {presence.get('peer_build')}" if presence.get("peer_build") else "")
    )
