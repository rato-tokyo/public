"""Fixed protocol constants for the current PixelDuplex protocol."""

from __future__ import annotations

from enum import IntEnum


PROTOCOL_VERSION = 6
WIDTH, HEIGHT, CELL = 1920, 1080, 2
GRID_W, GRID_H = WIDTH // CELL, HEIGHT // CELL
FRAME_BYTES = GRID_W * GRID_H // 8
PHYSICAL_HEADER_BYTES = 64
CRC_BYTES = 4
PHYSICAL_PAYLOAD_BYTES = FRAME_BYTES - PHYSICAL_HEADER_BYTES - CRC_BYTES
FILE_CHUNK_BYTES = 60_000
# Same provisional values as the config templates; window 8 with retransmit
# 1.0 s matched the v4 stall ratio (ISSUE-012).
DEFAULT_WINDOW_SIZE = 64
DEFAULT_FRAME_INTERVAL_SECONDS = 0.125
DEFAULT_RETRANSMIT_SECONDS = 2.0
DEFAULT_SCAN_INTERVAL_SECONDS = 5.0
DEFAULT_STABLE_SECONDS = 10.0
DEFAULT_HANDSHAKE_TIMEOUT_SECONDS = 300.0


class PhysicalKind(IntEnum):
    BEACON = 1
    AUTH = 2
    READY = 3
    SECURE = 4


class MessageKind(IntEnum):
    PING = 1
    PONG = 2
    MANIFEST_REQUEST = 3
    MANIFEST = 4
    FILE_ANNOUNCE = 5
    FILE_REQUEST = 6
    FILE_META = 7
    FILE_DATA = 8
    FILE_ACK = 9
    FILE_COMPLETE = 10
    COMPLETE_CONFIRM = 11
    ALREADY_COMPLETE = 12
    CONFLICT = 13
    KEEPALIVE = 14
    SYNC_TOKEN = 15
    BLOB_META = 16
    BLOB_DATA = 17
    BLOB_ACK = 18
    BLOB_COMPLETE = 19
    BLOB_COMPLETE_ACK = 20
    FILE_ECHO_ARM = 21
    FILE_ECHO_RESULT = 22
    PROFILE_CONTROL = 23
    # Receiver -> sender: this path is held (conflict or failure) for the session.
    FILE_REJECTED = 24
    # Sender -> receiver: the requested path cannot be sent now; drop the request.
    FILE_UNAVAILABLE = 25
