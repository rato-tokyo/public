"""Small authenticated startup handshake for the bidirectional link."""

from __future__ import annotations

import hmac
import os
import struct
from dataclasses import dataclass

from .build import BUILD_ID, BUILD_ID_BYTES
from .constants import MessageKind, PhysicalKind, PROTOCOL_VERSION
from .crypto import (
    CHALLENGE_BYTES, PROOF_BYTES, SALT_BYTES, SecureChannel, derive_root_key,
    receiver_proof, sender_proof,
)


NONCE_BYTES = 8
# protocol, role, flags, session, salt, challenge, build, nonce, heard nonce
BEACON = struct.Struct(f"<BBB16s16s16s{BUILD_ID_BYTES}s{NONCE_BYTES}s{NONCE_BYTES}s")
AUTH = struct.Struct("<16s32s")
ROLE_ID = {"sender": 1, "receiver": 2}
ROLE_NAME = {value: key for key, value in ROLE_ID.items()}
EMPTY_SESSION_ID = b"\0" * 16
EMPTY_CHALLENGE = b"\0" * CHALLENGE_BYTES
EMPTY_NONCE = b"\0" * NONCE_BYTES
PING_PAYLOAD = f"PixelDuplex-v{PROTOCOL_VERSION}".encode("ascii")
# Beacon flag: this endpoint decoded a frame of the peer within HEARD_SECONDS.
FLAG_HEARD = 0x01
HEARD_SECONDS = 3.0


class HandshakeError(RuntimeError):
    pass


class BuildMismatchError(HandshakeError):
    """The peer runs different code. Both PCs must extract the same release."""


class StaleProofError(HandshakeError):
    """A READY proof that does not match this sender's challenge.

    A receiver still in an old session keeps repeating READY for the previous
    sender's challenge, so a mismatch is not proof of a wrong key. The receiver
    detects a real key mismatch when it verifies AUTH.
    """


class Presence:
    """What each endpoint knows about the video path in both directions.

    It outlives link sessions, so the process nonce stays the same across
    reconnects. The beacon tells the peer whether we see its screen; the
    peer's beacon tells us whether it sees ours. Nothing here is trusted for
    security: it only explains why a connection does not form.
    """

    def __init__(self, nonce: bytes | None = None):
        self.nonce = nonce or os.urandom(NONCE_BYTES)
        self.last_peer_frame_at: float | None = None
        self.last_peer_beacon_at: float | None = None
        self.peer_nonce = EMPTY_NONCE
        self.peer_role: str | None = None
        self.peer_build: str | None = None
        self.peer_hears_us: bool | None = None
        self.own_beacon_seen_at: float | None = None
        self.peer_restarts = 0

    def hears_peer(self, now: float) -> bool:
        return (self.last_peer_frame_at is not None
                and now - self.last_peer_frame_at <= HEARD_SECONDS)

    def peer_frame(self, now: float) -> None:
        self.last_peer_frame_at = now

    def as_dict(self, now: float) -> dict:
        def age(value: float | None) -> float | None:
            return None if value is None else round(now - value, 1)
        return {
            "we_see_peer": self.hears_peer(now),
            "peer_sees_us": self.peer_hears_us,
            "last_peer_frame_age_seconds": age(self.last_peer_frame_at),
            "last_peer_beacon_age_seconds": age(self.last_peer_beacon_at),
            "own_screen_seen_age_seconds": age(self.own_beacon_seen_at),
            "peer_role": self.peer_role,
            "peer_build": self.peer_build,
            "peer_process_restarts": self.peer_restarts,
        }


@dataclass(frozen=True)
class OutgoingHandshake:
    physical_kind: int
    session_id: bytes
    payload: bytes


class Handshake:
    def __init__(self, role: str, password: str, presence: Presence | None = None):
        if role not in ROLE_ID:
            raise ValueError("role must be sender or receiver")
        self.role = role
        self.password = password
        self.presence = presence or Presence()
        self.state = "CONNECTING"
        self.channel: SecureChannel | None = None
        self.session_id = os.urandom(16) if role == "receiver" else EMPTY_SESSION_ID
        self.salt = os.urandom(SALT_BYTES) if role == "receiver" else b"\0" * SALT_BYTES
        self.receiver_challenge = (
            os.urandom(CHALLENGE_BYTES) if role == "receiver" else EMPTY_CHALLENGE
        )
        self.sender_challenge = EMPTY_CHALLENGE
        self.root_key: bytes | None = None
        # scrypt blocks the display loop for tens of milliseconds; repeated
        # beacons and AUTH retries of one session must not recompute it.
        self._root_keys: dict[bytes, bytes] = {}

    @property
    def connected(self) -> bool:
        return self.state == "CONNECTED"

    def _root_key(self, salt: bytes) -> bytes:
        key = self._root_keys.get(salt)
        if key is None:
            key = derive_root_key(self.password, salt)
            self._root_keys = {salt: key}
        return key

    def beacon(self, now: float) -> OutgoingHandshake:
        presence = self.presence
        payload = BEACON.pack(
            PROTOCOL_VERSION, ROLE_ID[self.role],
            FLAG_HEARD if presence.hears_peer(now) else 0,
            self.session_id, self.salt, self.receiver_challenge,
            BUILD_ID, presence.nonce, presence.peer_nonce,
        )
        return OutgoingHandshake(PhysicalKind.BEACON, self.session_id, payload)

    def receive_plain(self, kind: int, session_id: bytes, payload: bytes,
                      now: float) -> OutgoingHandshake | None:
        if kind == PhysicalKind.BEACON:
            return self._receive_beacon(payload, now)
        # AUTH and READY are only ever sent by the other role.
        self.presence.peer_frame(now)
        if session_id == self.session_id and session_id != EMPTY_SESSION_ID:
            # AUTH answers our beacon and READY answers our AUTH: the peer
            # decodes our screen even though it no longer sends beacons.
            self.presence.peer_hears_us = True
        if self.role == "receiver" and kind == PhysicalKind.AUTH:
            return self._receive_auth(session_id, payload)
        if self.role == "sender" and kind == PhysicalKind.READY:
            return self._receive_ready(session_id, payload)
        return None

    def _observe_beacon(self, payload: bytes, now: float) -> tuple | None:
        """Record what the beacon says about the video path; None for our own."""
        if len(payload) != BEACON.size:
            return None
        (version, remote_role, flags, session, salt, challenge, build, nonce,
         heard_nonce) = BEACON.unpack(payload)
        presence = self.presence
        if nonce == presence.nonce:
            # Our own screen reached our own capture: a cabling or capture
            # index mistake, not a peer with the same role.
            presence.own_beacon_seen_at = now
            return None
        presence.peer_frame(now)
        presence.last_peer_beacon_at = now
        if presence.peer_nonce not in (EMPTY_NONCE, nonce):
            presence.peer_restarts += 1
        presence.peer_nonce = nonce
        presence.peer_role = ROLE_NAME.get(remote_role, f"unknown({remote_role})")
        presence.peer_build = build.hex()
        presence.peer_hears_us = bool(flags & FLAG_HEARD) and heard_nonce == presence.nonce
        return version, remote_role, session, salt, challenge, build

    def _receive_beacon(self, payload: bytes, now: float) -> OutgoingHandshake | None:
        observed = self._observe_beacon(payload, now)
        if observed is None:
            return None
        # Frames of another protocol version never get here: the physical
        # layer counts and drops them (wire.decode_image_detail).
        _version, remote_role, session, salt, challenge, build = observed
        if remote_role == ROLE_ID[self.role]:
            raise HandshakeError(f"both endpoints are configured as {self.role}")
        if build != BUILD_ID:
            raise BuildMismatchError(
                f"peer runs build {build.hex()}, this PC runs {BUILD_ID.hex()}; "
                "extract the same release ZIP on both PCs"
            )
        if self.role == "receiver":
            return self.beacon(now)
        if remote_role != ROLE_ID["receiver"]:
            return None
        if self.channel is not None:
            if session == self.session_id:
                return None  # late duplicate beacon of the established session
            # A restarted receiver announced a new session: drop the old channel.
            self.channel = None
            self.sender_challenge = EMPTY_CHALLENGE
        elif self.state == "WAIT_READY" and session == self.session_id:
            # AUTH for this session is already repeated by the link.
            return None
        self.session_id, self.salt, self.receiver_challenge = session, salt, challenge
        self.root_key = self._root_key(self.salt)
        if self.sender_challenge == EMPTY_CHALLENGE:
            self.sender_challenge = os.urandom(CHALLENGE_BYTES)
        proof = sender_proof(
            self.root_key, self.session_id, self.receiver_challenge,
            self.sender_challenge,
        )
        self.state = "WAIT_READY"
        return OutgoingHandshake(
            PhysicalKind.AUTH, self.session_id,
            AUTH.pack(self.sender_challenge, proof),
        )

    def _receive_auth(self, session_id: bytes, payload: bytes) -> OutgoingHandshake | None:
        if session_id != self.session_id or len(payload) != AUTH.size:
            return None
        challenge, proof = AUTH.unpack(payload)
        if self.channel is not None and challenge != self.sender_challenge:
            # Channel keys depend only on salt and session. A restarted sender
            # must not join this session, or it would reuse AES-GCM nonces.
            return None
        root = self._root_key(self.salt)
        expected = sender_proof(root, self.session_id, self.receiver_challenge, challenge)
        if not hmac.compare_digest(proof, expected):
            raise HandshakeError("AUTHENTICATION_FAILED: key mismatch or damaged link")
        self.root_key, self.sender_challenge = root, challenge
        if self.channel is None:
            self.channel = SecureChannel.create("receiver", root, self.session_id)
            self.state = "WAIT_PING"
        proof = receiver_proof(root, self.session_id, self.receiver_challenge, challenge)
        return OutgoingHandshake(PhysicalKind.READY, self.session_id, proof)

    def _receive_ready(self, session_id: bytes, payload: bytes) -> None:
        if session_id != self.session_id or len(payload) != PROOF_BYTES or self.root_key is None:
            return None
        expected = receiver_proof(
            self.root_key, self.session_id, self.receiver_challenge,
            self.sender_challenge,
        )
        if not hmac.compare_digest(payload, expected):
            raise StaleProofError("READY proof does not match this sender challenge")
        if self.channel is None:
            self.channel = SecureChannel.create("sender", self.root_key, self.session_id)
            self.state = "WAIT_PONG"
        return None

    def secure_probe(self) -> tuple[int, bytes] | None:
        if self.role == "sender" and self.state == "WAIT_PONG":
            return MessageKind.PING, PING_PAYLOAD
        return None

    def receive_secure(self, kind: int, payload: bytes) -> tuple[int, bytes] | None:
        if self.role == "receiver" and kind == MessageKind.PING and self.state in {"WAIT_PING", "CONNECTED"}:
            self.state = "CONNECTED"
            return MessageKind.PONG, payload
        if self.role == "sender" and kind == MessageKind.PONG and self.state == "WAIT_PONG":
            if payload != PING_PAYLOAD:
                raise HandshakeError("invalid encrypted handshake response")
            self.state = "CONNECTED"
        return None
