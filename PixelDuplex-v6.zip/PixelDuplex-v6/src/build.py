"""Identify the exact code both endpoints run (PD-DEC-037).

The build ID is a digest of the running program's own source, so two PCs that
extracted the same release ZIP always agree, and any difference in the code,
even within one protocol version, is detected at the first beacon.
"""

from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUILD_ID_BYTES = 8


def source_files(root: Path = ROOT) -> list[Path]:
    """The code that decides behaviour on the link: the entry point and src/."""
    return [root / "pixelduplex.py", *sorted((root / "src").glob("*.py"))]


def compute_build_id(root: Path = ROOT) -> bytes:
    digest = hashlib.sha256()
    for path in source_files(root):
        # Line endings may differ after a checkout; the program does not.
        text = path.read_bytes().replace(b"\r\n", b"\n")
        digest.update(path.relative_to(root).as_posix().encode("utf-8") + b"\0")
        digest.update(len(text).to_bytes(8, "big") + text)
    return digest.digest()[:BUILD_ID_BYTES]


BUILD_ID = compute_build_id()
BUILD_TEXT = BUILD_ID.hex()
