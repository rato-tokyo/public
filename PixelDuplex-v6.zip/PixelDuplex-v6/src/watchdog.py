"""Record where the main loop is stuck when it stops turning (ISSUE-017).

A frozen main loop stops the display, so the peer sees a still screen and the
link drops without any error on this side. faulthandler writes the stack of
every thread to artifacts/logs/hang.log when the loop has not re-armed the
timer for HANG_SECONDS; the loop also reports each long pause it survived.
"""

from __future__ import annotations

import faulthandler
import time
from pathlib import Path


# Shorter than the peer's 15-second silence limit, so the stack is captured
# before the link is torn down.
HANG_SECONDS = 10.0
REARM_SECONDS = 1.0
# A pause this long is reported on the console even when it recovers.
PAUSE_REPORT_SECONDS = 3.0


class LoopWatchdog:
    def __init__(self, log_path: Path):
        self.log_path = log_path
        self._stream = None
        self._armed_at = float("-inf")
        self._last_beat: float | None = None
        self.max_pause_seconds = 0.0
        self.long_pauses = 0

    def start(self) -> None:
        try:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            self._stream = self.log_path.open("a", encoding="utf-8")
            self._stream.write(
                f"--- watchdog armed {time.strftime('%Y-%m-%dT%H:%M:%S%z')} "
                f"(dumps all thread stacks if the main loop stalls {HANG_SECONDS:.0f} s)\n"
            )
            self._stream.flush()
        except OSError:
            self._stream = None

    def beat(self, now: float) -> float | None:
        """Call once per loop turn; returns the length of a long pause just survived."""
        pause = None
        if self._last_beat is not None:
            gap = now - self._last_beat
            self.max_pause_seconds = max(self.max_pause_seconds, gap)
            if gap >= PAUSE_REPORT_SECONDS:
                self.long_pauses += 1
                pause = gap
        self._last_beat = now
        if self._stream is not None and (pause is not None or now - self._armed_at >= REARM_SECONDS):
            self._armed_at = now
            faulthandler.dump_traceback_later(HANG_SECONDS, repeat=False, file=self._stream)
        return pause

    def stop(self) -> None:
        if self._stream is not None:
            faulthandler.cancel_dump_traceback_later()
            self._stream.close()
            self._stream = None
