"""Windows display/capture transport for PixelDuplex physical frames."""

from __future__ import annotations

import ctypes
import queue
import threading
import time
from collections import deque
from ctypes import wintypes
from dataclasses import dataclass, field
from typing import Callable

import cv2

from .constants import DEFAULT_FRAME_INTERVAL_SECONDS, HEIGHT, WIDTH
from . import band_codec
from .wire import PhysicalPacket, decode_image_detail, packet_image


_CAPTURE_CLOSE_JOIN_SECONDS = 2.0
_CAPTURE_REOPEN_SECONDS = 2.0
# Reads succeed but nothing decodes: a device left in a bad mode (opened
# before the HDMI signal, re-plugged) recovers only when reopened. Used only
# while the link is down, so a healthy link is never interrupted.
NO_DECODE_REOPEN_SECONDS = 60.0
_MEAN_SAMPLE_SECONDS = 1.0
_FALLBACK_DECODE_EVERY = 4
_WINDOW_STYLE_INDEX = -16
_POPUP_VISIBLE_STYLE = 0x80000000 | 0x10000000
_TOPMOST_NO_ACTIVATE = 0x20 | 0x40


def opencv_gui_backend() -> str | None:
    """Return the compiled OpenCV GUI backend, or None for headless builds."""
    for line in cv2.getBuildInformation().splitlines():
        stripped = line.strip()
        if stripped.startswith("GUI:"):
            backend = stripped.partition(":")[2].strip()
            return None if backend.upper() in {"", "NONE", "NO"} else backend
    return None


def require_opencv_gui() -> str:
    backend = opencv_gui_backend()
    if backend is None:
        raise RuntimeError(
            "OpenCV has no GUI backend; uninstall opencv-python-headless and "
            "install the repository requirement opencv-python"
        )
    return backend


def configure_dpi() -> None:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def active_monitors() -> list[dict]:
    if not hasattr(ctypes, "windll"):
        raise RuntimeError("PixelDuplex hardware mode requires Windows")
    monitors: list[dict] = []
    callback_type = ctypes.WINFUNCTYPE(
        ctypes.c_int, wintypes.HMONITOR, wintypes.HDC,
        ctypes.POINTER(wintypes.RECT), wintypes.LPARAM,
    )

    class MONITORINFOEXW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
            ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD),
            ("szDevice", wintypes.WCHAR * 32),
        ]

    def callback(handle, _dc, _rect, _data):
        info = MONITORINFOEXW()
        info.cbSize = ctypes.sizeof(info)
        if ctypes.windll.user32.GetMonitorInfoW(handle, ctypes.byref(info)):
            rect = info.rcMonitor
            monitors.append({
                "handle": handle, "device": info.szDevice,
                "primary": bool(info.dwFlags & 1),
                "rect": (rect.left, rect.top, rect.right, rect.bottom),
            })
        return 1

    ctypes.windll.user32.EnumDisplayMonitors(None, None, callback_type(callback), 0)
    return monitors


def choose_external_monitor(monitors: list[dict], configured_device: str | None = None) -> dict:
    candidates = [item for item in monitors if not item["primary"]]
    if configured_device:
        candidates = [item for item in candidates if item["device"] == configured_device]
    if len(candidates) != 1:
        listing = "; ".join(
            f"{item['device']} primary={item['primary']} rect={item['rect']}"
            for item in monitors
        )
        raise RuntimeError(
            "could not select exactly one non-primary monitor before display; "
            f"detected: {listing or 'none'}"
        )
    selected = candidates[0]
    left, top, right, bottom = selected["rect"]
    if (right - left, bottom - top) != (WIDTH, HEIGHT):
        raise RuntimeError(
            f"PixelDuplex requires a 1920x1080 external monitor; "
            f"selected {selected['device']} is {right-left}x{bottom-top}"
        )
    return selected


def _find_window(window: str):
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    find_window = user32.FindWindowW
    find_window.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    find_window.restype = wintypes.HWND
    return user32, find_window(None, window)


def position_and_verify(window: str, monitor: dict) -> None:
    user32, hwnd = _find_window(window)
    if not hwnd:
        raise RuntimeError("could not locate output window")
    show_window = user32.ShowWindow
    show_window.argtypes = [wintypes.HWND, ctypes.c_int]
    show_window.restype = wintypes.BOOL
    show_window(hwnd, 0)
    try:
        set_style = user32.SetWindowLongPtrW
        set_style.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
        set_style.restype = ctypes.c_ssize_t
        style = _POPUP_VISIBLE_STYLE
    except AttributeError:
        set_style = user32.SetWindowLongW
        set_style.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.LONG]
        set_style.restype = wintypes.LONG
        style = ctypes.c_long(_POPUP_VISIBLE_STYLE).value
    ctypes.set_last_error(0)
    previous = set_style(hwnd, _WINDOW_STYLE_INDEX, style)
    if previous == 0 and ctypes.get_last_error():
        raise ctypes.WinError(ctypes.get_last_error())
    left, top, right, bottom = monitor["rect"]
    set_position = user32.SetWindowPos
    set_position.argtypes = [
        wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
        ctypes.c_int, ctypes.c_int, wintypes.UINT,
    ]
    set_position.restype = wintypes.BOOL
    if not set_position(
        hwnd, wintypes.HWND(-1), left, top, right - left, bottom - top,
        _TOPMOST_NO_ACTIVATE,
    ):
        raise ctypes.WinError(ctypes.get_last_error())
    actual = wintypes.RECT()
    get_rect = user32.GetWindowRect
    get_rect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    get_rect.restype = wintypes.BOOL
    if not get_rect(hwnd, ctypes.byref(actual)):
        raise ctypes.WinError(ctypes.get_last_error())
    if (actual.left, actual.top, actual.right, actual.bottom) != monitor["rect"]:
        raise RuntimeError("output window placement verification failed")


class DisplayLostError(RuntimeError):
    """The external data monitor disappeared or the window left it."""


class CaptureFailedError(RuntimeError):
    """The capture worker ended; nothing would ever be received again."""


def window_rect(window: str) -> tuple[int, int, int, int] | None:
    user32, hwnd = _find_window(window)
    if not hwnd:
        return None
    actual = wintypes.RECT()
    get_rect = user32.GetWindowRect
    get_rect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    get_rect.restype = wintypes.BOOL
    if not get_rect(hwnd, ctypes.byref(actual)):
        return None
    return actual.left, actual.top, actual.right, actual.bottom


def hide_window(window: str) -> None:
    user32, hwnd = _find_window(window)
    if hwnd:
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.ShowWindow(hwnd, 0)


def open_capture(device: int):
    capture = cv2.VideoCapture(device, cv2.CAP_DSHOW)
    if capture.isOpened():
        capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"YUY2"))
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
        capture.set(cv2.CAP_PROP_FPS, 30)
    return capture


def capture_format(capture) -> dict:
    """What the driver actually negotiated; a mode other than 1920x1080 never decodes."""
    try:
        fourcc = int(capture.get(cv2.CAP_PROP_FOURCC))
        text = "".join(chr((fourcc >> shift) & 0xFF) for shift in (0, 8, 16, 24))
        return {
            "width": int(capture.get(cv2.CAP_PROP_FRAME_WIDTH)),
            "height": int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT)),
            "fps": round(float(capture.get(cv2.CAP_PROP_FPS)), 2),
            "fourcc": text if text.isascii() and text.isprintable() else None,
        }
    except (cv2.error, AttributeError, OSError, TypeError, ValueError):
        return {"width": None, "height": None, "fps": None, "fourcc": None}


@dataclass
class QueuedFrame:
    """One physical packet waiting for the display, with its bookkeeping."""

    packet: PhysicalPacket
    queued_at: float
    on_display: Callable[[float], None] | None = None
    profile: str = "baseline"
    coalesce_key: object | None = None


@dataclass
class CaptureStats:
    """Written by the capture worker, read by the main loop for diagnosis."""

    reads: int = 0
    decoded_frames: int = 0
    last_read_at: float | None = None
    last_decoded_at: float | None = None
    last_frame_shape: tuple | None = None
    last_frame_mean: float | None = None
    foreign_version_frames: int = 0
    last_foreign_version: int | None = None
    worker_errors: int = 0
    last_worker_error: str | None = None
    reopens: int = 0
    reopen_failures: int = 0
    opened_at_hint: float | None = None
    format: dict = field(default_factory=dict)


class HdmiFrameIO:
    """Queue physical packets while continuously capturing in a worker thread."""

    def __init__(self, device: int, monitor_device: str | None = None,
                 frame_interval: float = DEFAULT_FRAME_INTERVAL_SECONDS):
        self.device = device
        self.monitor_device = monitor_device
        self.frame_interval = frame_interval
        self.window = "PixelDuplex Data Display"
        self._outgoing: deque[QueuedFrame] = deque()
        # Banded profiles repaint one band per sub-interval onto this canvas.
        self._canvas = None
        self._band_cursor = 0
        self._band_hold_until = 0.0
        self._prefer_bands = False
        self._decode_failures = 0
        self.coalesced_frames = 0
        self.capture_frames_per_second: float | None = None
        self._fps_since: float | None = None
        self._fps_count = 0
        self._incoming: queue.Queue[tuple[PhysicalPacket, tuple | None]] = queue.Queue(maxsize=512)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._capture = None
        self._capture_lock = threading.Lock()
        self._next_frame_at = 0.0
        self.repeated_capture_frames = 0
        self.undecodable_capture_frames = 0
        self.dropped_queue_frames = 0
        self.max_outgoing_queue_depth = 0
        self.displayed_unique_frames = 0
        self.displayed_duplicate_frames = 0
        self.display_delay_seconds_total = 0.0
        self.display_delay_seconds_max = 0.0
        self._displayed_identities: set[tuple[bytes, int, int, int, int]] = set()
        self._displayed_order: deque[tuple[bytes, int, int, int, int]] = deque()
        self.stats = CaptureStats()
        # Set by the main loop: reopen a capture that reads but never decodes
        # only while the link is down.
        self.link_down = True
        self._mean_sampled_at = float("-inf")
        # Set by start(); tests that never open a window leave it None.
        self._monitor: dict | None = None
        self._display_checked_at = float("-inf")

    def start(self) -> None:
        require_opencv_gui()
        configure_dpi()
        monitor = choose_external_monitor(active_monitors(), self.monitor_device)
        self._monitor = monitor
        self._capture = open_capture(self.device)
        if not self._capture.isOpened():
            raise RuntimeError(
                f"could not open capture device {self.device}; check capture_device in "
                "config.json (python pixelduplex.py find-capture lists working devices)"
            )
        self.stats.format = capture_format(self._capture)
        self.stats.opened_at_hint = time.monotonic()
        cv2.namedWindow(self.window, cv2.WINDOW_NORMAL)
        position_and_verify(self.window, monitor)
        self._thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._thread.start()

    def queued_packets(self) -> list[PhysicalPacket]:
        return [item.packet for item in self._outgoing]

    def send(self, packets: list[PhysicalPacket], *, priority: bool = False,
             on_display: Callable[[float], None] | None = None,
             profile: str = "baseline",
             coalesce_key: object | None = None) -> None:
        """Queue packets. A single-packet send with ``coalesce_key`` replaces a
        still-undisplayed packet with the same key in place (cumulative ACKs)."""
        if profile != "baseline" and profile not in band_codec.PROFILE_IDS:
            raise ValueError(f"unsupported send profile: {profile}")
        if coalesce_key is not None and len(packets) == 1:
            for item in self._outgoing:
                if item.coalesce_key == coalesce_key:
                    item.packet, item.profile, item.on_display = packets[0], profile, on_display
                    self.coalesced_frames += 1
                    return
        key = coalesce_key if len(packets) == 1 else None
        queued_at = time.monotonic()
        items = [QueuedFrame(packet, queued_at, None, profile, key) for packet in packets]
        if items:
            # The callback fires when the message's last fragment is shown.
            items[-1].on_display = on_display
        if priority:
            self._outgoing.extendleft(reversed(items))
        else:
            self._outgoing.extend(items)
        self.max_outgoing_queue_depth = max(self.max_outgoing_queue_depth, len(self._outgoing))

    def clear_outgoing(self) -> None:
        self._outgoing.clear()

    def display_metrics(self) -> dict[str, int | float | None]:
        displayed = self.displayed_unique_frames + self.displayed_duplicate_frames
        return {
            "outgoing_queue_depth": len(self._outgoing),
            "outgoing_queue_high_watermark": self.max_outgoing_queue_depth,
            "displayed_unique_frames": self.displayed_unique_frames,
            "displayed_duplicate_frames": self.displayed_duplicate_frames,
            "display_delay_seconds_mean": (
                self.display_delay_seconds_total / displayed if displayed else None
            ),
            "display_delay_seconds_max": (
                self.display_delay_seconds_max if displayed else None
            ),
            "coalesced_ack_frames": self.coalesced_frames,
            # Raw successful reads per second; the driver may repeat images.
            "capture_reads_per_second": self.capture_frames_per_second,
        }

    def capture_alive(self) -> bool:
        """False only when a started worker has ended (tests never start one)."""
        return self._thread is None or self._thread.is_alive()

    def capture_metrics(self, now: float) -> dict:
        stats = self.stats

        def age(value: float | None) -> float | None:
            return None if value is None else round(now - value, 1)

        return {
            "device": self.device,
            "format": dict(stats.format),
            "worker_alive": self.capture_alive(),
            "reads": stats.reads,
            "reads_per_second": self.capture_frames_per_second,
            "last_read_age_seconds": age(stats.last_read_at),
            "decoded_frames": stats.decoded_frames,
            "last_decoded_age_seconds": age(stats.last_decoded_at),
            "undecodable_frames": self.undecodable_capture_frames,
            "last_frame_shape": list(stats.last_frame_shape) if stats.last_frame_shape else None,
            "last_frame_mean_brightness": stats.last_frame_mean,
            "foreign_version_frames": stats.foreign_version_frames,
            "last_foreign_version": stats.last_foreign_version,
            "worker_errors": stats.worker_errors,
            "last_worker_error": stats.last_worker_error,
            "reopens": stats.reopens,
            "reopen_failures": stats.reopen_failures,
        }

    def check_display(self, now: float) -> None:
        """Stop before the data window can cover the primary screen.

        Windows moves a window onto the primary monitor when the extended
        display disappears (e.g. switched to duplicate or PC screen only).
        """
        if self._monitor is None or now - self._display_checked_at < 1.0:
            return
        self._display_checked_at = now
        expected = self._monitor
        try:
            current = choose_external_monitor(active_monitors(), self.monitor_device)
        except RuntimeError as error:
            reason = f"external monitor lost: {error}"
        else:
            if (current["device"], current["rect"]) != (expected["device"], expected["rect"]):
                reason = (f"external monitor changed: {expected['device']} {expected['rect']} "
                          f"-> {current['device']} {current['rect']}")
            elif window_rect(self.window) != expected["rect"]:
                reason = f"data window left the external monitor {expected['device']}"
            else:
                return
        hide_window(self.window)
        raise DisplayLostError(reason)

    def pump_display(self) -> bool:
        now = time.monotonic()
        self.check_display(now)
        head = self._outgoing[0] if self._outgoing else None
        if (head is not None and head.profile == "baseline"
                and self._canvas is not None and now < self._band_hold_until):
            # A full-frame packet would erase every band; let the newest band
            # stay up for one whole frame_interval first.
            return (cv2.waitKey(1) & 0xFF) != 27
        if head is not None and now >= self._next_frame_at:
            item = self._outgoing.popleft()
            packet = item.packet
            if item.profile == "baseline":
                # Keep the band canvas: repainting one band over black after a
                # full-frame packet leaves too little screen to find the
                # active area of a scaled capture.
                image = packet_image(packet)
                hold = self.frame_interval
            else:
                # Staggered repaint: each band still stays up for one full
                # frame_interval, but only one band changes at a time.
                if self._canvas is None:
                    self._canvas = band_codec.blank_canvas()
                    self._band_cursor = 0
                band_codec.paint_band(
                    self._canvas, self._band_cursor, band_codec.layout_for(item.profile), packet,
                )
                self._band_cursor = (self._band_cursor + 1) % band_codec.BANDS
                self._band_hold_until = now + self.frame_interval
                image = self._canvas
                hold = self.frame_interval / band_codec.BANDS
            cv2.imshow(self.window, image)
            delay = max(0.0, now - item.queued_at)
            self.display_delay_seconds_total += delay
            self.display_delay_seconds_max = max(self.display_delay_seconds_max, delay)
            identity = (
                packet.session_id, packet.kind, packet.message_id,
                packet.fragment_index, packet.fragment_count,
            )
            if identity in self._displayed_identities:
                self.displayed_duplicate_frames += 1
            else:
                self.displayed_unique_frames += 1
                self._displayed_identities.add(identity)
                self._displayed_order.append(identity)
                while len(self._displayed_order) > 4096:
                    self._displayed_identities.discard(self._displayed_order.popleft())
            # Advance from the schedule, not from "now", so waitKey and loop
            # latency do not accumulate; resync after an idle or long stall.
            scheduled = self._next_frame_at + hold
            self._next_frame_at = scheduled if scheduled > now else now + hold
            if item.on_display is not None:
                item.on_display(now)
        return (cv2.waitKey(1) & 0xFF) != 27

    def receive(self) -> list[tuple[PhysicalPacket, tuple | None]]:
        result = []
        while True:
            try:
                result.append(self._incoming.get_nowait())
            except queue.Empty:
                return result

    def _capture_loop(self) -> None:
        previous: set[tuple[bytes, int, int, int, int]] = set()
        failed_since: float | None = None
        while not self._stop.is_set():
            try:
                previous, failed_since = self._capture_once(previous, failed_since)
            except Exception as error:
                # Nothing may end the worker silently: the link would look
                # alive while never receiving again. Record and keep reading.
                self.stats.worker_errors += 1
                self.stats.last_worker_error = f"{type(error).__name__}: {error}"[:300]
                previous = set()
                self._stop.wait(0.1)

    def _capture_once(self, previous: set, failed_since: float | None):
        capture = self._capture
        if capture is None:
            if not self._stop.wait(_CAPTURE_REOPEN_SECONDS):
                self._reopen_capture()
            return set(), None
        try:
            ok, frame = capture.read()
        except (cv2.error, OSError):
            ok, frame = False, None
        now = time.monotonic()
        if not ok:
            if failed_since is None:
                failed_since = now
            elif now - failed_since >= _CAPTURE_REOPEN_SECONDS:
                failed_since = None
                self._reopen_capture()
            else:
                self._stop.wait(0.05)
            return set(), failed_since
        stats = self.stats
        stats.reads += 1
        stats.last_read_at = now
        stats.last_frame_shape = tuple(getattr(frame, "shape", ()))
        if now - self._mean_sampled_at >= _MEAN_SAMPLE_SECONDS:
            self._mean_sampled_at = now
            try:
                stats.last_frame_mean = round(float(frame[::16, ::16].mean()), 1)
            except (AttributeError, TypeError, ValueError, IndexError):
                stats.last_frame_mean = None
        self._count_capture_read(now)
        try:
            packets, rect = self._decode_frame(frame)
        except Exception:
            # An unexpected frame must not silently stop the capture worker.
            packets, rect = [], None
        if not packets:
            self.undecodable_capture_frames += 1
            since = stats.last_decoded_at if stats.last_decoded_at is not None else stats.opened_at_hint
            if self.link_down and since is not None and now - since >= NO_DECODE_REOPEN_SECONDS:
                self._reopen_capture()
            return set(), None
        stats.decoded_frames += 1
        stats.last_decoded_at = now
        delivered: set[tuple[bytes, int, int, int, int]] = set()
        for packet in packets:
            identity = (
                packet.session_id,
                packet.kind,
                packet.message_id,
                packet.fragment_index,
                packet.fragment_count,
            )
            # A band that did not change since the previous capture is a
            # repeat; only the repainted band carries new data.
            if identity in previous:
                self.repeated_capture_frames += 1
                delivered.add(identity)
                continue
            try:
                self._incoming.put_nowait((packet, rect))
            except queue.Full:
                self.dropped_queue_frames += 1
            else:
                # Remember only successful delivery. A full queue must leave
                # the same physical packet eligible for the next capture.
                delivered.add(identity)
        return delivered, None

    def _decode_frame(self, frame) -> tuple[list[PhysicalPacket], tuple[int, int, int, int] | None]:
        """Decode baseline or banded frames, trying the last successful format first."""
        def baseline():
            packet, rect, foreign = decode_image_detail(frame)
            if foreign is not None:
                self.stats.foreign_version_frames += 1
                self.stats.last_foreign_version = foreign
            return ([packet], rect) if packet is not None else ([], None)

        def banded():
            return band_codec.decode_bands(frame)

        preferred, other = (banded, baseline) if self._prefer_bands else (baseline, banded)
        packets, rect = preferred()
        if packets:
            self._decode_failures = 0
            return packets, rect
        # The other format costs ~38 ms per failed frame (ISSUE-014). The first
        # failure after a success tries it at once (a format switch); a long
        # run of failures (no peer, black screen) tries it on every 4th frame.
        self._decode_failures += 1
        if (self._decode_failures - 1) % _FALLBACK_DECODE_EVERY:
            return [], None
        packets, rect = other()
        if packets:
            self._decode_failures = 0
            self._prefer_bands = other is banded
            return packets, rect
        return [], None

    def _count_capture_read(self, now: float) -> None:
        """Measure raw capture reads per second over roughly 5-second windows."""
        if self._fps_since is None:
            self._fps_since, self._fps_count = now, 0
            return
        self._fps_count += 1
        elapsed = now - self._fps_since
        if elapsed >= 5.0:
            self.capture_frames_per_second = round(self._fps_count / elapsed, 2)
            self._fps_since, self._fps_count = now, 0

    def _reopen_capture(self) -> None:
        """Replace a failed DirectShow handle without reopening on every bad frame."""
        with self._capture_lock:
            old = self._capture
            self._capture = None
        self.stats.reopens += 1
        # Restart the no-decode clock so a reopen happens at most once a period.
        self.stats.opened_at_hint = time.monotonic()
        self.stats.last_decoded_at = None
        if old is not None:
            try:
                old.release()
            except (cv2.error, OSError):
                pass
        if self._stop.is_set():
            return
        try:
            replacement = open_capture(self.device)
        except (cv2.error, OSError):
            self.stats.reopen_failures += 1
            return
        if not replacement.isOpened():
            replacement.release()
            self.stats.reopen_failures += 1
            return
        self.stats.format = capture_format(replacement)
        with self._capture_lock:
            if self._stop.is_set():
                replacement.release()
            else:
                self._capture = replacement

    def close(self) -> None:
        self._stop.set()
        thread = self._thread
        with self._capture_lock:
            capture = self._capture
            self._capture = None
        if thread is not None:
            thread.join(timeout=_CAPTURE_CLOSE_JOIN_SECONDS)
        # DirectShow read() can remain blocked until the capture handle is
        # released. Release it exactly once, then give the worker one final
        # bounded opportunity to finish.
        if capture is not None:
            capture.release()
        if thread is not None and thread.is_alive():
            thread.join(timeout=_CAPTURE_CLOSE_JOIN_SECONDS)
        shutdown_failed = thread is not None and thread.is_alive()
        if not shutdown_failed:
            self._thread = None
        try:
            cv2.destroyAllWindows()
        except cv2.error:
            # Avoid masking the actionable startup error on headless builds.
            pass
        if shutdown_failed:
            raise RuntimeError("capture worker did not stop after capture release")
