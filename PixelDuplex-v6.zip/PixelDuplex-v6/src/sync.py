"""Receiver-driven file synchronization state machines."""

from __future__ import annotations

import json
import math
import threading
import uuid
import time
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .constants import (
    DEFAULT_RETRANSMIT_SECONDS, DEFAULT_SCAN_INTERVAL_SECONDS,
    DEFAULT_STABLE_SECONDS, DEFAULT_WINDOW_SIZE, FILE_CHUNK_BYTES, MessageKind,
)
from .files import (
    AtomicReceiver, FileSnapshot, StabilityTracker, normalized_relative,
    safe_output_path, scan_regular_files, sha256_file, snapshot_file,
)
from .ledger import LedgerScope, atomic_json
from .messages import (
    decode_ack, decode_data, encode_ack, encode_data, json_bytes, parse_json,
)
from .reliable import SelectiveRepeatReceiver, SelectiveRepeatSender


AppMessage = tuple[int, bytes]
MetricsProvider = Callable[[], dict[str, int]]
ProgressSink = Callable[[str], None]
PROGRESS_STEP_PERCENT = 20
MANIFEST_RETRY_SECONDS = 3.0
# Longest a scan waits for background SHA-256 results. Small files are
# announced in the same scan; a large file finishes in a later one while the
# display loop keeps running (ISSUE-014).
SCAN_HASH_WAIT_SECONDS = 0.2


def _size_text(size: int) -> str:
    if size >= 1_000_000:
        return f"{size / 1_000_000:.1f} MB"
    if size >= 1_000:
        return f"{size / 1_000:.1f} KB"
    return f"{size} B"


def chunk_bytes_done(chunks: set[int], chunk_count: int, chunk_bytes: int, size: int) -> int:
    """Exact payload bytes held in the given chunk indexes (last chunk may be short)."""
    total = len(chunks) * chunk_bytes
    if chunk_count - 1 in chunks:
        total -= chunk_count * chunk_bytes - size
    return max(0, min(size, total))


class TransferProgress:
    """Console lines at fixed 20% steps. Only DONE lines claim verified success."""

    def __init__(self, sink: ProgressSink, direction: str, relative: str,
                 size: int, now: float):
        self.sink = sink
        self.direction = direction
        self.path = json.dumps(relative, ensure_ascii=False)
        self.size = size
        self.started = now
        self.reported = 0
        self.percent = 0
        self.emit(f"START size={_size_text(size)}")

    def emit(self, text: str) -> None:
        self.sink(
            f"{time.strftime('%Y-%m-%d %H:%M:%S')} TRANSFER {self.direction} "
            f"{text} path={self.path}"
        )

    def update(self, done_bytes: int, now: float) -> None:
        self.percent = 100 if self.size <= 0 else done_bytes * 100 // self.size
        step = self.percent // PROGRESS_STEP_PERCENT * PROGRESS_STEP_PERCENT
        if step <= self.reported:
            return
        self.reported = step
        elapsed = max(0.0, now - self.started)
        rate = f"{_size_text(int(done_bytes / elapsed))}/s" if elapsed > 0 else "N/A"
        self.emit(
            f"PROGRESS {step}% {_size_text(done_bytes)}/{_size_text(self.size)} "
            f"elapsed={elapsed:.0f}s average={rate}"
        )

    def finish(self, text: str, now: float) -> None:
        self.emit(f"{text} elapsed={max(0.0, now - self.started):.0f}s")


def interval_metrics(start: dict[str, int] | None, provider: MetricsProvider | None) -> dict:
    """Count observed link activity during a transfer, not FILE_DATA-only frames."""
    if start is None or provider is None:
        return {
            "unique_physical_frames": None,
            "duplicate_physical_frames": None,
            "discarded_physical_frames": None,
            "authentication_failures": None,
            "physical_metric_scope": "unavailable without a link metrics provider",
        }
    end = provider()
    return {
        "unique_physical_frames": max(0, end["unique_physical_frames"] - start["unique_physical_frames"]),
        "duplicate_physical_frames": max(0, end["duplicate_physical_frames"] - start["duplicate_physical_frames"]),
        "discarded_physical_frames": max(0, end["discarded_physical_frames"] - start["discarded_physical_frames"]),
        "authentication_failures": max(0, end["authentication_failures"] - start["authentication_failures"]),
        "physical_metric_scope": "link-wide observation during this transfer; includes control traffic",
    }


@dataclass
class SenderTransfer:
    transfer_id: bytes
    path: Path
    snapshot: FileSnapshot
    chunk_count: int
    reliable: SelectiveRepeatSender
    stream: object
    chunk_bytes: int
    retransmitted_chunks: int = 0
    metrics_start: dict[str, int] | None = None
    progress: TransferProgress | None = None

    def read(self, index: int) -> bytes:
        self.stream.seek(index * self.chunk_bytes)
        return self.stream.read(self.chunk_bytes)

    def expected_length(self, index: int) -> int:
        return max(0, min(self.chunk_bytes, self.snapshot.size - index * self.chunk_bytes))

    def close(self) -> None:
        self.stream.close()


class SenderEngine:
    def __init__(self, root: Path, ledger: LedgerScope, *, window_size: int = DEFAULT_WINDOW_SIZE,
                 scan_interval: float = DEFAULT_SCAN_INTERVAL_SECONDS,
                 stable_seconds: float = DEFAULT_STABLE_SECONDS,
                 retransmit_seconds: float = DEFAULT_RETRANSMIT_SECONDS,
                 chunk_bytes: int = FILE_CHUNK_BYTES,
                 report_path: Path | None = None,
                 metrics_provider: MetricsProvider | None = None,
                 progress_sink: ProgressSink | None = None):
        if not 0 < chunk_bytes <= 120_000:
            raise ValueError("chunk_bytes must be between 1 and 120000")
        self.progress_sink = progress_sink
        self.root = root
        self.ledger = ledger
        self.window_size = window_size
        self.scan_interval = scan_interval
        self.retransmit_seconds = retransmit_seconds
        self.chunk_bytes = chunk_bytes
        self.report_path = report_path
        self.metrics_provider = metrics_provider
        self.stability = StabilityTracker(stable_seconds)
        self.snapshots: dict[str, FileSnapshot] = {}
        self.paths: dict[str, Path] = {}
        self.last_scan = float("-inf")
        self.transfer: SenderTransfer | None = None
        self.completed_transfer_ids: set[str] = set()
        # Paths the receiver held (conflict or failure) in this session: never
        # announced again and listed as not sendable until the next session.
        self.rejected: set[str] = set()
        self._hasher: ThreadPoolExecutor | None = None
        self._hash_stop = threading.Event()
        self._hashing: dict[str, tuple[int, int, Future]] = {}

    def set_chunk_bytes(self, chunk_bytes: int) -> None:
        """Change chunk size only between files after both endpoints agree."""
        if self.transfer is not None:
            raise RuntimeError("cannot change chunk size during transfer")
        if not 0 < chunk_bytes <= 120_000:
            raise ValueError("chunk_bytes must be between 1 and 120000")
        self.chunk_bytes = chunk_bytes

    def close(self) -> None:
        self._hash_stop.set()
        if self._hasher is not None:
            self._hasher.shutdown(wait=False, cancel_futures=True)
            self._hasher = None
        self._hashing.clear()
        if self.transfer is not None:
            if self.transfer.progress is not None:
                self.transfer.progress.emit(
                    f"INTERRUPTED at {self.transfer.progress.percent}%; "
                    "not complete, resends from the beginning later"
                )
            self.transfer.close()
            self.transfer = None

    def scan(self, now: float) -> list[AppMessage]:
        if now - self.last_scan < self.scan_interval:
            return []
        self.last_scan = now
        announcements: list[AppMessage] = []
        deadline = time.monotonic() + SCAN_HASH_WAIT_SECONDS
        for path in scan_regular_files(self.root):
            relative = normalized_relative(self.root, path)
            self.paths[relative] = path
            if self.ledger.is_complete(relative) or relative in self.rejected:
                continue
            try:
                info = path.stat()
            except OSError:
                continue  # removed or locked since the directory walk
            if not self.stability.observe(relative, info.st_size, info.st_mtime_ns, now):
                continue
            cached = self.snapshots.get(relative)
            if cached and (cached.size, cached.mtime_ns) == (info.st_size, info.st_mtime_ns):
                # Announced once when the snapshot was taken. A lost announcement
                # is recovered by the manifest the receiver requests (ISSUE-012).
                continue
            snapshot = self._hashed_snapshot(relative, path, info, deadline)
            if snapshot is None:
                continue
            self.snapshots[relative] = snapshot
            announcements.append((MessageKind.FILE_ANNOUNCE, json_bytes(self._item(snapshot))))
        return announcements

    def _hashed_snapshot(self, relative: str, path: Path, info, deadline: float) -> FileSnapshot | None:
        """Hash on a worker thread; None until the result for this size/mtime is ready."""
        key = (info.st_size, info.st_mtime_ns)
        pending = self._hashing.get(relative)
        if pending is None or pending[:2] != key:
            if self._hasher is None:
                self._hasher = ThreadPoolExecutor(1, thread_name_prefix="pixelduplex-hash")
            future = self._hasher.submit(snapshot_file, self.root, path, self._hash_stop)
            self._hashing[relative] = (*key, future)
        else:
            future = pending[2]
        try:
            snapshot = future.result(timeout=max(0.0, deadline - time.monotonic()))
        except TimeoutError:
            return None
        except (OSError, RuntimeError):
            self._hashing.pop(relative, None)
            return None
        self._hashing.pop(relative, None)
        if (snapshot.size, snapshot.mtime_ns) != key:
            return None
        return snapshot

    def _item(self, snapshot: FileSnapshot) -> dict:
        return {
            "path": snapshot.relative_path,
            "size": snapshot.size,
            "sha256": snapshot.sha256,
            "sendable": (
                not self.ledger.is_complete(snapshot.relative_path)
                and snapshot.relative_path not in self.rejected
            ),
        }

    def manifest(self) -> list[dict]:
        items = []
        for path in scan_regular_files(self.root):
            relative = normalized_relative(self.root, path)
            self.paths[relative] = path
            if self.ledger.is_complete(relative):
                record = self.ledger.get(relative) or {}
                items.append({
                    "path": relative, "size": record.get("size"),
                    "sha256": record.get("sha256"), "sendable": False,
                })
            elif relative in self.snapshots:
                items.append(self._item(self.snapshots[relative]))
            else:
                try:
                    size = path.stat().st_size
                except OSError:
                    continue
                items.append({
                    "path": relative, "size": size, "sha256": None,
                    "sendable": False, "reason": "waiting for file stability",
                })
        return items

    def handle(self, kind: int, payload: bytes, now: float) -> list[AppMessage]:
        if kind == MessageKind.MANIFEST_REQUEST:
            return [(MessageKind.MANIFEST, json_bytes(self.manifest()))]
        if kind == MessageKind.FILE_REQUEST:
            return self._request(parse_json(payload), now)
        if kind == MessageKind.FILE_ACK and self.transfer:
            transfer_id, base, bitmap = decode_ack(payload)
            if transfer_id == self.transfer.transfer_id:
                transfer = self.transfer
                try:
                    transfer.reliable.acknowledge(base, bitmap)
                except ValueError:
                    return []
                if transfer.progress is not None:
                    transfer.progress.update(chunk_bytes_done(
                        transfer.reliable.acked, transfer.chunk_count,
                        transfer.chunk_bytes, transfer.snapshot.size,
                    ), now)
            return []
        if kind == MessageKind.FILE_COMPLETE and self.transfer:
            value = parse_json(payload)
            if value.get("transfer_id") != self.transfer.transfer_id.hex():
                return []
            snapshot = self.transfer.snapshot
            if value.get("sha256") != snapshot.sha256 or value.get("size") != snapshot.size:
                return []
            self.ledger.record(
                snapshot.relative_path, status="SUCCESS", size=snapshot.size,
                sha256=snapshot.sha256, session_id=value.get("session_id"),
            )
            transfer_id = self.transfer.transfer_id.hex()
            if self.report_path is not None:
                atomic_json(self.report_path, {
                    "status": "SUCCESS",
                    "reason": "receiver verified file and acknowledged completion",
                    "direction": "outgoing",
                    "relative_path": snapshot.relative_path,
                    "file_size": snapshot.size,
                    "expected_sha256": snapshot.sha256,
                    "actual_sha256": value.get("sha256"),
                    "sha256_verified": True,
                    "session_id": value.get("session_id"),
                    "transfer_id": transfer_id,
                    "retransmitted_chunks": self.transfer.retransmitted_chunks,
                    "metric_scope": "per-transfer; null means not attributable without guessing",
                    "missing_chunks": None,
                    "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                    **interval_metrics(self.transfer.metrics_start, self.metrics_provider),
                })
            self.completed_transfer_ids.add(transfer_id)
            if self.transfer.progress is not None:
                self.transfer.progress.finish(
                    "DONE receiver verified size and SHA-256", now,
                )
            self.transfer.close()
            self.transfer = None
            return [(MessageKind.COMPLETE_CONFIRM, json_bytes({"transfer_id": transfer_id}))]
        if kind == MessageKind.FILE_COMPLETE:
            value = parse_json(payload)
            transfer_id = value.get("transfer_id")
            if transfer_id in self.completed_transfer_ids:
                return [(MessageKind.COMPLETE_CONFIRM, json_bytes({"transfer_id": transfer_id}))]
        if kind == MessageKind.ALREADY_COMPLETE:
            value = parse_json(payload)
            relative = value.get("path")
            if relative in self.paths:
                self.ledger.record(
                    relative, status="SUCCESS", size=value.get("size"),
                    sha256=value.get("sha256"), session_id=value.get("session_id"),
                    reason="receiver already held identical content",
                )
            return []
        if kind == MessageKind.FILE_REJECTED:
            value = parse_json(payload)
            relative = value.get("path")
            if isinstance(relative, str):
                self.rejected.add(relative)
                transfer = self.transfer
                if transfer is not None and transfer.snapshot.relative_path == relative:
                    if transfer.progress is not None:
                        transfer.progress.finish(
                            f"CANCELLED receiver held the file: {value.get('reason')}", now,
                        )
                    transfer.close()
                    self.transfer = None
            return []
        return []

    @staticmethod
    def _unavailable(relative: str, reason: str) -> AppMessage:
        return MessageKind.FILE_UNAVAILABLE, json_bytes({"path": relative, "reason": reason})

    def _request(self, value: dict, now: float) -> list[AppMessage]:
        relative = value.get("path")
        if not isinstance(relative, str):
            return []
        if self.ledger.is_complete(relative):
            # Answer the requester's receive side; it must not be mistaken for the
            # receiver's own ALREADY_COMPLETE, which completes our outgoing record.
            return [self._unavailable(relative, "already sent and acknowledged")]
        snapshot = self.snapshots.get(relative)
        path = self.paths.get(relative)
        if self.transfer is not None:
            if self.transfer.snapshot.relative_path == relative:
                return [self._metadata_message(self.transfer)]
            return []
        if snapshot is None or path is None:
            return [self._unavailable(relative, "not ready to send")]
        try:
            info = path.stat()
            if (info.st_size, info.st_mtime_ns) != (snapshot.size, snapshot.mtime_ns):
                self.snapshots.pop(relative, None)
                return [self._unavailable(relative, "source changed")]
            stream = path.open("rb")
        except OSError as error:
            self.snapshots.pop(relative, None)
            return [self._unavailable(relative, f"source unavailable: {error}")]
        transfer_id = uuid.uuid4().bytes
        chunk_count = max(1, math.ceil(snapshot.size / self.chunk_bytes))
        self.transfer = SenderTransfer(
            transfer_id, path, snapshot, chunk_count,
            SelectiveRepeatSender(chunk_count, self.window_size, self.retransmit_seconds),
            stream,
            self.chunk_bytes,
            metrics_start=self.metrics_provider() if self.metrics_provider is not None else None,
            progress=(
                TransferProgress(self.progress_sink, "outgoing", relative, snapshot.size, now)
                if self.progress_sink is not None else None
            ),
        )
        return [self._metadata_message(self.transfer)]

    @staticmethod
    def _metadata_message(transfer: SenderTransfer) -> AppMessage:
        return MessageKind.FILE_META, json_bytes({
            "transfer_id": transfer.transfer_id.hex(),
            "path": transfer.snapshot.relative_path,
            "size": transfer.snapshot.size, "sha256": transfer.snapshot.sha256,
            "chunk_count": transfer.chunk_count, "chunk_bytes": transfer.chunk_bytes,
        })

    def tick(self, now: float) -> list[AppMessage]:
        outgoing = self.scan(now)
        transfer = self.transfer
        if transfer is None:
            return outgoing
        try:
            info = transfer.path.stat()
        except OSError:
            info = None
        if info is None or (info.st_size, info.st_mtime_ns) != (
            transfer.snapshot.size, transfer.snapshot.mtime_ns,
        ):
            return outgoing + self._cancel_changed(transfer, now)
        for transmission in transfer.reliable.due(now):
            try:
                data = transfer.read(transmission.index)
            except OSError:
                data = None
            if data is None or len(data) != transfer.expected_length(transmission.index):
                # Truncated or unreadable after the stat check: never send a
                # chunk that disagrees with the announced size.
                return outgoing + self._cancel_changed(transfer, now)
            if transmission.attempts > 1:
                transfer.retransmitted_chunks += 1
            outgoing.append((
                MessageKind.FILE_DATA,
                encode_data(transfer.transfer_id, transmission.index, data),
            ))
        return outgoing

    def _cancel_changed(self, transfer: SenderTransfer, now: float) -> list[AppMessage]:
        relative = transfer.snapshot.relative_path
        transfer_id = transfer.transfer_id.hex()
        if transfer.progress is not None:
            transfer.progress.finish(
                "CANCELLED source changed; resends after it is stable", now,
            )
        transfer.close()
        self.transfer = None
        self.snapshots.pop(relative, None)
        if self.report_path is not None:
            atomic_json(self.report_path, {
                "status": "CANCELLED",
                "reason": "source changed during transfer",
                "direction": "outgoing",
                "relative_path": relative,
                "sha256_verified": False,
                "transfer_id": transfer_id,
                "retransmitted_chunks": transfer.retransmitted_chunks,
                "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                **interval_metrics(transfer.metrics_start, self.metrics_provider),
            })
        return [(MessageKind.CONFLICT, json_bytes({
            "path": relative, "reason": "source changed during transfer",
        }))]


@dataclass
class ReceiverTransfer:
    transfer_id: bytes
    relative_path: str
    size: int
    sha256: str
    writer: AtomicReceiver
    reliable: SelectiveRepeatReceiver
    started_at: float
    first_chunk_at: float | None = None
    last_chunk_at: float | None = None
    first_chunk_bytes: int | None = None
    duplicate_chunks: int = 0
    metrics_start: dict[str, int] | None = None
    chunk_bytes: int = FILE_CHUNK_BYTES
    progress: TransferProgress | None = None


class ReceiverEngine:
    def __init__(self, root: Path, ledger: LedgerScope, session_id: str = "local",
                 report_path: Path | None = None,
                 metrics_provider: MetricsProvider | None = None,
                 progress_sink: ProgressSink | None = None):
        self.progress_sink = progress_sink
        self.root = root
        self.ledger = ledger
        self.session_id = session_id
        self.report_path = report_path
        self.metrics_provider = metrics_provider
        self.manifest_received = False
        self.last_request = float("-inf")
        self.last_manifest_request = float("-inf")
        self.pending: list[dict] = []
        self.queued_paths: set[str] = set()
        # Paths held after a conflict or failure; retried only in a new session.
        self.held: set[str] = set()
        self.transfer: ReceiverTransfer | None = None
        self.completed_message: AppMessage | None = None
        self.last_complete_sent = float("-inf")

    def start_round(self) -> None:
        """Called when this side takes the receive token: fetch a fresh manifest."""
        self.manifest_received = False
        self.last_request = float("-inf")
        self.last_manifest_request = float("-inf")

    def close(self) -> None:
        if self.transfer is not None:
            if self.transfer.progress is not None and self.completed_message is None:
                self.transfer.progress.emit(
                    f"INTERRUPTED at {self.transfer.progress.percent}%; "
                    "not complete, re-requests from the beginning later"
                )
            self.transfer.writer.abort()
            self.transfer = None
        self.completed_message = None

    def _failure_report(self, relative: str, reason: str, *, status: str = "FAILURE") -> None:
        if self.report_path is not None:
            transfer = self.transfer if self.transfer and self.transfer.relative_path == relative else None
            atomic_json(self.report_path, {
                "status": status, "reason": reason, "relative_path": relative,
                "direction": "incoming",
                "sha256_verified": False, "session_id": self.session_id,
                "goodput_bytes_per_second": None,
                "unique_chunks": len(transfer.reliable.received) if transfer else None,
                "duplicate_chunks": transfer.duplicate_chunks if transfer else None,
                "retransmitted_chunks": None,
                "missing_chunks": None,
                **interval_metrics(transfer.metrics_start if transfer else None, self.metrics_provider),
                "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            })

    def _reject(self, relative: str, reason: str, *, status: str = "FAILURE",
                ledger_status: str | None = None, size=None, digest=None) -> list[AppMessage]:
        """Hold a path for this session, record why, and tell the sender."""
        self.held.add(relative)
        self.queued_paths.discard(relative)
        if ledger_status is not None:
            self.ledger.record(
                relative, status=ledger_status, size=size, sha256=digest,
                session_id=self.session_id, reason=reason,
            )
        self._failure_report(relative, reason, status=status)
        return [(MessageKind.FILE_REJECTED, json_bytes({"path": relative, "reason": reason}))]

    def _fail_transfer(self, reason: str, now: float, *, status: str = "FAILURE",
                       ledger_status: str | None = None) -> list[AppMessage]:
        transfer = self.transfer
        assert transfer is not None
        messages = self._reject(
            transfer.relative_path, reason, status=status, ledger_status=ledger_status,
            size=transfer.size, digest=transfer.sha256,
        )
        if transfer.progress is not None:
            transfer.progress.finish(f"CANCELLED {reason}; not complete", now)
        transfer.writer.abort()
        self.transfer = None
        self.completed_message = None
        return messages

    def _consider(self, item: dict) -> list[AppMessage]:
        relative = item.get("path")
        digest = item.get("sha256")
        size = item.get("size")
        if not isinstance(relative, str) or not item.get("sendable", True):
            return []
        if self.ledger.is_complete(relative):
            record = self.ledger.get(relative) or {}
            return [(MessageKind.ALREADY_COMPLETE, json_bytes({
                "path": relative, "size": record.get("size"),
                "sha256": record.get("sha256"),
                "session_id": record.get("session_id"),
            }))]
        if relative in self.queued_paths or relative in self.held:
            return []
        try:
            output = safe_output_path(self.root, relative)
            exists = output.exists()
            # A size mismatch is a conflict without reading the whole file.
            identical = (exists and output.is_file() and isinstance(digest, str)
                         and output.stat().st_size == size
                         and sha256_file(output) == digest)
        except ValueError as error:
            return self._reject(
                relative, f"unsafe destination path: {error}",
                ledger_status="FAILURE", size=size, digest=digest,
            )
        except OSError as error:
            return self._reject(relative, f"destination not accessible: {error}")
        if exists:
            if identical:
                self.ledger.record(
                    relative, status="SUCCESS", size=size, sha256=digest,
                    session_id=self.session_id,
                    reason="identical file already existed",
                )
                return [(MessageKind.ALREADY_COMPLETE, json_bytes({
                    "path": relative, "size": size, "sha256": digest,
                    "session_id": self.session_id,
                }))]
            # Held for the session: not re-hashed or re-recorded on every manifest.
            return self._reject(
                relative, "destination exists with different content", status="CONFLICT",
                ledger_status="CONFLICT", size=size, digest=digest,
            )
        self.pending.append(item)
        self.queued_paths.add(relative)
        return []

    def handle(self, kind: int, payload: bytes, now: float) -> list[AppMessage]:
        outgoing: list[AppMessage] = []
        if kind == MessageKind.MANIFEST:
            value = parse_json(payload)
            if not isinstance(value, list):
                return []
            self.manifest_received = True
            for item in value:
                if isinstance(item, dict):
                    outgoing.extend(self._consider(item))
        elif kind == MessageKind.FILE_ANNOUNCE:
            value = parse_json(payload)
            if isinstance(value, dict):
                outgoing.extend(self._consider(value))
        elif kind == MessageKind.FILE_META:
            outgoing.extend(self._metadata(parse_json(payload), now))
        elif kind == MessageKind.FILE_DATA and self.transfer:
            if self.completed_message is not None:
                return [self.completed_message]
            transfer_id, index, data = decode_data(payload)
            if transfer_id != self.transfer.transfer_id:
                return outgoing
            try:
                is_new = self.transfer.writer.write(index, data)
            except (ValueError, OSError) as error:
                return self._fail_transfer(f"chunk rejected: {error}", now)
            self.transfer.reliable.accept(index)
            if is_new:
                if self.transfer.first_chunk_at is None:
                    self.transfer.first_chunk_at = now
                    self.transfer.first_chunk_bytes = len(data)
                self.transfer.last_chunk_at = now
                if self.transfer.progress is not None:
                    self.transfer.progress.update(chunk_bytes_done(
                        self.transfer.reliable.received,
                        self.transfer.reliable.chunk_count,
                        self.transfer.chunk_bytes, self.transfer.size,
                    ), now)
            else:
                self.transfer.duplicate_chunks += 1
            base, bitmap = self.transfer.reliable.ack()
            outgoing.append((MessageKind.FILE_ACK, encode_ack(transfer_id, base, bitmap)))
            if self.transfer.reliable.done:
                outgoing.extend(self._publish(now))
        elif kind == MessageKind.COMPLETE_CONFIRM and self.transfer:
            value = parse_json(payload)
            if value.get("transfer_id") == self.transfer.transfer_id.hex():
                self.transfer = None
                self.completed_message = None
        elif kind == MessageKind.CONFLICT:
            value = parse_json(payload)
            if self.transfer and value.get("path") == self.transfer.relative_path:
                self._failure_report(
                    self.transfer.relative_path,
                    str(value.get("reason") or "sender cancelled transfer"),
                )
                if self.transfer.progress is not None:
                    self.transfer.progress.finish(
                        "CANCELLED by sender; not complete", now,
                    )
                self.transfer.writer.abort()
                self.queued_paths.discard(self.transfer.relative_path)
                self.transfer = None
                self.completed_message = None
        elif kind == MessageKind.FILE_UNAVAILABLE:
            # The sender cannot serve the head request now (already sent, not
            # stable, changed, removed or locked). Drop it so the queue and the
            # token move on; a later announcement or manifest re-queues it.
            value = parse_json(payload)
            relative = value.get("path")
            if (self.transfer is None and self.pending
                    and self.pending[0].get("path") == relative):
                self.pending.pop(0)
                self.queued_paths.discard(relative)
        return outgoing

    def _metadata(self, value: dict, now: float) -> list[AppMessage]:
        relative = value.get("path")
        if self.transfer is not None or not self.pending or self.pending[0].get("path") != relative:
            return []
        try:
            transfer_id = bytes.fromhex(value["transfer_id"])
            size = int(value["size"])
            digest = value["sha256"]
            chunk_count = int(value["chunk_count"])
            chunk_bytes = int(value["chunk_bytes"])
            if (len(transfer_id) != 16 or size < 0 or not isinstance(digest, str)
                    or chunk_bytes <= 0
                    or chunk_count != max(1, math.ceil(size / chunk_bytes))):
                raise ValueError("inconsistent file metadata")
        except (KeyError, TypeError, ValueError) as error:
            self.pending.pop(0)
            return self._reject(relative, f"invalid file metadata: {error}")
        self.pending.pop(0)
        try:
            output = safe_output_path(self.root, relative)
            writer = AtomicReceiver(
                output, size, digest, chunk_count, chunk_bytes, temp_tag=transfer_id.hex(),
            )
        except ValueError as error:
            return self._reject(
                relative, f"unsafe destination path: {error}",
                ledger_status="FAILURE", size=size, digest=digest,
            )
        except OSError as error:
            return self._reject(relative, f"cannot create temporary file: {error}")
        self.transfer = ReceiverTransfer(
            transfer_id, relative, size, digest, writer,
            SelectiveRepeatReceiver(chunk_count), now,
            metrics_start=self.metrics_provider() if self.metrics_provider is not None else None,
            chunk_bytes=chunk_bytes,
            progress=(
                TransferProgress(self.progress_sink, "incoming", relative, size, now)
                if self.progress_sink is not None else None
            ),
        )
        base, bitmap = self.transfer.reliable.ack()
        return [(MessageKind.FILE_ACK, encode_ack(transfer_id, base, bitmap))]

    def _publish(self, now: float) -> list[AppMessage]:
        transfer = self.transfer
        assert transfer is not None
        try:
            transfer.writer.publish()
        except FileExistsError:
            # Never replace a file that appeared meanwhile; hold it as a conflict.
            return self._fail_transfer(
                "destination appeared during transfer", now,
                status="CONFLICT", ledger_status="CONFLICT",
            )
        except (RuntimeError, OSError) as error:
            return self._fail_transfer(f"publish failed: {error}", now)
        self.ledger.record(
            transfer.relative_path, status="SUCCESS", size=transfer.size,
            sha256=transfer.sha256, session_id=self.session_id,
        )
        if transfer.progress is not None:
            transfer.progress.finish("DONE size and SHA-256 verified, saved", now)
        transfer_seconds = None
        measured_bytes = None
        goodput = None
        if (
            transfer.first_chunk_at is not None
            and transfer.last_chunk_at is not None
            and transfer.last_chunk_at > transfer.first_chunk_at
            and len(transfer.reliable.received) >= 2
        ):
            transfer_seconds = transfer.last_chunk_at - transfer.first_chunk_at
            measured_bytes = transfer.size - (transfer.first_chunk_bytes or 0)
            goodput = measured_bytes / transfer_seconds
        if self.report_path is not None:
            atomic_json(self.report_path, {
                "status": "SUCCESS",
                "reason": "file reconstructed and SHA-256 verified",
                "direction": "incoming",
                "relative_path": transfer.relative_path,
                "file_size": transfer.size,
                "expected_sha256": transfer.sha256,
                "actual_sha256": transfer.sha256,
                "sha256_verified": True,
                "session_id": self.session_id,
                "transfer_id": transfer.transfer_id.hex(),
                "unique_chunks": len(transfer.reliable.received),
                "duplicate_chunks": transfer.duplicate_chunks,
                "retransmitted_chunks": None,
                "missing_chunks": None,
                "metric_scope": "per-transfer; null means not attributable without guessing",
                "transfer_seconds": transfer_seconds,
                "goodput_measured_bytes": measured_bytes,
                "goodput_bytes_per_second": goodput,
                "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                **interval_metrics(transfer.metrics_start, self.metrics_provider),
            })
        self.completed_message = (
            MessageKind.FILE_COMPLETE,
            json_bytes({
                "transfer_id": transfer.transfer_id.hex(),
                "path": transfer.relative_path, "size": transfer.size,
                "sha256": transfer.sha256, "session_id": self.session_id,
            }),
        )
        self.last_complete_sent = now
        return [self.completed_message]

    def tick(self, now: float) -> list[AppMessage]:
        if self.completed_message is not None:
            if now - self.last_complete_sent >= 1.0:
                self.last_complete_sent = now
                return [self.completed_message]
            return []
        if self.transfer is not None:
            return []
        if not self.manifest_received:
            # A manifest can span many frames; asking again every second queued
            # several full copies before the first one was even displayed.
            if now - self.last_manifest_request >= MANIFEST_RETRY_SECONDS:
                self.last_manifest_request = now
                return [(MessageKind.MANIFEST_REQUEST, b"")]
            return []
        if self.pending and now - self.last_request >= 1.0:
            self.last_request = now
            return [(MessageKind.FILE_REQUEST, json_bytes({"path": self.pending[0]["path"]}))]
        return []
