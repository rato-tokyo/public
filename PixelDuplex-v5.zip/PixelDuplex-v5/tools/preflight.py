"""Read-only, non-invasive preflight checks for PixelDuplex hardware mode.

This utility deliberately does not open a camera/capture device or create a GUI
window, so it is safe to run while PixelDuplex (or another camera client) is
active.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


PASS = "PASS"
WARN = "WARN"
FAIL = "FAIL"


def result(name: str, status: str, summary: str, **details: Any) -> dict[str, Any]:
    item: dict[str, Any] = {"name": name, "status": status, "summary": summary}
    if details:
        item["details"] = details
    return item


def check_config() -> tuple[dict[str, Any], Any | None]:
    try:
        from src.app import load_settings

        settings = load_settings(ROOT)
        safe_settings = {
            "role": settings.role,
            "capture_device": settings.capture_device,
            "monitor_device": settings.monitor_device,
            "scan_interval_seconds": settings.scan_interval_seconds,
            "file_stable_seconds": settings.file_stable_seconds,
            "handshake_timeout_seconds": settings.handshake_timeout_seconds,
            "frame_interval_seconds": settings.frame_interval_seconds,
            "retransmit_seconds": settings.retransmit_seconds,
            "window_size": settings.window_size,
            "preferred_profile": settings.preferred_profile,
        }
        if settings.capture_device < 0:
            return result("config", FAIL, "capture_device must be zero or greater",
                          settings=safe_settings), None
        if settings.monitor_device is not None and not isinstance(settings.monitor_device, str):
            return result("config", FAIL, "monitor_device must be a string or null",
                          settings=safe_settings), None
        return result("config", PASS, "config.json is valid", settings=safe_settings), settings
    except Exception as error:
        return result("config", FAIL, str(error)), None


def check_key() -> dict[str, Any]:
    path = ROOT / "key.txt"
    try:
        if not path.is_file():
            return result("key", FAIL, "key.txt is missing")
        # Decode only long enough to validate non-emptiness. Never report the
        # password or metadata such as its length.
        password = path.read_text(encoding="utf-8").rstrip("\r\n")
        if not password:
            return result("key", FAIL, "key.txt is empty")
        return result("key", PASS, "key.txt is present and non-empty", readable=True)
    except (OSError, UnicodeError) as error:
        return result("key", FAIL, f"key.txt cannot be read as UTF-8: {error}")


def check_opencv() -> dict[str, Any]:
    try:
        import cv2
        from src.hardware import opencv_gui_backend

        build = cv2.getBuildInformation()
        gui_backend = opencv_gui_backend()
        directshow_line = next((line.strip() for line in build.splitlines()
                                if line.strip().startswith("DirectShow:")),
                               "DirectShow: unknown")
        gui_ok = gui_backend is not None
        dshow_constant = hasattr(cv2, "CAP_DSHOW")
        dshow_built = directshow_line.partition(":")[2].strip().upper() == "YES"
        status = PASS if gui_ok and dshow_constant and dshow_built else FAIL
        summary = ("OpenCV has GUI and DirectShow API support"
                   if status == PASS else "OpenCV lacks required GUI or DirectShow API support")
        return result("opencv", status, summary, version=cv2.__version__,
                      gui=gui_backend,
                      directshow_built=directshow_line.partition(":")[2].strip(),
                      cap_dshow_constant=dshow_constant)
    except Exception as error:
        return result("opencv", FAIL, f"OpenCV is unavailable: {error}")


def check_monitors(configured_device: str | None) -> dict[str, Any]:
    if os.name != "nt":
        return result("monitors", FAIL, "Windows monitor enumeration is unavailable")
    try:
        from src.hardware import active_monitors, choose_external_monitor, configure_dpi

        configure_dpi()
        monitors = active_monitors()
        safe = [
            {"device": item["device"], "primary": item["primary"], "rect": list(item["rect"]),
             "width": item["rect"][2] - item["rect"][0],
             "height": item["rect"][3] - item["rect"][1]}
            for item in monitors
        ]
        selected = choose_external_monitor(monitors, configured_device)
        return result("monitors", PASS, "exactly one suitable non-primary monitor was selected",
                      monitors=safe, selected_device=selected["device"])
    except Exception as error:
        monitors = locals().get("safe", [])
        return result("monitors", FAIL, str(error), monitors=monitors,
                      configured_device=configured_device)


def check_pnp_cameras(capture_device: int | None) -> dict[str, Any]:
    if os.name != "nt":
        return result("camera_pnp", WARN, "PnP camera inventory is only available on Windows")
    command = (
        "$ErrorActionPreference='Stop'; "
        "$utf8=[System.Text.UTF8Encoding]::new($false); "
        "[Console]::OutputEncoding=$utf8; $OutputEncoding=$utf8; "
        "$d=@(Get-PnpDevice -PresentOnly | Where-Object "
        "{ $_.Class -in @('Camera','Image') } | "
        "Select-Object Class,FriendlyName,InstanceId,Status); "
        "$d | ConvertTo-Json -Compress -Depth 3"
    )
    try:
        completed = subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            timeout=4, check=False,
        )
        if completed.returncode != 0:
            message = completed.stderr.strip() or "PnP query failed"
            return result("camera_pnp", WARN, message, configured_capture_device=capture_device)
        raw = completed.stdout.strip()
        parsed = json.loads(raw) if raw else []
        devices = parsed if isinstance(parsed, list) else [parsed]
        safe = [{
            "class": item.get("Class"), "friendly_name": item.get("FriendlyName"),
            "instance_id": item.get("InstanceId"), "status": item.get("Status"),
        } for item in devices]
        if not safe:
            return result("camera_pnp", WARN, "no present Camera/Image PnP devices were found",
                          configured_capture_device=capture_device, devices=[])
        return result(
            "camera_pnp", PASS, f"found {len(safe)} present Camera/Image PnP device(s)",
            configured_capture_device=capture_device, devices=safe,
            note=("DirectShow numeric indices cannot be mapped reliably from PnP data; "
                  "the configured device is not opened by preflight."),
        )
    except subprocess.TimeoutExpired:
        return result("camera_pnp", WARN, "PnP query timed out after 4 seconds",
                      configured_capture_device=capture_device)
    except Exception as error:
        return result("camera_pnp", WARN, f"PnP query unavailable: {error}",
                      configured_capture_device=capture_device)


def protocol_version() -> int | None:
    """Code protocol version, compared between both ends before switching (PD-DEC-037)."""
    try:
        from src.constants import PROTOCOL_VERSION

        return PROTOCOL_VERSION
    except Exception:
        return None


def collect() -> dict[str, Any]:
    config_check, settings = check_config()
    checks = [
        config_check,
        check_key(),
        check_opencv(),
        check_monitors(settings.monitor_device if settings else None),
        check_pnp_cameras(settings.capture_device if settings else None),
    ]
    statuses = {item["status"] for item in checks}
    overall = FAIL if FAIL in statuses else WARN if WARN in statuses else PASS
    return {
        "tool": "PixelDuplex preflight",
        "overall_status": overall,
        "project_root": str(ROOT),
        "platform": platform.platform(),
        "protocol_version": protocol_version(),
        # load_settings() already defaults an omitted value to "baseline".
        "preferred_profile": settings.preferred_profile if settings else None,
        "capture_device_opened": False,
        "checks": checks,
    }


def print_human(report: dict[str, Any]) -> None:
    print(f"PixelDuplex preflight: {report['overall_status']}")
    print(f"Protocol version: {report.get('protocol_version')} | "
          f"preferred_profile: {report.get('preferred_profile')}")
    for item in report["checks"]:
        print(f"[{item['status']}] {item['name']}: {item['summary']}")
        details = item.get("details", {})
        if item["name"] == "monitors":
            for monitor in details.get("monitors", []):
                print(f"  - {monitor['device']} primary={monitor['primary']} "
                      f"{monitor['width']}x{monitor['height']} rect={tuple(monitor['rect'])}")
        elif item["name"] == "camera_pnp":
            for device in details.get("devices", []):
                print(f"  - {device['friendly_name']} [{device['status']}] ({device['class']})")
    print("Capture device opened: no")


def main() -> int:
    parser = argparse.ArgumentParser(description="Run safe, read-only PixelDuplex preflight checks.")
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    args = parser.parse_args()
    report = collect()
    if args.json:
        # ASCII escaping makes the byte stream valid UTF-8 even when Windows
        # redirects stdout through a legacy code page such as CP932.
        print(json.dumps(report, ensure_ascii=True, indent=2))
    else:
        print_human(report)
    return {PASS: 0, WARN: 1, FAIL: 2}[report["overall_status"]]


if __name__ == "__main__":
    raise SystemExit(main())
