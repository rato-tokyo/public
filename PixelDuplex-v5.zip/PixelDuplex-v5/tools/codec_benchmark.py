"""Offline pixel-format comparison; never opens a capture device or changes app state.

This is a synthetic screen/capture model, not proof that a physical link works.
The output is intentionally independent of PixelDuplex's current wire format.
"""

from __future__ import annotations

import argparse
import json
import time

import cv2
import numpy as np


FORMATS = (("mono-1", 1, 1, 2), ("mono-2", 2, 1, 2),
           ("mono-3", 3, 1, 2), ("mono-4", 4, 1, 2),
           ("gray4-2", 2, 1, 4), ("gray4-3", 3, 1, 4),
           ("gray4-4", 4, 1, 4), ("rgb-2", 2, 3, 2),
           ("rgb-3", 3, 3, 2))
WIDTH, HEIGHT = 1920, 1080


def encode(symbols: np.ndarray, cell: int, channels: int) -> np.ndarray:
    grid_height, grid_width = symbols.shape[:2]
    image = np.repeat(np.repeat(symbols, cell, axis=0), cell, axis=1)
    if channels == 1:
        image = np.repeat(image[:, :, None], 3, axis=2)
    return image[:grid_height * cell, :grid_width * cell]


def decode(image: np.ndarray, cell: int, channels: int, levels: int = 2) -> np.ndarray:
    # Mean over a cell is less phase-sensitive than a single pixel sample.
    height, width = image.shape[:2]
    cells = image[:height - height % cell, :width - width % cell]
    means = cells.reshape(height // cell, cell, width // cell, cell, 3).mean(axis=(1, 3))
    if channels == 1:
        means = means[:, :, 0]
    palette = np.linspace(0, 255, levels)
    return np.argmin(abs(means[..., None] - palette), axis=-1).astype(np.uint8)


def distort(image: np.ndarray, *, scale: float, border: int, noise: float,
            rng: np.random.Generator) -> np.ndarray:
    changed = image
    if scale != 1:
        resized = cv2.resize(changed, None, fx=scale, fy=scale,
                             interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR)
        changed = cv2.resize(resized, (image.shape[1], image.shape[0]),
                             interpolation=cv2.INTER_LINEAR)
    if noise:
        perturbation = rng.normal(0, noise, changed.shape)
        changed = np.clip(changed.astype(np.float32) + perturbation, 0, 255).astype(np.uint8)
    if border:
        # Model underscan: entire image shrinks into black margins, then crop/normalize.
        inner = cv2.resize(changed, (image.shape[1] - 2 * border,
                                     image.shape[0] - 2 * border),
                           interpolation=cv2.INTER_AREA)
        canvas = np.zeros_like(image)
        canvas[border:-border, border:-border] = inner
        changed = cv2.resize(canvas[border:-border, border:-border],
                             (image.shape[1], image.shape[0]),
                             interpolation=cv2.INTER_LINEAR)
    return changed


def benchmark(*, scale: float = 1.0, border: int = 0, noise: float = 0.0,
              seed: int = 1) -> list[dict]:
    if not 0.5 <= scale <= 1.5 or not 0 <= border < min(WIDTH, HEIGHT) // 4 or not 0 <= noise <= 100:
        raise ValueError("scale, border or noise out of safe benchmark range")
    results = []
    for name, cell, channels, levels in FORMATS:
        rng = np.random.default_rng(seed)
        shape = (HEIGHT // cell, WIDTH // cell)
        symbols = rng.integers(0, levels, (*shape, channels), dtype=np.uint8)
        if channels == 1:
            symbols = symbols[:, :, 0]
        palette = np.rint(np.linspace(0, 255, levels)).astype(np.uint8)
        start = time.perf_counter()
        image = encode(palette[symbols], cell, channels)
        encode_ms = (time.perf_counter() - start) * 1000
        changed = distort(image, scale=scale, border=border, noise=noise, rng=rng)
        start = time.perf_counter()
        recovered = decode(changed, cell, channels, levels)
        decode_ms = (time.perf_counter() - start) * 1000
        errors = int(np.count_nonzero(recovered != symbols))
        symbol_count = int(symbols.size)
        bits_per_symbol = int(np.log2(levels))
        results.append({"format": name, "cell": cell, "channels": channels,
                        "levels": levels,
                        "raw_payload_bytes": symbol_count * bits_per_symbol // 8,
                        "symbol_errors": errors, "symbol_error_rate": errors / symbol_count,
                        "encode_ms": round(encode_ms, 3), "decode_ms": round(decode_ms, 3)})
    return results


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scale", type=float, default=1.0,
                        help="synthetic capture scaling factor (0.5-1.5)")
    parser.add_argument("--border", type=int, default=0,
                        help="synthetic black underscan border in pixels")
    parser.add_argument("--noise", type=float, default=0.0,
                        help="synthetic independent channel Gaussian noise, standard deviation")
    parser.add_argument("--seed", type=int, default=1)
    arguments = parser.parse_args(argv)
    try:
        rows = benchmark(scale=arguments.scale, border=arguments.border,
                         noise=arguments.noise, seed=arguments.seed)
    except ValueError as error:
        parser.error(str(error))
    print(json.dumps({"kind": "synthetic_offline_codec_benchmark", "physical_validation": False,
                      "warning": "RGB model treats B/G/R channels as independent. It does not model actual YUY2 chroma subsampling, HDMI processing, or USB capture; physical tests are required.",
                      "width": WIDTH, "height": HEIGHT, "scale": arguments.scale,
                      "border": arguments.border, "noise": arguments.noise,
                      "formats": rows}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
