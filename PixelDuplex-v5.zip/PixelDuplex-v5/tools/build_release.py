"""Build an immutable, sender-ready PixelDuplex release ZIP.

Only explicitly listed source files are packaged. Runtime data and secrets are
never considered, even when the destination is inside this repository.
"""

from __future__ import annotations

import argparse
import ast
import json
import shutil
import stat
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RELEASE_FILES = (
    "AGENTS.md",
    "issues.md",
    "pixelduplex.py",
    "requirements.txt",
    "config.sender.json",
    "config.receiver.json",
    "src/__init__.py",
    "src/app.py",
    "src/codec_v5.py",
    "src/constants.py",
    "src/crypto.py",
    "src/diagnostic.py",
    "src/duplex.py",
    "src/file_loopback.py",
    "src/files.py",
    "src/handshake.py",
    "src/hardware.py",
    "src/ledger.py",
    "src/link.py",
    "src/messages.py",
    "src/profile_negotiation.py",
    "src/reliable.py",
    "src/sync.py",
    "src/wire.py",
    "tools/build_release.py",
    "tools/capture_probe.py",
    "tools/codec_benchmark.py",
    "tools/preflight.py",
    "tools/status_snapshot.py",
    "tests/test_core.py",
    "tests/test_build_release.py",
    "tests/test_capture_reopen.py",
    "tests/test_codec_benchmark.py",
    "tests/test_codec_v5.py",
    "tests/test_config_templates.py",
    "tests/test_echo_responder.py",
    "tests/test_entrypoint.py",
    "tests/test_file_loopback.py",
    "tests/test_file_test_cli.py",
    "tests/test_fragment_bounds.py",
    "tests/test_full_stack.py",
    "tests/test_issue002_offline.py",
    "tests/test_issue008_offline.py",
    "tests/test_issue012_queue_collapse.py",
    "tests/test_runner_e2e.py",
    "tests/test_sync_robustness.py",
    "tests/test_v5_runtime_guards.py",
    "tests/test_transfer_progress.py",
    "tests/test_profile_negotiation.py",
    "tests/test_reliable_display.py",
    "tests/test_replay_behavior.py",
    "tests/test_tools.py",
    "tests/test_transfer_reports.py",
    "tests/test_transport_metrics.py",
    "tests/test_v5_chunking.py",
    "tests/test_v5_transport.py",
)
SOURCE_DIRS = ("src", "tools", "tests")


def check_manifest_complete(root: Path) -> None:
    """Fail closed when a new Python module was not reviewed for packaging."""
    listed = set(RELEASE_FILES)
    discovered = {path.relative_to(root).as_posix() for path in root.glob("*.py")}
    for directory in SOURCE_DIRS:
        discovered.update(
            path.relative_to(root).as_posix()
            for path in (root / directory).rglob("*.py")
            if "__pycache__" not in path.parts
        )
    missing = sorted(discovered - listed)
    if missing:
        raise ValueError("配布許可リストに未登録のPythonファイルがあります: " + ", ".join(missing))


def protocol_version(root: Path) -> int:
    source = (root / "src" / "constants.py").read_text(encoding="utf-8")
    for node in ast.parse(source).body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "PROTOCOL_VERSION"
            for target in node.targets
        ):
            value = ast.literal_eval(node.value)
            if type(value) is int and value > 0:
                return value
    raise ValueError("src/constants.py の PROTOCOL_VERSION を判定できません")


def checked_source(root: Path, relative: str) -> Path:
    path = root / relative
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"配布に必要な通常ファイルがありません: {relative}")
    # Junctions and other reparse points must not pull data from elsewhere.
    if hasattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT"):
        for item in (path, *path.parents):
            if item == root.parent:
                break
            if item.stat().st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                raise ValueError(f"リパースポイントは配布できません: {relative}")
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError(f"配布元の外部参照を拒否しました: {relative}")
    return path


def build_release(root: Path, output_dir: Path, version: int) -> tuple[Path, Path]:
    actual = protocol_version(root)
    if version != actual:
        raise ValueError(f"指定 v{version} と実装プロトコル v{actual} が一致しません")
    for synced in ("target", "received"):
        # A release folder under target/ would be synced file by file.
        if output_dir.resolve().is_relative_to((root / synced).resolve()):
            raise ValueError(f"出力先を {synced}/ 配下にしないでください。ZIPだけを target/ へコピーします")
    folder_name = f"PixelDuplex-v{version}"
    destination = output_dir / folder_name
    archive = output_dir / f"{folder_name}.zip"
    if destination.exists() or archive.exists():
        raise FileExistsError("同名の配布フォルダまたはZIPが既にあります。上書きしません")

    check_manifest_complete(root)
    sources = [(relative, checked_source(root, relative)) for relative in RELEASE_FILES]
    sender = json.loads(checked_source(root, "config.sender.json").read_text(encoding="utf-8"))
    if not isinstance(sender, dict) or sender.get("role") != "sender":
        raise ValueError("config.sender.json の role は sender である必要があります")
    receiver = json.loads(checked_source(root, "config.receiver.json").read_text(encoding="utf-8"))
    if not isinstance(receiver, dict) or receiver.get("role") != "receiver":
        raise ValueError("config.receiver.json の role は receiver である必要があります")

    output_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".pixelduplex-release-", dir=output_dir) as temporary:
        temp = Path(temporary)
        staged = temp / folder_name
        for relative, source in sources:
            target = staged / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
        shutil.copyfile(root / "config.sender.json", staged / "config.json")
        staged_archive = temp / f"{folder_name}.zip"
        with zipfile.ZipFile(staged_archive, "w", compression=zipfile.ZIP_DEFLATED) as zip_file:
            for file in sorted(staged.rglob("*")):
                if file.is_file():
                    zip_file.write(file, f"{folder_name}/{file.relative_to(staged).as_posix()}")
        if destination.exists() or archive.exists():
            raise FileExistsError("配布先に同名ファイルが作成されました。上書きしません")
        staged.rename(destination)
        staged_archive.rename(archive)
    return destination, archive


def main() -> int:
    parser = argparse.ArgumentParser(description="現行プロトコル版の送信側配布物を安全に作成")
    parser.add_argument("--version", type=int, required=True, help="期待するプロトコル番号")
    parser.add_argument("--output-dir", type=Path, required=True, help="配布フォルダとZIPの出力先")
    args = parser.parse_args()
    try:
        destination, archive = build_release(ROOT, args.output_dir.resolve(), args.version)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        parser.exit(1, f"ERROR: {error}\n")
    print(f"Release folder: {destination}")
    print(f"Release ZIP: {archive}")
    print("key.txt は含みません。対象端末で別途設定してください。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
