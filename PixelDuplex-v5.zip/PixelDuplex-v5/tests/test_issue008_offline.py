"""Offline checks for ISSUE-008/009; these do not replace two-PC trials."""

from __future__ import annotations

import unittest
from unittest import mock

from src import codec_v5
from src.app import Runner
from src.constants import MessageKind
from src.link import LinkSession
from src.profile_negotiation import (
    BASELINE_PROFILE, ProfileAgreementError, ProfileNegotiator,
)
from src.wire import decode_image, packet_image


PROFILES = frozenset({"baseline", "mono-band4"})


def exchange(a: LinkSession, b: LinkSession, start: float, rounds: int = 20) -> None:
    """Deliver periodic and response packets both ways without loss."""
    for step in range(rounds):
        now = start + step
        for source, destination in ((a, b), (b, a)):
            pending = [(destination, packet) for packet in source.periodic(now)]
            while pending:
                receiver, packet = pending.pop(0)
                reply_to = a if receiver is b else b
                outgoing, _ = receiver.receive(packet)
                pending.extend((reply_to, reply) for reply in outgoing)


class LateAndMalformedProfileMessageTests(unittest.TestCase):
    def active_pair(self):
        initiator = ProfileNegotiator("initiator", "s", PROFILES)
        responder = ProfileNegotiator("responder", "s", PROFILES)
        proposal = initiator.propose("mono-band4", "x", 0)
        ack = responder.receive(proposal, 1)
        retried_ack = responder.pending_message(2)
        confirm = initiator.receive(ack, 3)
        initiator.receive(responder.receive(confirm, 4), 5)
        return initiator, responder, retried_ack

    def test_late_retried_ack_after_activation_is_ignored(self):
        initiator, _, retried_ack = self.active_pair()
        self.assertEqual(initiator.state, "ACTIVE")
        self.assertIsNone(initiator.receive(retried_ack, 6))
        self.assertEqual(initiator.active_profile, "mono-band4")

    def test_late_ack_with_changed_profile_fails_closed(self):
        initiator, _, retried_ack = self.active_pair()
        with self.assertRaises(ProfileAgreementError):
            initiator.receive(dict(retried_ack, profile_id="baseline"), 6)
        self.assertEqual(initiator.active_profile, BASELINE_PROFILE)

    def test_non_string_fields_fail_closed_without_type_error(self):
        for field in ("type", "session_id", "exchange_id", "profile_id"):
            responder = ProfileNegotiator("responder", "s", PROFILES)
            initiator = ProfileNegotiator("initiator", "s", PROFILES)
            message = dict(initiator.propose("mono-band4", "x", 0), **{field: ["mono-band4"]})
            with self.assertRaises(ProfileAgreementError):
                responder.receive(message, 1)
            self.assertEqual(responder.state, "FAILED")
            self.assertEqual(responder.active_profile, BASELINE_PROFILE)

    def test_lost_final_confirmation_times_out_to_baseline(self):
        initiator = ProfileNegotiator("initiator", "s", PROFILES)
        responder = ProfileNegotiator("responder", "s", PROFILES)
        confirm = initiator.receive(responder.receive(initiator.propose("mono-band4", "x", 0), 1), 2)
        responder.receive(confirm, 3)  # every PROFILE_CONFIRMED is lost
        self.assertEqual(responder.active_profile, "mono-band4")
        self.assertEqual(initiator.pending_message(5), confirm)
        initiator.tick(12)
        self.assertEqual(initiator.state, "FAILED")
        self.assertEqual(initiator.active_profile, BASELINE_PROFILE)


class RestartHandshakeTests(unittest.TestCase):
    def connected_pair(self):
        sender, receiver = LinkSession("sender", "pw"), LinkSession("receiver", "pw")
        exchange(sender, receiver, 0)
        self.assertTrue(sender.connected and receiver.connected)
        return sender, receiver

    def test_sender_rejoins_restarted_receiver_session(self):
        sender, receiver = self.connected_pair()
        restarted = LinkSession("receiver", "pw")
        exchange(sender, restarted, 100)
        self.assertTrue(sender.connected)
        self.assertTrue(restarted.connected)
        self.assertEqual(sender.session_id, restarted.session_id)
        self.assertNotEqual(sender.session_id, receiver.session_id)

    def test_late_duplicate_beacon_does_not_disconnect_sender(self):
        sender, receiver = self.connected_pair()
        stale_beacon = receiver.plain(receiver.handshake.beacon())
        for packet in stale_beacon:
            sender.receive(packet)
        self.assertTrue(sender.connected)

    def test_restarted_sender_cannot_join_existing_session(self):
        _, receiver = self.connected_pair()
        restarted = LinkSession("sender", "pw")
        exchange(restarted, receiver, 100)
        # Joining would restart the sender's AES-GCM sequence under old keys.
        self.assertFalse(restarted.connected)
        self.assertIsNone(restarted.handshake.channel)
        fresh_receiver = LinkSession("receiver", "pw")  # after 15 s silence
        exchange(restarted, fresh_receiver, 200)
        self.assertTrue(restarted.connected and fresh_receiver.connected)


class RunnerSessionChangeTests(unittest.TestCase):
    def test_new_peer_session_discards_candidate_profile_and_transfers(self):
        runner = Runner.__new__(Runner)
        runner.mode = "run"
        runner.link = mock.Mock()
        runner.link.session_id = b"\x02" * 16
        runner.profile = ProfileNegotiator("responder", (b"\x01" * 16).hex(), PROFILES)
        runner.applied_profile = "mono-band4"
        old_engine = mock.Mock()
        runner.engine = old_engine
        runner._new_engine = mock.Mock(return_value="new-engine")
        runner._new_diagnostic = mock.Mock(return_value="new-diagnostic")
        runner._status = mock.Mock()
        runner._seen_packet_order = mock.Mock()
        runner._seen_packets = mock.Mock()
        runner.io = mock.Mock()
        runner._check_session_change()
        runner.io.clear_outgoing.assert_called_once_with()
        old_engine.close.assert_called_once_with()
        runner.link.set_send_profile.assert_called_once_with(BASELINE_PROFILE)
        self.assertIsNone(runner.profile)
        self.assertEqual(runner.applied_profile, BASELINE_PROFILE)
        self.assertEqual(runner.engine, "new-engine")
        self.assertTrue(runner.reconnecting)

    def test_same_session_keeps_state(self):
        runner = Runner.__new__(Runner)
        runner.link = mock.Mock(session_id=b"\x01" * 16)
        runner.profile = ProfileNegotiator("responder", (b"\x01" * 16).hex(), PROFILES)
        runner._discard_session_state = mock.Mock()
        runner._check_session_change()
        runner._discard_session_state.assert_not_called()


class MixedCodecTests(unittest.TestCase):
    def test_baseline_and_candidate_frames_both_reach_the_link(self):
        sender, receiver = LinkSession("sender", "pw"), LinkSession("receiver", "pw")
        exchange(sender, receiver, 0)
        sender.set_send_profile("mono-band4")
        received = []
        for payload, force_baseline in ((b"candidate", False), (b"control", True)):
            for packet in sender.secure(MessageKind.KEEPALIVE, payload,
                                        force_baseline=force_baseline):
                image = (packet_image(packet) if force_baseline
                         else codec_v5.render_frame(codec_v5.MONO, [packet]))
                # Same decoder pair as HdmiFrameIO._decode_frame.
                decoded, _ = decode_image(image)
                bands = [decoded] if decoded is not None else codec_v5.decode_bands(image)[0]
                self.assertEqual(len(bands), 1)
                received.extend(receiver.receive(bands[0])[1])
        self.assertEqual(received, [
            (MessageKind.KEEPALIVE, b"candidate"), (MessageKind.KEEPALIVE, b"control"),
        ])


class DiagnosticSizeTests(unittest.TestCase):
    def test_out_of_range_size_is_rejected_before_config_or_hardware(self):
        from pathlib import Path
        from src.app import MAX_TEST_BYTES, MIN_TEST_BYTES, run_command
        for size in (MIN_TEST_BYTES - 1, MAX_TEST_BYTES + 1):
            with mock.patch("src.app.load_settings") as load_settings:
                with self.assertRaises(RuntimeError):
                    run_command(Path("."), "profile-test", test_bytes=size)
                load_settings.assert_not_called()


if __name__ == "__main__":
    unittest.main()
