"""Failure-status behavior of the CLI entry point."""

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import pixelduplex


class FailureStatusTests(unittest.TestCase):
    def test_failure_replaces_stale_ready_without_error_details(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            path = base / "artifacts" / "reports" / "status.json"
            path.parent.mkdir(parents=True)
            path.write_text('{"status":"READY"}', encoding="utf-8")
            pixelduplex.record_failure_status(base, "run")
            report = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(report["status"], "FAILURE")
            self.assertEqual(report["mode"], "run")
            self.assertFalse(report["connected"])
            self.assertNotIn("password", path.read_text(encoding="utf-8"))

    def test_active_instance_status_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            path = base / "artifacts" / "reports" / "status.json"
            path.parent.mkdir(parents=True)
            path.write_text('{"status":"READY"}', encoding="utf-8")
            with mock.patch.object(pixelduplex.InstanceLock, "__enter__", side_effect=RuntimeError("already running")):
                pixelduplex.record_failure_status(base, "run")
            self.assertEqual(json.loads(path.read_text(encoding="utf-8"))["status"], "READY")


if __name__ == "__main__":
    unittest.main()
