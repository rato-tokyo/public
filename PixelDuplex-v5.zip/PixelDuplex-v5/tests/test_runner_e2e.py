"""Two real Runners joined by an in-memory lossy display/capture channel.

Everything above the pixel codec runs for real: handshake, profile agreement,
duplex token, Selective Repeat, display queue, ACK coalescing and ledgers.
"""

from __future__ import annotations

import hashlib
import json
import os
import random
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

from src import hardware
from src.app import Runner, Settings
from src.hardware import HdmiFrameIO


PASSWORD = "e2e-shared-password"


class LoopIO(HdmiFrameIO):
    """HdmiFrameIO whose window and capture are a lossy in-memory link."""

    def __init__(self, name: str, frame_interval: float, loss: float, seed: int):
        super().__init__(0, frame_interval=frame_interval)
        self.window = name
        self.peer: LoopIO | None = None
        self.loss = loss
        self.random = random.Random(seed)
        self.stop_event = threading.Event()

    def start(self) -> None:
        pass

    def deliver(self, packet) -> None:
        # Called from the peer's display: drop, or capture once or twice.
        if self.random.random() < self.loss:
            return
        for _ in range(2 if self.random.random() < 0.3 else 1):
            self._incoming.put((packet, None))

    def pump_display(self) -> bool:
        super().pump_display()
        return not self.stop_event.is_set()

    def close(self) -> None:
        pass


def fake_imshow(window, packet) -> None:
    LINKS[window].deliver(packet)


LINKS: dict[str, LoopIO] = {}


def settings(role: str, **overrides) -> Settings:
    value = dict(
        role=role, capture_device=0, monitor_device=None,
        scan_interval_seconds=0.2, file_stable_seconds=0.3,
        handshake_timeout_seconds=60.0, frame_interval_seconds=0.004,
        retransmit_seconds=0.3, window_size=8,
    )
    value.update(overrides)
    return Settings(**value)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class RunnerEndToEndTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        root = Path(self.temporary.name)
        self.bases = {role: root / role for role in ("sender", "receiver")}
        for base in self.bases.values():
            for directory in ("target", "received", "artifacts/logs", "artifacts/reports"):
                (base / directory).mkdir(parents=True)
        patches = [
            mock.patch.object(hardware, "packet_image", lambda packet: packet),
            mock.patch.object(hardware.cv2, "imshow", fake_imshow),
            mock.patch.object(hardware.cv2, "waitKey", lambda _delay: -1),
            mock.patch("src.app.console", lambda _line: None),
            mock.patch("builtins.print", lambda *_args, **_kwargs: None),
        ]
        for patch in patches:
            patch.start()
            self.addCleanup(patch.stop)
        self.addCleanup(self.temporary.cleanup)

    def start_pair(self, loss: float, **overrides):
        runners, ios = {}, {}
        for seed, role in enumerate(("sender", "receiver")):
            runner = Runner(self.bases[role], settings(role, **overrides), PASSWORD, "run")
            io = LoopIO(f"window-{role}", runner.settings.frame_interval_seconds, loss, seed)
            runner.io = io
            runners[role], ios[role] = runner, io
        ios["sender"].peer, ios["receiver"].peer = ios["receiver"], ios["sender"]
        # A display on one end is a capture on the other end.
        LINKS.clear()
        LINKS["window-sender"] = ios["receiver"]
        LINKS["window-receiver"] = ios["sender"]
        results: dict[str, int] = {}
        threads = [
            threading.Thread(target=lambda r=role: results.__setitem__(r, runners[r].run()), daemon=True)
            for role in runners
        ]
        for thread in threads:
            thread.start()

        def stop():
            for io in ios.values():
                io.stop_event.set()
            for thread in threads:
                thread.join(timeout=10)
        self.addCleanup(stop)
        return runners, ios, stop, results

    def wait_for(self, predicate, timeout: float) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if predicate():
                return True
            time.sleep(0.05)
        return predicate()

    def write_source(self, role: str, relative: str, size: int) -> bytes:
        data = os.urandom(size)
        path = self.bases[role] / "target" / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return data

    def received(self, role: str, relative: str) -> bytes | None:
        path = self.bases[role] / "received" / relative
        return path.read_bytes() if path.exists() else None

    def test_duplex_sync_over_lossy_channel_keeps_queue_bounded(self):
        forward = self.write_source("sender", "dir/forward.bin", 900_000)
        backward = self.write_source("receiver", "backward.bin", 700_000)
        runners, ios, stop, results = self.start_pair(loss=0.15)

        done = self.wait_for(
            lambda: self.received("receiver", "dir/forward.bin") == forward
            and self.received("sender", "backward.bin") == backward
            and runners["sender"].ledger.is_complete("dir/forward.bin", "outgoing")
            and runners["receiver"].ledger.is_complete("backward.bin", "outgoing"),
            timeout=90,
        )
        stop()
        self.assertTrue(done, "duplex transfer did not finish over a 15% lossy channel")
        self.assertEqual(results, {"sender": 130, "receiver": 130})
        for role, io in ios.items():
            # Data is limited by the window, ACKs are coalesced: no v4-style
            # unbounded growth (ISSUE-012).
            self.assertLessEqual(io.max_outgoing_queue_depth, 8 + 8, role)
        ledger = json.loads((self.bases["receiver"] / "pixelduplex-ledger.json").read_text("utf-8"))
        self.assertEqual(ledger["incoming"]["dir/forward.bin"]["sha256"], sha256(forward))
        self.assertIsNone(self.received("sender", "dir/forward.bin"))
        self.assertIsNone(self.received("receiver", "backward.bin"))

    def test_v4_stall_parameters_still_make_progress(self):
        # ISSUE-012: window 8 x frame 0.125 == retransmit 1.0 jammed v4.
        # Same ratios, scaled down 25x so the test stays short.
        data = self.write_source("sender", "big.bin", 1_200_000)
        runners, ios, stop, _results = self.start_pair(
            loss=0.2, frame_interval_seconds=0.005, retransmit_seconds=0.04, window_size=8,
        )
        done = self.wait_for(lambda: self.received("receiver", "big.bin") == data, timeout=120)
        stop()
        self.assertTrue(done, "transfer stalled with the v4 window/retransmit/frame ratio")
        for role, io in ios.items():
            self.assertLessEqual(io.max_outgoing_queue_depth, 8 + 8, role)

    def test_receiver_restart_mid_transfer_resends_from_start(self):
        # ISSUE-009 / PD-DEC-011: a restarted peer must not leave the other
        # end stuck; the interrupted file is sent again from the beginning.
        data = self.write_source("sender", "restart.bin", 1_500_000)
        runners, ios, stop, results = self.start_pair(loss=0.1)
        received_dir = self.bases["receiver"] / "received"
        self.assertTrue(self.wait_for(
            lambda: runners["receiver"].engine.inbound.transfer is not None, timeout=30,
        ))
        ios["receiver"].stop_event.set()
        self.assertTrue(self.wait_for(lambda: "receiver" in results, timeout=10))

        runner = Runner(self.bases["receiver"], settings("receiver"), PASSWORD, "run")
        io = LoopIO("window-receiver-2", runner.settings.frame_interval_seconds, 0.1, 7)
        runner.io = io
        io.peer, ios["sender"].peer = ios["sender"], io
        LINKS["window-receiver-2"] = ios["sender"]
        LINKS["window-sender"] = io
        second: dict[str, int] = {}
        thread = threading.Thread(target=lambda: second.__setitem__("receiver", runner.run()), daemon=True)
        thread.start()
        self.addCleanup(thread.join, 10)
        self.addCleanup(io.stop_event.set)

        done = self.wait_for(
            lambda: self.received("receiver", "restart.bin") == data
            and runners["sender"].ledger.is_complete("restart.bin", "outgoing"),
            timeout=90,
        )
        self.assertTrue(done, "transfer did not recover after the receiver restarted")
        self.assertEqual(list(received_dir.glob("*.pdtmp")), [])

    def test_sender_restart_mid_transfer_recovers(self):
        data = self.write_source("sender", "restart-sender.bin", 1_500_000)
        runners, ios, stop, results = self.start_pair(loss=0.1)
        self.assertTrue(self.wait_for(
            lambda: runners["sender"].engine.outbound.transfer is not None, timeout=30,
        ))
        ios["sender"].stop_event.set()
        self.assertTrue(self.wait_for(lambda: "sender" in results, timeout=10))

        runner = Runner(self.bases["sender"], settings("sender"), PASSWORD, "run")
        io = LoopIO("window-sender-2", runner.settings.frame_interval_seconds, 0.1, 9)
        runner.io = io
        io.peer, ios["receiver"].peer = ios["receiver"], io
        LINKS["window-sender-2"] = ios["receiver"]
        LINKS["window-receiver"] = io
        second: dict[str, int] = {}
        thread = threading.Thread(target=lambda: second.__setitem__("sender", runner.run()), daemon=True)
        thread.start()
        self.addCleanup(thread.join, 10)
        self.addCleanup(io.stop_event.set)

        done = self.wait_for(
            lambda: self.received("receiver", "restart-sender.bin") == data
            and runner.ledger.is_complete("restart-sender.bin", "outgoing"),
            timeout=90,
        )
        self.assertTrue(done, "transfer did not recover after the sender restarted")


if __name__ == "__main__":
    unittest.main()
