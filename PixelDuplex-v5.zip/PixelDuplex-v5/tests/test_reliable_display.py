"""Physical-display timing for Selective Repeat retransmissions."""

import unittest

from src.reliable import SelectiveRepeatSender


class DisplayTimedSenderTests(unittest.TestCase):
    def test_queued_chunk_is_not_retransmitted_before_display(self):
        sender = SelectiveRepeatSender(3, 3, 1.0)
        self.assertEqual([item.index for item in sender.due(0.0)], [0, 1, 2])
        self.assertEqual(sender.due(100.0), [])
        sender.mark_displayed(0, 100.0)
        self.assertEqual(sender.due(100.9), [])
        self.assertEqual([(item.index, item.attempts) for item in sender.due(101.0)], [(0, 2)])
        self.assertEqual(sender.due(1000.0), [])  # retransmission still queued

    def test_lost_chunk_retries_after_each_actual_display(self):
        sender = SelectiveRepeatSender(1, 1, 1.0)
        sender.due(0.0)
        sender.mark_displayed(0, 3.0)
        self.assertEqual([item.attempts for item in sender.due(4.0)], [2])
        sender.mark_displayed(0, 10.0)
        self.assertEqual([item.attempts for item in sender.due(11.0)], [3])
        sender.acknowledge(1, 0)
        self.assertTrue(sender.done)
        self.assertEqual(sender.due(20.0), [])

    def test_budget_and_cancelled_queue_reservation(self):
        sender = SelectiveRepeatSender(5, 5, 1.0)
        self.assertEqual([item.index for item in sender.due(0.0, 2)], [0, 1])
        sender.cancel_pending(1)
        self.assertEqual([item.index for item in sender.due(1.0, 1)], [1])
        self.assertEqual([item.index for item in sender.due(1.0, 2)], [2, 3])


if __name__ == "__main__":
    unittest.main()
