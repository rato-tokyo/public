from __future__ import annotations

import unittest

from src.profile_negotiation import (
    BASELINE_PROFILE, ProfileAgreementError, ProfileNegotiator,
)


class ProfileNegotiationTests(unittest.TestCase):
    def pair(self, responder_profiles=frozenset({"baseline", "mono-band4"})):
        initiator = ProfileNegotiator(
            "initiator", "session-1", frozenset({"baseline", "mono-band4"})
        )
        responder = ProfileNegotiator("responder", "session-1", responder_profiles)
        return initiator, responder

    def test_explicit_agreement_before_switch(self):
        initiator, responder = self.pair()
        proposal = initiator.propose("mono-band4", "exchange-1", 0)
        self.assertEqual(initiator.active_profile, BASELINE_PROFILE)
        ack = responder.receive(proposal, 1)
        self.assertEqual(responder.active_profile, BASELINE_PROFILE)
        confirm = initiator.receive(ack, 2)
        self.assertEqual(initiator.active_profile, BASELINE_PROFILE)
        confirmed = responder.receive(confirm, 3)
        self.assertEqual(confirmed["type"], "PROFILE_CONFIRMED")
        self.assertIsNone(initiator.receive(confirmed, 4))
        self.assertEqual(initiator.active_profile, "mono-band4")
        self.assertEqual(responder.active_profile, "mono-band4")

    def test_unsupported_candidate_requires_explicit_baseline_confirmation(self):
        initiator, responder = self.pair(frozenset({"baseline"}))
        ack = responder.receive(initiator.propose("mono-band4", "x", 0), 1)
        self.assertEqual(ack["profile_id"], BASELINE_PROFILE)
        confirm = initiator.receive(ack, 2)
        self.assertEqual(confirm["profile_id"], BASELINE_PROFILE)
        initiator.receive(responder.receive(confirm, 3), 4)
        self.assertEqual(initiator.active_profile, BASELINE_PROFILE)

    def test_timeout_keeps_baseline_and_fails_closed(self):
        initiator, _ = self.pair()
        initiator.propose("mono-band4", "x", 0)
        initiator.tick(10)
        self.assertEqual(initiator.state, "FAILED")
        self.assertEqual(initiator.active_profile, BASELINE_PROFILE)
        with self.assertRaises(ProfileAgreementError):
            initiator.receive({"type": "PROFILE_ACK"}, 11)

    def test_mismatch_and_cross_session_rejected(self):
        initiator, responder = self.pair()
        proposal = initiator.propose("mono-band4", "x", 0)
        proposal["session_id"] = "other-session"
        with self.assertRaises(ProfileAgreementError):
            responder.receive(proposal, 1)
        self.assertEqual(responder.state, "FAILED")
        self.assertEqual(responder.active_profile, BASELINE_PROFILE)

    def test_unexpected_selection_and_replay_rejected(self):
        initiator, responder = self.pair()
        ack = responder.receive(initiator.propose("mono-band4", "x", 0), 1)
        ack["profile_id"] = "rgb2"
        with self.assertRaises(ProfileAgreementError):
            initiator.receive(ack, 2)
        self.assertEqual(initiator.active_profile, BASELINE_PROFILE)

    def test_unknown_profiles_and_arbitrary_parameters_rejected(self):
        with self.assertRaises(ValueError):
            ProfileNegotiator("initiator", "s", frozenset({"baseline", "peer_setting"}))
        initiator, responder = self.pair()
        proposal = initiator.propose("mono-band4", "x", 0)
        proposal["cell_size"] = 1
        with self.assertRaises(ProfileAgreementError):
            responder.receive(proposal, 1)

    def test_lost_ack_confirm_and_confirmed_retries(self):
        initiator, responder = self.pair()
        proposal = initiator.propose("mono-band4", "retry-1", 0)
        lost_ack = responder.receive(proposal, 1)
        self.assertEqual(responder.receive(proposal, 2), lost_ack)
        self.assertEqual(initiator.pending_message(2), proposal)

        confirm = initiator.receive(lost_ack, 3)
        self.assertEqual(initiator.receive(lost_ack, 4), confirm)
        self.assertEqual(initiator.pending_message(4), confirm)
        confirmed = responder.receive(confirm, 5)
        self.assertEqual(responder.receive(confirm, 6), confirmed)
        self.assertIsNone(initiator.receive(confirmed, 7))
        self.assertIsNone(initiator.receive(confirmed, 8))
        self.assertEqual(responder.receive(proposal, 9), lost_ack)
        self.assertEqual(initiator.active_profile, "mono-band4")
        self.assertEqual(responder.active_profile, "mono-band4")

    def test_stale_exchange_and_changed_duplicate_fail_closed(self):
        initiator, responder = self.pair()
        proposal = initiator.propose("mono-band4", "new", 0)
        responder.receive(proposal, 1)
        stale = dict(proposal, exchange_id="old")
        with self.assertRaises(ProfileAgreementError):
            responder.receive(stale, 2)
        self.assertEqual(responder.state, "FAILED")

        _, responder = self.pair()
        responder.receive(proposal, 1)
        changed = dict(proposal, profile_id="baseline")
        with self.assertRaises(ProfileAgreementError):
            responder.receive(changed, 2)
        self.assertEqual(responder.active_profile, BASELINE_PROFILE)

    def test_retries_do_not_extend_deadline(self):
        initiator, responder = self.pair()
        proposal = initiator.propose("mono-band4", "x", 0)
        responder.receive(proposal, 1)
        responder.receive(proposal, 9)
        self.assertIsNone(responder.pending_message(11))
        self.assertEqual(responder.state, "FAILED")
        self.assertEqual(responder.active_profile, BASELINE_PROFILE)


if __name__ == "__main__":
    unittest.main()
