"""Offline checks for v5 reconnect, stall and profile-purpose guards."""

from __future__ import annotations

import unittest
from collections import deque
from unittest import mock

import numpy as np

from src import codec_v5
from src.app import LINK_SILENCE_SECONDS, TRANSFER_STALL_SECONDS
from src.constants import MessageKind, PhysicalKind
from src.link import LinkSession
from src.profile_negotiation import BASELINE_PROFILE, ProfileNegotiator
from src.wire import PhysicalPacket
try:
    from test_issue002_offline import bare_runner
except ImportError:  # run as ``python -m unittest tests.test_v5_runtime_guards``
    from tests.test_issue002_offline import bare_runner


PASSWORD = "shared password"
PROFILES = frozenset({BASELINE_PROFILE, "mono-band4", "gray4-band4"})


def handshake(sender: LinkSession, receiver: LinkSession, record: list | None = None) -> None:
    """Run the handshake without loss; receiver-to-sender packets are recorded."""
    for step in range(30):
        now = step * 0.6
        to_receiver = list(sender.periodic(now))
        to_sender = list(receiver.periodic(now))
        while to_sender or to_receiver:
            while to_sender:
                packet = to_sender.pop(0)
                if record is not None:
                    record.append(packet)
                outgoing, _ = sender.receive(packet)
                to_receiver.extend(outgoing)
            while to_receiver:
                outgoing, _ = receiver.receive(to_receiver.pop(0))
                to_sender.extend(outgoing)
        if sender.connected and receiver.connected:
            return
    raise AssertionError("test handshake did not connect")


class StaleReadyTests(unittest.TestCase):
    def test_restarted_sender_ignores_ready_for_previous_challenge(self):
        old_sender = LinkSession("sender", PASSWORD)
        receiver = LinkSession("receiver", PASSWORD)
        recorded: list[PhysicalPacket] = []
        handshake(old_sender, receiver, recorded)
        ready = [p for p in recorded if p.kind == PhysicalKind.READY]
        beacon = [p for p in recorded if p.kind == PhysicalKind.BEACON]
        self.assertTrue(ready and beacon)

        new_sender = LinkSession("sender", PASSWORD)
        new_sender.receive(beacon[0])
        self.assertEqual(new_sender.handshake.state, "WAIT_READY")
        outgoing, messages = new_sender.receive(ready[0])  # must not raise

        self.assertEqual((outgoing, messages), ([], []))
        self.assertEqual(new_sender.authentication_failures, 1)
        self.assertEqual(new_sender.handshake.state, "WAIT_READY")


class HandshakeWatchdogTests(unittest.TestCase):
    def runner_in(self, state: str, started_at, now: float):
        runner = bare_runner(connected=False, now=now)
        runner.ever_connected = True
        runner.started = now - 1000.0
        runner.link.handshake.state = state
        runner.handshake_started_at = started_at
        return runner

    def run_at(self, runner, now: float) -> int:
        with mock.patch("src.app.time.monotonic", return_value=now):
            return runner.run()

    def test_partial_handshake_is_restarted_after_silence_limit(self):
        runner = self.runner_in("WAIT_PING", 100.0, 100.0 + LINK_SILENCE_SECONDS)
        self.run_at(runner, 100.0 + LINK_SILENCE_SECONDS)
        runner._reset_link.assert_called_once()
        runner._status.assert_any_call("RECONNECTING", "handshake did not complete")

    def test_sender_never_restarts_the_handshake_itself(self):
        # A sender reset only changes its challenge; a receiver in WAIT_PING
        # ignores the new AUTH, so both would wait (seen in the e2e test).
        now = 100.0 + LINK_SILENCE_SECONDS
        runner = self.runner_in("WAIT_READY", 100.0, now)
        runner.settings.role = "sender"
        self.run_at(runner, now)
        runner._reset_link.assert_not_called()
        self.assertIsNone(runner.handshake_started_at)

    def test_partial_handshake_is_kept_before_limit(self):
        runner = self.runner_in("WAIT_PING", 100.0, 100.0 + LINK_SILENCE_SECONDS - 1)
        self.run_at(runner, 100.0 + LINK_SILENCE_SECONDS - 1)
        runner._reset_link.assert_not_called()

    def test_first_partial_state_starts_the_clock(self):
        runner = self.runner_in("WAIT_READY", None, 500.0)
        self.run_at(runner, 500.0)
        self.assertEqual(runner.handshake_started_at, 500.0)
        runner._reset_link.assert_not_called()

    def test_connecting_state_clears_the_clock(self):
        runner = self.runner_in("CONNECTING", 1.0, 500.0)
        self.run_at(runner, 500.0)
        self.assertIsNone(runner.handshake_started_at)
        runner._reset_link.assert_not_called()


class TransferStallTests(unittest.TestCase):
    def runner_with_transfer(self, acked: set[int]):
        runner = bare_runner(connected=True, now=0.0)
        transfer = mock.Mock(transfer_id=b"t" * 16)
        transfer.reliable.acked = acked
        runner.engine.outbound.transfer = transfer
        return runner

    def test_flat_progress_is_a_stall_only_after_limit(self):
        acked: set[int] = set()
        runner = self.runner_with_transfer(acked)
        self.assertFalse(runner._transfer_stalled(0.0))
        self.assertFalse(runner._transfer_stalled(TRANSFER_STALL_SECONDS - 1))
        self.assertTrue(runner._transfer_stalled(TRANSFER_STALL_SECONDS))

    def test_new_chunk_restarts_the_clock(self):
        acked: set[int] = set()
        runner = self.runner_with_transfer(acked)
        runner._transfer_stalled(0.0)
        acked.add(0)
        self.assertFalse(runner._transfer_stalled(TRANSFER_STALL_SECONDS - 1))
        self.assertFalse(runner._transfer_stalled(TRANSFER_STALL_SECONDS + 1))

    def test_idle_link_is_never_stalled(self):
        runner = bare_runner(connected=True, now=0.0)
        self.assertFalse(runner._transfer_stalled(0.0))
        self.assertFalse(runner._transfer_stalled(10 * TRANSFER_STALL_SECONDS))

    def test_run_resets_a_stalled_transfer_even_while_keepalives_arrive(self):
        now = 1000.0
        runner = self.runner_with_transfer(set())
        runner.ever_connected = True
        runner.last_valid_packet = now  # KEEPALIVE liveness is fresh
        runner.progress_marker = runner._progress_marker()
        runner.progress_changed_at = now - TRANSFER_STALL_SECONDS
        with mock.patch("src.app.time.monotonic", return_value=now):
            runner.run()
        runner._reset_link.assert_called_once()
        runner._status.assert_any_call("RECONNECTING", "transfer stalled")


class ProfilePurposeTests(unittest.TestCase):
    def agree(self, proposed: str, purpose: str, responder_sync: str) -> tuple:
        initiator = ProfileNegotiator("initiator", "s", PROFILES)
        responder = ProfileNegotiator("responder", "s", PROFILES, sync_profile=responder_sync)
        message = initiator.propose(proposed, "x", 0.0, purpose=purpose)
        while message is not None:
            reply = responder.receive(message, 0.0)
            message = initiator.receive(reply, 0.0) if reply is not None else None
        self.assertEqual((initiator.state, responder.state), ("ACTIVE", "ACTIVE"))
        self.assertEqual(initiator.active_profile, responder.active_profile)
        return initiator.active_profile, responder.purpose

    def test_sync_proposal_the_responder_did_not_choose_falls_back_to_baseline(self):
        self.assertEqual(self.agree("gray4-band4", "sync", "mono-band4"), (BASELINE_PROFILE, "sync"))

    def test_sync_proposal_matching_both_ends_is_used(self):
        self.assertEqual(self.agree("mono-band4", "sync", "mono-band4"), ("mono-band4", "sync"))

    def test_trial_proposal_is_accepted_for_profile_test(self):
        self.assertEqual(self.agree("gray4-band4", "trial", BASELINE_PROFILE), ("gray4-band4", "trial"))

    def test_trial_profile_never_allows_file_sync(self):
        runner = bare_runner(connected=True, now=0.0)
        runner.applied_profile = "gray4-band4"
        runner.profile = mock.Mock(purpose="trial")
        self.assertFalse(runner._sync_allowed())
        runner.profile = mock.Mock(purpose="sync")
        self.assertTrue(runner._sync_allowed())
        runner.applied_profile = BASELINE_PROFILE
        runner.profile = mock.Mock(purpose="trial")
        self.assertTrue(runner._sync_allowed())

    def test_lost_candidate_session_falls_back_to_baseline(self):
        runner = bare_runner(connected=True, now=0.0)
        runner.settings.preferred_profile = "mono-band4"
        self.assertEqual(runner._sync_profile(), "mono-band4")
        runner.candidate_failed = True
        self.assertEqual(runner._sync_profile(), BASELINE_PROFILE)

    def test_reset_from_candidate_marks_it_failed(self):
        runner = bare_runner(connected=True, now=0.0)
        del runner._reset_link  # use the real method
        runner.password = PASSWORD
        runner.link = mock.Mock(authentication_failures=0, duplicate_secure_messages=0)
        runner.authentication_failures_total = 0
        runner.duplicate_secure_messages_total = 0
        runner._discard_session_state = mock.Mock()
        runner.applied_profile = "mono-band4"
        runner._reset_link()
        self.assertTrue(runner.candidate_failed)


class PartialBandDecodeTests(unittest.TestCase):
    def test_bands_found_exactly_and_after_normalization_are_merged(self):
        layout = codec_v5.MONO
        packets = [PhysicalPacket(4, b"s" * 16, index, 0, 1, 1, bytes([index]))
                   for index in range(1, 5)]
        frame = codec_v5.render_frame(layout, packets)
        exact_only = {0: packets[0]}
        normalized_only = {1: packets[1], 2: packets[2], 3: packets[3], 0: packets[0]}
        calls = iter([exact_only, normalized_only])
        with mock.patch.object(codec_v5, "_decode_exact", side_effect=lambda _f: next(calls)), \
             mock.patch.object(codec_v5, "normalize_active_image",
                               return_value=(frame, (1, 2, 3, 4))):
            decoded, rect = codec_v5.decode_bands(frame)
        self.assertEqual(decoded, packets)
        self.assertEqual(rect, codec_v5.FULL_RECT)

    def test_full_exact_decode_skips_normalization(self):
        layout = codec_v5.MONO
        packets = [PhysicalPacket(4, b"s" * 16, index, 0, 1, 1, bytes([index]))
                   for index in range(1, 5)]
        frame = codec_v5.render_frame(layout, packets)
        with mock.patch.object(codec_v5, "normalize_active_image") as normalize:
            decoded, _ = codec_v5.decode_bands(frame)
        normalize.assert_not_called()
        self.assertEqual(decoded, packets)

    def test_blank_frame_decodes_nothing(self):
        decoded, rect = codec_v5.decode_bands(np.zeros((1080, 1920, 3), dtype=np.uint8))
        self.assertEqual((decoded, rect), ([], None))


class DiagnosticIsolationTests(unittest.TestCase):
    def runner_receiving(self, mode: str):
        runner = bare_runner(connected=True, now=0.0)
        del runner._receive_packets  # use the real method
        del runner._send_app
        runner._send_app = mock.Mock()
        runner.mode = mode
        runner.ever_connected = True
        runner.profile = mock.Mock(state="ACTIVE", active_profile=BASELINE_PROFILE, purpose="sync")
        runner._seen_packet_order, runner._seen_packets = deque(), set()
        runner.unique_physical_frames_total = runner.duplicate_physical_frames_total = 0
        runner.diagnostic.handles.return_value = False
        runner.io.receive.return_value = [(mock.Mock(), None)]
        runner.link.receive.return_value = ([], [(MessageKind.FILE_ANNOUNCE, b"{}")])
        runner.link.last_authenticated_packet = True
        return runner

    def test_self_test_ignores_ordinary_sync_messages(self):
        for mode in ("self-test", "profile-test"):
            runner = self.runner_receiving(mode)
            runner._receive_packets(1.0)
            runner.engine.handle.assert_not_called()

    def test_run_still_handles_sync_messages(self):
        runner = self.runner_receiving("run")
        runner._receive_packets(1.0)
        runner.engine.handle.assert_called_once()


class DisplayScheduleTests(unittest.TestCase):
    def pump_at(self, io, now: float) -> None:
        with mock.patch("src.hardware.cv2.imshow"), \
             mock.patch("src.hardware.cv2.waitKey", return_value=-1), \
             mock.patch("src.hardware.packet_image", lambda packet: packet), \
             mock.patch("src.hardware.time.monotonic", return_value=now):
            io.pump_display()

    def test_late_display_does_not_push_the_schedule_back(self):
        from src.hardware import HdmiFrameIO
        io = HdmiFrameIO(0, frame_interval=0.4)
        io.send([PhysicalPacket(4, b"s" * 16, index, 0, 1, 1, b"x") for index in range(3)])
        self.pump_at(io, 10.0)
        self.assertAlmostEqual(io._next_frame_at, 10.4)
        self.pump_at(io, 10.45)  # 50 ms late
        self.assertAlmostEqual(io._next_frame_at, 10.8)

    def test_schedule_resyncs_after_idle(self):
        from src.hardware import HdmiFrameIO
        io = HdmiFrameIO(0, frame_interval=0.4)
        io.send([PhysicalPacket(4, b"s" * 16, 1, 0, 1, 1, b"x")])
        self.pump_at(io, 10.0)
        io.send([PhysicalPacket(4, b"s" * 16, 2, 0, 1, 1, b"x")])
        self.pump_at(io, 50.0)
        self.assertAlmostEqual(io._next_frame_at, 50.4)


class DisplayLossTests(unittest.TestCase):
    EXTERNAL = {"handle": 2, "device": r"\\.\DISPLAY2", "primary": False, "rect": (1920, 0, 3840, 1080)}
    PRIMARY = {"handle": 1, "device": r"\\.\DISPLAY1", "primary": True, "rect": (0, 0, 1920, 1080)}

    def io(self):
        from src.hardware import HdmiFrameIO
        io = HdmiFrameIO(0, frame_interval=0.4)
        io._monitor = dict(self.EXTERNAL)
        return io

    def check(self, io, monitors, rect, now=5.0):
        with mock.patch("src.hardware.active_monitors", return_value=monitors), \
             mock.patch("src.hardware.window_rect", return_value=rect), \
             mock.patch("src.hardware.hide_window") as hide:
            io.check_display(now)
        return hide

    def test_unchanged_external_monitor_passes(self):
        hide = self.check(self.io(), [self.PRIMARY, self.EXTERNAL], self.EXTERNAL["rect"])
        hide.assert_not_called()

    def test_lost_external_monitor_hides_and_stops(self):
        from src.hardware import DisplayLostError
        io = self.io()
        with self.assertRaisesRegex(DisplayLostError, "external monitor lost"):
            self.check(io, [self.PRIMARY], self.PRIMARY["rect"])

    def test_window_moved_to_primary_stops(self):
        from src.hardware import DisplayLostError
        with self.assertRaisesRegex(DisplayLostError, "left the external monitor"):
            self.check(self.io(), [self.PRIMARY, self.EXTERNAL], self.PRIMARY["rect"])

    def test_moved_external_monitor_stops(self):
        from src.hardware import DisplayLostError
        moved = dict(self.EXTERNAL, rect=(-1920, 0, 0, 1080))
        with self.assertRaisesRegex(DisplayLostError, "external monitor changed"):
            self.check(self.io(), [self.PRIMARY, moved], moved["rect"])

    def test_check_runs_at_most_once_per_second(self):
        io = self.io()
        self.check(io, [self.PRIMARY, self.EXTERNAL], self.EXTERNAL["rect"], now=5.0)
        with mock.patch("src.hardware.active_monitors") as monitors:
            io.check_display(5.5)
        monitors.assert_not_called()

    def test_runner_records_failure_and_exits(self):
        from src.hardware import DisplayLostError
        runner = bare_runner(connected=True, now=0.0)
        runner.io = mock.Mock()
        runner.io.start.side_effect = DisplayLostError("external monitor lost: test")
        runner.engine = mock.Mock()
        with mock.patch("builtins.print"):
            self.assertEqual(runner.run(), 1)
        runner._status.assert_called_with("FAILURE", "external monitor lost: test")
        runner.io.close.assert_called_once()


class StatusWriteTests(unittest.TestCase):
    def test_locked_status_file_does_not_stop_run(self):
        runner = bare_runner(connected=True, now=0.0)
        del runner._status  # use the real method
        runner._write_status = mock.Mock(side_effect=PermissionError("locked"))
        runner._status("READY")  # must not raise
        runner._write_status.assert_called_once_with("READY", "")


if __name__ == "__main__":
    unittest.main()
