from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

from src.constants import MessageKind
from src.duplex import DuplexEngine
from src.ledger import Ledger
from src.messages import json_bytes, parse_json


def request(request_id: str, content: bytes) -> dict:
    return {
        "id": request_id,
        "path": f"pixelduplex-test/{request_id}/forward.bin",
        "return_path": f"pixelduplex-test/{request_id}/return.bin",
        "size": len(content),
        "sha256": hashlib.sha256(content).hexdigest(),
    }


class EchoResponderTests(unittest.TestCase):
    def test_new_request_replaces_abandoned_request_without_reflecting_it(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            ledger = Ledger(root / "ledger.json", "sender")
            engine = DuplexEngine(root / "target", root / "received", ledger, "sender")
            first = request("1" * 32, b"one")
            second = request("2" * 32, b"two")

            def arm(value):
                messages = engine.handle(MessageKind.FILE_ECHO_ARM, json_bytes(value), 0)
                self.assertEqual(messages[0][0], MessageKind.FILE_ECHO_RESULT)
                return parse_json(messages[0][1])

            self.assertEqual(arm(first)["status"], "ARMED")
            self.assertEqual(arm(second)["status"], "ARMED")
            self.assertEqual(engine._file_echo_arm, second)

            source = root / "received" / first["path"]
            source.parent.mkdir(parents=True)
            source.write_bytes(b"one")
            ledger.scope("incoming").record(
                first["path"], status="SUCCESS", size=3, sha256=first["sha256"],
            )
            self.assertFalse((root / "target" / first["return_path"]).exists())

            source = root / "received" / second["path"]
            source.parent.mkdir(parents=True)
            source.write_bytes(b"two")
            ledger.scope("incoming").record(
                second["path"], status="SUCCESS", size=3, sha256=second["sha256"],
            )
            self.assertEqual(arm(second)["status"], "COPIED")
            self.assertEqual((root / "target" / second["return_path"]).read_bytes(), b"two")
            self.assertEqual(arm(first)["status"], "COPIED")
            self.assertEqual((root / "target" / first["return_path"]).read_bytes(), b"one")
            engine.close()


if __name__ == "__main__":
    unittest.main()
