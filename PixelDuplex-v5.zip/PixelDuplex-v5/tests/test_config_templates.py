"""Check that either role template can be used as config.json."""

import json
import shutil
import tempfile
import unittest
from pathlib import Path

from src.app import load_settings


ROOT = Path(__file__).resolve().parents[1]


class ConfigTemplateTests(unittest.TestCase):
    def test_role_templates_are_interchangeable(self):
        templates = {}
        for role in ("sender", "receiver"):
            template = ROOT / f"config.{role}.json"
            templates[role] = json.loads(template.read_text(encoding="utf-8"))
            with self.subTest(role=role), tempfile.TemporaryDirectory() as directory:
                shutil.copyfile(template, Path(directory) / "config.json")
                self.assertEqual(load_settings(Path(directory)).role, role)

        self.assertEqual(templates["sender"]["role"], "sender")
        self.assertEqual(templates["receiver"]["role"], "receiver")
        for role in templates:
            self.assertEqual(
                {key: value for key, value in templates[role].items() if key != "role"},
                {key: value for key, value in templates["sender"].items() if key != "role"},
            )
            self.assertNotIn("password", templates[role])
            self.assertNotIn("key", templates[role])


if __name__ == "__main__":
    unittest.main()
