"""Offline checks for the v5 banded physical frames (PD-DEC-040)."""

import unittest

import cv2
import numpy as np

from src import codec_v5, wire


def band_packet(message_id: int, payload: bytes, index: int = 0, count: int = 1,
                total: int | None = None) -> wire.PhysicalPacket:
    return wire.PhysicalPacket(
        4, b"s" * 16, message_id, index, count,
        len(payload) if total is None else total, payload,
    )


def full_bands(layout: codec_v5.BandLayout, seed: int) -> list[wire.PhysicalPacket]:
    rng = np.random.default_rng(seed)
    return [band_packet(seed * 10 + band, rng.bytes(layout.payload_bytes))
            for band in range(codec_v5.BANDS)]


class BandLayoutTests(unittest.TestCase):
    def test_capacities_and_chunk_sizes(self):
        self.assertEqual(codec_v5.MONO.band_bytes, 16_200)
        self.assertEqual(codec_v5.MONO.payload_bytes, 16_132)
        self.assertEqual(codec_v5.MONO.chunk_bytes, 16_000)
        self.assertEqual(codec_v5.GRAY4.band_bytes, 32_400)
        self.assertEqual(codec_v5.GRAY4.payload_bytes, 32_332)
        self.assertEqual(codec_v5.GRAY4.chunk_bytes, 32_000)
        # A sealed FILE_DATA message of one chunk must fit one band exactly.
        for layout in codec_v5.LAYOUTS.values():
            self.assertLessEqual(layout.chunk_bytes + 45, layout.payload_bytes)
        self.assertEqual(codec_v5.BANDS * codec_v5.BAND_ROWS, 540)

    def test_layout_lookup_rejects_unknown(self):
        self.assertIs(codec_v5.layout_for("mono-band4"), codec_v5.MONO)
        with self.assertRaises(ValueError):
            codec_v5.layout_for("baseline")


class BandCodecTests(unittest.TestCase):
    def test_all_bands_round_trip_for_each_layout(self):
        for seed, layout in enumerate(codec_v5.LAYOUTS.values(), start=1):
            packets = full_bands(layout, seed)
            image = codec_v5.render_frame(layout, packets)
            self.assertEqual(image.shape, (1080, 1920, 3))
            decoded, rect = codec_v5.decode_bands(image)
            self.assertEqual(decoded, packets)
            self.assertEqual(rect, codec_v5.FULL_RECT)

    def test_fragmentation_and_empty(self):
        layout = codec_v5.MONO
        data = b"a" * (layout.payload_bytes + 17)
        packets = codec_v5.fragment_message(layout, 4, b"s" * 16, 9, data)
        self.assertEqual(len(packets), 2)
        self.assertEqual(b"".join(packet.payload for packet in packets), data)
        for packet in packets:
            raw = codec_v5.encode_packet(layout, packet)
            self.assertEqual(codec_v5.decode_packet(layout, raw), packet)
        empty = codec_v5.fragment_message(layout, 4, b"s" * 16, 10, b"")
        self.assertEqual(len(empty), 1)
        raw = codec_v5.encode_packet(layout, empty[0])
        self.assertEqual(codec_v5.decode_packet(layout, raw), empty[0])

    def test_corruption_and_format_separation(self):
        packet = band_packet(7, b"hello")
        raw = bytearray(codec_v5.encode_packet(codec_v5.MONO, packet))
        raw[100] ^= 1
        self.assertIsNone(codec_v5.decode_packet(codec_v5.MONO, bytes(raw)))
        self.assertIsNone(wire.decode_packet(codec_v5.encode_packet(codec_v5.MONO, packet)))
        # Same size is impossible across layouts, but the magic also differs.
        self.assertNotEqual(codec_v5.MONO.magic, codec_v5.GRAY4.magic)
        v4_image = wire.packet_image(packet)
        self.assertEqual(codec_v5.decode_bands(v4_image), ([], None))
        band_image = codec_v5.render_frame(codec_v5.MONO, [packet])
        self.assertEqual(wire.decode_image(band_image), (None, None))

    def test_one_damaged_band_leaves_the_others_decodable(self):
        packets = full_bands(codec_v5.MONO, 3)
        image = codec_v5.render_frame(codec_v5.MONO, packets)
        top = 2 * codec_v5.BAND_PIXEL_ROWS
        image[top + 40:top + 60] = 255 - image[top + 40:top + 60]
        decoded, _ = codec_v5.decode_bands(image)
        self.assertEqual(decoded, [packets[0], packets[1], packets[3]])

    def test_torn_capture_during_staggered_repaint_loses_one_band_at_most(self):
        layout = codec_v5.MONO
        old = full_bands(layout, 4)
        canvas = codec_v5.render_frame(layout, old)
        before = canvas.copy()
        replacement = band_packet(99, b"new band")
        codec_v5.paint_band(canvas, 1, layout, replacement)
        # Scanout tear in the middle of the band being repainted.
        tear = codec_v5.BAND_PIXEL_ROWS + codec_v5.BAND_PIXEL_ROWS // 2
        torn = np.vstack([canvas[:tear], before[tear:]])
        decoded, _ = codec_v5.decode_bands(torn)
        self.assertEqual(decoded, [old[0], old[2], old[3]])
        decoded, _ = codec_v5.decode_bands(canvas)
        self.assertEqual(decoded, [old[0], replacement, old[2], old[3]])

    def test_bands_of_different_layouts_share_one_screen(self):
        canvas = codec_v5.blank_canvas()
        mono, gray = band_packet(1, b"mono"), band_packet(2, b"gray")
        codec_v5.paint_band(canvas, 0, codec_v5.MONO, mono)
        codec_v5.paint_band(canvas, 3, codec_v5.GRAY4, gray)
        decoded, _ = codec_v5.decode_bands(canvas)
        self.assertEqual(decoded, [mono, gray])

    def test_paint_band_rejects_out_of_range_index(self):
        with self.assertRaises(ValueError):
            codec_v5.paint_band(codec_v5.blank_canvas(), codec_v5.BANDS,
                                codec_v5.MONO, band_packet(1, b"x"))

    def test_shifted_phase(self):
        packets = full_bands(codec_v5.MONO, 5)
        image = codec_v5.render_frame(codec_v5.MONO, packets)
        shifted = np.zeros_like(image)
        shifted[1:, 1:] = image[:-1, :-1]
        decoded, _ = codec_v5.decode_bands(shifted)
        # The last cell column/row is cut off, so the bottom band may be lost,
        # but no band may decode to wrong data.
        self.assertTrue(decoded)
        for packet in decoded:
            self.assertIn(packet, packets)

    def test_scaled_gray_band_is_rejected_not_misread(self):
        packets = full_bands(codec_v5.GRAY4, 6)
        image = codec_v5.render_frame(codec_v5.GRAY4, packets)
        border = 20
        canvas = np.zeros_like(image)
        canvas[border:-border, border:-border] = cv2.resize(
            image, (1920 - 2 * border, 1080 - 2 * border), interpolation=cv2.INTER_AREA)
        decoded, _ = codec_v5.decode_bands(canvas)
        # Resampling damages four-level symbols; CRC must reject, never accept garbage.
        for packet in decoded:
            self.assertIn(packet, packets)


if __name__ == "__main__":
    unittest.main()
