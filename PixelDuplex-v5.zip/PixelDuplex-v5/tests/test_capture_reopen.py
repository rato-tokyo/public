"""Offline checks for capture-handle recovery without touching physical devices."""

from __future__ import annotations

import unittest
from unittest import mock

from src.hardware import HdmiFrameIO


class FakeCapture:
    def __init__(self, opened=True):
        self.opened = opened
        self.releases = 0

    def isOpened(self):
        return self.opened

    def release(self):
        self.releases += 1


class CaptureReopenTests(unittest.TestCase):
    def test_replaces_failed_handle(self):
        io = HdmiFrameIO(3)
        old = FakeCapture()
        replacement = FakeCapture()
        io._capture = old
        with mock.patch("src.hardware.open_capture", return_value=replacement) as opener:
            io._reopen_capture()
        opener.assert_called_once_with(3)
        self.assertEqual(old.releases, 1)
        self.assertIs(io._capture, replacement)

    def test_failed_open_releases_candidate_and_retries_later(self):
        io = HdmiFrameIO(3)
        old = FakeCapture()
        rejected = FakeCapture(opened=False)
        io._capture = old
        with mock.patch("src.hardware.open_capture", return_value=rejected):
            io._reopen_capture()
        self.assertEqual(old.releases, 1)
        self.assertEqual(rejected.releases, 1)
        self.assertIsNone(io._capture)

    def test_stop_prevents_opening_new_handle(self):
        io = HdmiFrameIO(3)
        old = FakeCapture()
        io._capture = old
        io._stop.set()
        with mock.patch("src.hardware.open_capture") as opener:
            io._reopen_capture()
        opener.assert_not_called()
        self.assertEqual(old.releases, 1)
        self.assertIsNone(io._capture)

    def test_open_exception_leaves_worker_ready_to_retry(self):
        io = HdmiFrameIO(3)
        old = FakeCapture()
        io._capture = old
        with mock.patch("src.hardware.open_capture", side_effect=OSError("unplugged")):
            io._reopen_capture()
        self.assertEqual(old.releases, 1)
        self.assertIsNone(io._capture)
        replacement = FakeCapture()
        with mock.patch("src.hardware.open_capture", return_value=replacement):
            io._reopen_capture()
        self.assertIs(io._capture, replacement)

    def test_read_exception_does_not_kill_worker(self):
        io = HdmiFrameIO(3)

        class FailingThenStopped:
            def __init__(self):
                self.calls = 0

            def read(self):
                self.calls += 1
                if self.calls == 1:
                    raise OSError("disconnected")
                io._stop.set()
                return False, None

        capture = FailingThenStopped()
        io._capture = capture
        with mock.patch.object(io._stop, "wait", return_value=False):
            io._capture_loop()
        self.assertEqual(capture.calls, 2)


if __name__ == "__main__":
    unittest.main()
