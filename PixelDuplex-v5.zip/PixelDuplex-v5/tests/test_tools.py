from __future__ import annotations

import json
import io
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest import mock
from contextlib import nullcontext, redirect_stderr, redirect_stdout

import cv2
import numpy as np

from tools import capture_probe, preflight, status_snapshot


def run_with_cp932_stdout(callable_):
    """Return bytes written through a representative legacy Windows stdout."""
    buffer = io.BytesIO()
    stream = io.TextIOWrapper(buffer, encoding="cp932", newline="\n")
    with mock.patch.object(sys, "stdout", stream):
        result = callable_()
        stream.flush()
    return result, buffer.getvalue()


class PreflightTests(unittest.TestCase):
    def test_json_output_is_ascii_and_valid_utf8_under_cp932_stdout(self):
        report = {"overall_status": preflight.PASS, "device": "日本語カメラ"}
        with mock.patch.object(sys, "argv", ["preflight.py", "--json"]), mock.patch.object(
            preflight, "collect", return_value=report
        ):
            code, output = run_with_cp932_stdout(preflight.main)

        self.assertEqual(code, 0)
        self.assertTrue(output.isascii())
        self.assertEqual(json.loads(output.decode("utf-8")), report)

    def test_pnp_query_forces_powershell_utf8_output(self):
        completed = mock.Mock(
            returncode=0,
            stdout='[{"Class":"Camera","FriendlyName":"日本語カメラ",'
                   '"InstanceId":"USB\\\\VID_0000","Status":"OK"}]',
            stderr="",
        )
        with mock.patch.object(preflight.os, "name", "nt"), mock.patch.object(
            preflight.subprocess, "run", return_value=completed
        ) as run:
            report = preflight.check_pnp_cameras(1)

        self.assertEqual(report["status"], preflight.PASS)
        command = run.call_args.args[0][-1]
        self.assertIn("[Console]::OutputEncoding=$utf8", command)
        self.assertIn("$OutputEncoding=$utf8", command)
        self.assertEqual(run.call_args.kwargs["encoding"], "utf-8")
        self.assertEqual(
            report["details"]["devices"][0]["friendly_name"], "日本語カメラ"
        )

    def test_key_check_never_discloses_value_or_length(self):
        secret = "unique-secret-value-that-must-not-leak"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "key.txt").write_text(secret + "\n", encoding="utf-8")
            with mock.patch.object(preflight, "ROOT", root):
                report = preflight.check_key()

        encoded = json.dumps(report, ensure_ascii=False)
        self.assertEqual(report["status"], preflight.PASS)
        self.assertNotIn(secret, encoded)
        self.assertNotIn(str(len(secret)), encoded)
        self.assertEqual(report["details"], {"readable": True})

    def test_report_includes_protocol_version_and_preferred_profile(self):
        from src.constants import PROTOCOL_VERSION

        secret = "preflight-secret-that-must-not-leak"
        settings = mock.Mock(
            role="receiver", capture_device=1, monitor_device=None,
            scan_interval_seconds=5, file_stable_seconds=10,
            handshake_timeout_seconds=300, frame_interval_seconds=0.125,
            retransmit_seconds=2.0, window_size=64, preferred_profile="baseline",
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "key.txt").write_text(secret, encoding="utf-8")
            with mock.patch.object(preflight, "ROOT", root), mock.patch(
                "src.app.load_settings", return_value=settings
            ), mock.patch.object(
                preflight, "check_opencv", return_value=preflight.result("opencv", preflight.PASS, "ok")
            ), mock.patch.object(
                preflight, "check_monitors", return_value=preflight.result("monitors", preflight.PASS, "ok")
            ), mock.patch.object(
                preflight, "check_pnp_cameras", return_value=preflight.result("camera_pnp", preflight.PASS, "ok")
            ):
                report = preflight.collect()
                human = io.StringIO()
                with redirect_stdout(human):
                    preflight.print_human(report)

        self.assertEqual(report["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(report["preferred_profile"], "baseline")
        self.assertEqual(report["checks"][0]["details"]["settings"]["preferred_profile"], "baseline")
        self.assertIn(f"Protocol version: {PROTOCOL_VERSION}", human.getvalue())
        self.assertIn("preferred_profile: baseline", human.getvalue())
        encoded = json.dumps(report) + human.getvalue()
        self.assertNotIn(secret, encoded)
        self.assertNotIn(str(len(secret)), encoded)

    def test_omitted_preferred_profile_defaults_to_baseline(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            template = Path(preflight.__file__).resolve().parents[1] / "config.receiver.json"
            config = json.loads(template.read_text(encoding="utf-8"))
            config.pop("preferred_profile", None)
            (root / "config.json").write_text(json.dumps(config), encoding="utf-8")
            with mock.patch.object(preflight, "ROOT", root):
                check, settings = preflight.check_config()
        self.assertIsNotNone(settings)
        self.assertEqual(check["details"]["settings"]["preferred_profile"], "baseline")

    def test_empty_key_reports_failure_without_metadata(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "key.txt").write_text("\r\n", encoding="utf-8")
            with mock.patch.object(preflight, "ROOT", root):
                report = preflight.check_key()
        self.assertEqual(report["status"], preflight.FAIL)
        self.assertNotIn("details", report)


class StatusSnapshotTests(unittest.TestCase):
    def test_json_output_is_ascii_and_valid_utf8_under_cp932_stdout(self):
        snapshot = {"health": "healthy", "exit_code": 0, "finding": "認証成功"}
        with mock.patch.object(status_snapshot, "collect", return_value=(snapshot, 0)):
            code, output = run_with_cp932_stdout(
                lambda: status_snapshot.main(["--json"])
            )

        self.assertEqual(code, 0)
        self.assertTrue(output.isascii())
        self.assertEqual(json.loads(output.decode("utf-8")), snapshot)

    def _make_tree(self, root: Path) -> tuple[Path, Path]:
        reports = root / "artifacts" / "reports"
        logs = root / "artifacts" / "logs"
        reports.mkdir(parents=True)
        logs.mkdir(parents=True)
        return reports, logs

    def test_fresh_ready_status_with_live_pid_is_healthy(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY",
                "connected": True,
                "role": "receiver",
                "mode": "run",
                "authentication_failures": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "receiver-run.pid").write_text("1234", encoding="utf-8")
            with mock.patch.object(
                status_snapshot, "windows_process_alive", return_value=True
            ), mock.patch.object(
                status_snapshot, "windows_process_is_pixelduplex", return_value=True
            ):
                report, code = status_snapshot.collect(root, stale_seconds=30, line_limit=5)
        self.assertEqual(code, status_snapshot.EXIT_HEALTHY)
        self.assertEqual(report["health"], "healthy")

    def test_unrelated_stale_pid_does_not_fail_current_run(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY", "connected": True, "role": "receiver",
                "mode": "run", "authentication_failures": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "receiver-run.pid").write_text("1234", encoding="utf-8")
            (logs / "sender-run.pid").write_text("5678", encoding="utf-8")
            (logs / "self-test.pid").write_text("not-a-pid", encoding="utf-8")
            with mock.patch.object(
                status_snapshot, "windows_process_alive", side_effect=lambda pid: pid == 1234
            ), mock.patch.object(
                status_snapshot, "windows_process_is_pixelduplex", return_value=True
            ):
                report, code = status_snapshot.collect(root, stale_seconds=30, line_limit=5)
        self.assertEqual(code, status_snapshot.EXIT_HEALTHY)
        self.assertEqual([item["file"] for item in report["processes"]], ["receiver-run.pid"])

    def test_current_self_test_pid_is_selected_without_run_pid(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY", "connected": True, "role": "receiver",
                "mode": "self-test", "authentication_failures": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "self-test.pid").write_text("1234", encoding="utf-8")
            (logs / "receiver-run.pid").write_text("5678", encoding="utf-8")
            with mock.patch.object(
                status_snapshot, "windows_process_alive", side_effect=lambda pid: pid == 1234
            ), mock.patch.object(
                status_snapshot, "windows_process_is_pixelduplex", return_value=True
            ):
                report, code = status_snapshot.collect(root, stale_seconds=30, line_limit=5)
        self.assertEqual(code, status_snapshot.EXIT_HEALTHY)
        self.assertEqual([item["file"] for item in report["processes"]], ["self-test.pid"])

    def test_current_file_test_pid_is_selected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY", "connected": True, "role": "receiver",
                "mode": "file-test", "authentication_failures": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "file-test.pid").write_text("1234", encoding="utf-8")
            with mock.patch.object(
                status_snapshot, "windows_process_alive", return_value=True
            ), mock.patch.object(
                status_snapshot, "windows_process_is_pixelduplex", return_value=True
            ):
                report, code = status_snapshot.collect(root, stale_seconds=30, line_limit=5)
        self.assertEqual(code, status_snapshot.EXIT_HEALTHY)
        self.assertEqual([item["file"] for item in report["processes"]], ["file-test.pid"])

    def test_completed_file_test_is_not_mistaken_for_dead_run(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "SUCCESS", "connected": False, "role": "receiver",
                "mode": "file-test", "authentication_failures": 0,
                "updated_at": "2020-01-01T00:00:00+00:00",
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "file-test.pid").write_text("1234", encoding="utf-8")
            with mock.patch.object(status_snapshot, "windows_process_alive") as alive:
                report, code = status_snapshot.collect(root, stale_seconds=1, line_limit=5)
            alive.assert_not_called()
        self.assertEqual(code, status_snapshot.EXIT_HEALTHY)
        self.assertEqual(report["runtime_state"], "completed")
        self.assertEqual(report["processes"], [])
        self.assertEqual(report["status"]["status"], "SUCCESS")

    def test_stale_run_still_requires_attention(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY", "connected": True, "role": "receiver",
                "mode": "run", "authentication_failures": 0,
                "updated_at": "2020-01-01T00:00:00+00:00",
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "receiver-run.pid").write_text("1234", encoding="utf-8")
            with mock.patch.object(status_snapshot, "windows_process_alive", return_value=True), \
                    mock.patch.object(status_snapshot, "windows_process_is_pixelduplex", return_value=True):
                report, code = status_snapshot.collect(root, stale_seconds=1, line_limit=5)
        self.assertEqual(code, status_snapshot.EXIT_ATTENTION)
        self.assertEqual(report["runtime_state"], "running_or_unknown")
        self.assertTrue(any("status is stale" in item for item in report["findings"]))

    def test_missing_and_stale_status_are_attention(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            report, code = status_snapshot.collect(root, stale_seconds=1, line_limit=5)
            self.assertEqual(code, status_snapshot.EXIT_ATTENTION)
            self.assertIn("status.json is missing", report["findings"])

            old = {
                "status": "READY", "connected": True, "authentication_failures": 0,
                "updated_at": "2000-01-01T00:00:00+00:00",
            }
            (reports / "status.json").write_text(json.dumps(old), encoding="utf-8")
            (logs / "run.pid").write_text("12", encoding="utf-8")
            with mock.patch.object(status_snapshot, "windows_process_alive", return_value=True):
                report, code = status_snapshot.collect(root, stale_seconds=1, line_limit=5)
            self.assertEqual(code, status_snapshot.EXIT_ATTENTION)
            self.assertTrue(any("status is stale" in item for item in report["findings"]))

    def test_log_tail_is_line_and_byte_bounded_and_redacted(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "large.log"
            prefix = b"discarded\n" * 20000
            path.write_bytes(prefix + b"one\npassword=do-not-leak\nthree\nfour\n")
            lines = status_snapshot.tail_lines(path, 3)
        self.assertEqual(lines, ["password=<redacted>", "three", "four"])
        self.assertNotIn("do-not-leak", "\n".join(lines))

    def test_redact_covers_quoted_assignments_and_json_secret_fields(self):
        samples = [
            ('password="sekrit"', 'password="<redacted>"'),
            ("password='sekrit'", "password='<redacted>'"),
        ]
        for source, expected in samples:
            with self.subTest(source=source):
                redacted = status_snapshot.redact(source)
                self.assertEqual(redacted, expected)
                self.assertNotIn("sekrit", redacted)

        source = json.dumps({
            "event": "diagnostic",
            "token": "token-value",
            "api_key": "api-value",
            "private_key": "private-value",
            "nested": {"password": "password-value", "safe": "visible"},
        })
        redacted = status_snapshot.redact(source)
        parsed = json.loads(redacted)
        self.assertEqual(parsed["token"], "<redacted>")
        self.assertEqual(parsed["api_key"], "<redacted>")
        self.assertEqual(parsed["private_key"], "<redacted>")
        self.assertEqual(parsed["nested"]["password"], "<redacted>")
        self.assertEqual(parsed["nested"]["safe"], "visible")
        for secret in ("token-value", "api-value", "private-value", "password-value"):
            self.assertNotIn(secret, redacted)

    def test_secret_field_names_are_consistent_across_formats(self):
        for name in ("password", "passphrase", "derived_key", "secret", "token",
                     "api_key", "private_key"):
            with self.subTest(name=name):
                self.assertEqual(
                    status_snapshot.redact(f"{name}=sensitive"),
                    f"{name}=<redacted>",
                )
                self.assertEqual(
                    status_snapshot.redact_object({name: "sensitive"})[name],
                    "<redacted>",
                )

    def test_future_status_requires_attention(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            future = datetime.now(timezone.utc) + timedelta(minutes=5)
            status = {
                "status": "READY", "connected": True, "authentication_failures": 0,
                "updated_at": future.isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "run.pid").write_text("1234", encoding="utf-8")
            with mock.patch.object(status_snapshot, "windows_process_alive", return_value=True):
                report, code = status_snapshot.collect(root, stale_seconds=30, line_limit=5)
        self.assertEqual(code, status_snapshot.EXIT_ATTENTION)
        self.assertTrue(any("in the future" in item for item in report["findings"]))

    def test_log_text_is_opt_in_and_redacted_when_included(self):
        secret = "do-not-expose-this-token"
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY", "connected": True, "authentication_failures": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "run.pid").write_text("1234", encoding="utf-8")
            (logs / "run.log").write_text(
                f"ordinary line\nerror token={secret}\n", encoding="utf-8"
            )
            with mock.patch.object(status_snapshot, "windows_process_alive", return_value=True):
                default, _ = status_snapshot.collect(root, 30, 10)
                included, _ = status_snapshot.collect(
                    root, 30, 10, include_log_tails=True
                )

        default_json = json.dumps(default, ensure_ascii=False)
        included_json = json.dumps(included, ensure_ascii=False)
        self.assertNotIn("logs", default)
        self.assertNotIn("error_like_log_lines", default)
        self.assertNotIn("ordinary line", default_json)
        self.assertIn("logs", included)
        self.assertIn("error_like_log_lines", included)
        self.assertIn("ordinary line", included_json)
        self.assertNotIn(secret, included_json)
        self.assertIn("token=<redacted>", included_json)

    def test_authentication_and_transfer_diagnostics_are_immediately_available(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            now = datetime.now(timezone.utc).isoformat()
            status = {
                "status": "READY", "connected": True,
                "handshake_state": "CONNECTED", "authentication_failures": 0,
                "active_transfer": "folder/example.bin",
                "active_transfer_direction": "receiving", "updated_at": now,
            }
            last_transfer = {
                "status": "SUCCESS", "relative_path": "previous.bin",
                "reason": "SHA-256 verified", "completed_at": now,
                "token": "must-not-leak",
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (reports / "last_transfer.json").write_text(
                json.dumps(last_transfer), encoding="utf-8"
            )
            (logs / "run.pid").write_text("1234", encoding="utf-8")
            with mock.patch.object(status_snapshot, "windows_process_alive", return_value=True):
                report, code = status_snapshot.collect(root, 30, 5)

        self.assertEqual(code, status_snapshot.EXIT_HEALTHY)
        diagnostics = report["diagnostics"]
        self.assertEqual(diagnostics["authentication_failures"], 0)
        self.assertTrue(diagnostics["connected"])
        self.assertEqual(diagnostics["handshake_state"], "CONNECTED")
        self.assertEqual(diagnostics["active_transfer"], "folder/example.bin")
        self.assertEqual(diagnostics["active_transfer_direction"], "receiving")
        self.assertEqual(diagnostics["last_transfer"]["status"], "SUCCESS")
        self.assertEqual(diagnostics["last_transfer"]["token"], "<redacted>")
        self.assertNotIn("must-not-leak", json.dumps(report))

    def test_invalid_last_transfer_is_attention_without_hiding_live_status(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY", "connected": True,
                "authentication_failures": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (reports / "last_transfer.json").write_text("[]", encoding="utf-8")
            (logs / "run.pid").write_text("1234", encoding="utf-8")
            with mock.patch.object(status_snapshot, "windows_process_alive", return_value=True):
                report, code = status_snapshot.collect(root, 30, 5)

        self.assertEqual(code, status_snapshot.EXIT_ATTENTION)
        self.assertIsNone(report["diagnostics"]["last_transfer"])
        self.assertTrue(any("last_transfer.json" in item for item in report["findings"]))

    def test_current_profile_test_pid_matches_app_runtime_pid(self):
        from src.app import runtime_pid

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY", "connected": True, "role": "receiver",
                "mode": "profile-test", "authentication_failures": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            with runtime_pid(root, "receiver", "profile-test"):
                created = [path.name for path in logs.glob("*.pid")]
                with mock.patch.object(
                    status_snapshot, "windows_process_alive", return_value=True
                ), mock.patch.object(
                    status_snapshot, "windows_process_is_pixelduplex", return_value=True
                ):
                    report, code = status_snapshot.collect(root, stale_seconds=30, line_limit=5)
        self.assertEqual(code, status_snapshot.EXIT_HEALTHY)
        self.assertEqual([item["file"] for item in report["processes"]], created)

    def _write_completed_profile_test(self, root: Path, report_status: str | None) -> tuple[dict, int]:
        reports, logs = self._make_tree(root)
        status = {
            "status": "SUCCESS", "connected": False, "role": "receiver",
            "mode": "profile-test", "authentication_failures": 0,
            "updated_at": "2020-01-01T00:00:00+00:00",
        }
        (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
        if report_status is not None:
            (reports / "profile_test.json").write_text(json.dumps({
                "status": report_status, "active_profile": "mono-band4",
                "round_trip_goodput_bytes_per_second": 1234.5,
            }), encoding="utf-8")
        (logs / "profile-test.pid").write_text("1234", encoding="utf-8")
        with mock.patch.object(status_snapshot, "windows_process_alive") as alive:
            result = status_snapshot.collect(root, stale_seconds=1, line_limit=5)
        alive.assert_not_called()
        return result

    def test_completed_profile_test_is_healthy_and_reports_result(self):
        with tempfile.TemporaryDirectory() as directory:
            report, code = self._write_completed_profile_test(Path(directory), "SUCCESS")
        self.assertEqual(code, status_snapshot.EXIT_HEALTHY)
        self.assertEqual(report["runtime_state"], "completed")
        self.assertEqual(report["processes"], [])
        self.assertEqual(report["diagnostics"]["profile_test"]["active_profile"], "mono-band4")

    def test_completed_profile_test_without_success_report_needs_attention(self):
        for report_status in (None, "FAILURE"):
            with self.subTest(report_status=report_status), tempfile.TemporaryDirectory() as directory:
                report, code = self._write_completed_profile_test(Path(directory), report_status)
                self.assertEqual(code, status_snapshot.EXIT_ATTENTION)
                self.assertTrue(any("profile_test.json" in item for item in report["findings"]))

    def _collect_with_progress_age(self, age) -> tuple[dict, int]:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            reports, logs = self._make_tree(root)
            status = {
                "status": "READY", "connected": True, "role": "receiver",
                "mode": "run", "authentication_failures": 0,
                "transfer_progress_marker_age_seconds": age,
                "ignored_handshake_errors": 3,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
            (reports / "status.json").write_text(json.dumps(status), encoding="utf-8")
            (logs / "receiver-run.pid").write_text("1234", encoding="utf-8")
            with mock.patch.object(
                status_snapshot, "windows_process_alive", return_value=True
            ), mock.patch.object(
                status_snapshot, "windows_process_is_pixelduplex", return_value=True
            ):
                return status_snapshot.collect(root, stale_seconds=30, line_limit=5)

    def test_progress_marker_age_and_ignored_handshake_errors_are_reported(self):
        for age, expected in ((None, status_snapshot.EXIT_HEALTHY),
                              (59.9, status_snapshot.EXIT_HEALTHY),
                              (60.0, status_snapshot.EXIT_ATTENTION)):
            with self.subTest(age=age):
                report, code = self._collect_with_progress_age(age)
                self.assertEqual(code, expected)
                diagnostics = report["diagnostics"]
                self.assertEqual(diagnostics["transfer_progress_marker_age_seconds"], age)
                self.assertEqual(diagnostics["ignored_handshake_errors"], 3)
                stalled = any("transfer progress has not changed" in item
                              for item in report["findings"])
                self.assertEqual(stalled, expected == status_snapshot.EXIT_ATTENTION)


class _FakeCapture:
    def __init__(self, frames: list[np.ndarray]):
        self.frames = list(frames)
        self.released = False

    def isOpened(self):
        return True

    def read(self):
        return (True, self.frames.pop(0)) if self.frames else (False, None)

    def get(self, prop):
        return {
            cv2.CAP_PROP_FOURCC: cv2.VideoWriter_fourcc(*"YUY2"),
            cv2.CAP_PROP_FRAME_WIDTH: 1920,
            cv2.CAP_PROP_FRAME_HEIGHT: 1080,
            cv2.CAP_PROP_FPS: 30,
        }.get(prop, 0)

    def release(self):
        self.released = True


class CaptureProbeTests(unittest.TestCase):
    def test_json_output_is_ascii_and_valid_utf8_under_cp932_stdout(self):
        args = mock.Mock(
            device=1, frames=1, timeout=1.0, warmup_seconds=0.0,
            json=True, save_frame=False, force=True,
        )
        report = {"status": "SUCCESS", "device": 1, "message": "復号成功"}
        with mock.patch.object(capture_probe, "parse_args", return_value=args), mock.patch.object(
            capture_probe, "probe", return_value=report
        ):
            code, output = run_with_cp932_stdout(capture_probe.main)

        self.assertEqual(code, capture_probe.EXIT_SUCCESS)
        self.assertTrue(output.isascii())
        self.assertEqual(json.loads(output.decode("utf-8")), report)

    def test_worker_timeout_becomes_bounded_operational_failure(self):
        settings = mock.Mock(capture_device=3)
        timeout = subprocess.TimeoutExpired(["python", "capture_probe.py"], 6.0)
        with mock.patch.object(
            sys, "argv", ["capture_probe.py", "--json", "--timeout", "1", "--warmup-seconds", "0"]
        ), mock.patch.object(
            capture_probe, "load_settings", return_value=settings
        ), mock.patch.object(
            capture_probe.subprocess, "run", side_effect=timeout
        ), mock.patch.object(
            capture_probe, "InstanceLock", return_value=nullcontext()
        ), redirect_stdout(io.StringIO()) as stdout:
            code = capture_probe.main()

        self.assertEqual(code, capture_probe.EXIT_OPERATIONAL_FAILURE)
        report = json.loads(stdout.getvalue())
        self.assertEqual(report["status"], "FAILURE")
        self.assertIn("hard deadline", report["error"])

    def test_argument_boundaries_reject_invalid_values(self):
        invalid = [
            ["capture_probe.py", "--frames", "0"],
            ["capture_probe.py", "--frames", "91"],
            ["capture_probe.py", "--timeout", "0"],
            ["capture_probe.py", "--warmup-seconds", "-0.1"],
        ]
        for argv in invalid:
            with self.subTest(argv=argv), mock.patch.object(sys, "argv", argv):
                with self.assertRaises(SystemExit) as raised:
                    capture_probe.parse_args()
                self.assertEqual(raised.exception.code, 2)

    def test_argument_boundaries_accept_limits(self):
        for value in (1, 90):
            with self.subTest(frames=value), mock.patch.object(
                sys, "argv", ["capture_probe.py", "--frames", str(value), "--timeout", "0.1"]
            ):
                self.assertEqual(capture_probe.parse_args().frames, value)

        with mock.patch.object(
            sys, "argv", ["capture_probe.py", "--warmup-seconds", "0"]
        ):
            self.assertEqual(capture_probe.parse_args().warmup_seconds, 0)

    def test_json_argument_error_emits_json_only(self):
        stdout = io.StringIO()
        stderr = io.StringIO()
        with mock.patch.object(
            sys, "argv", ["capture_probe.py", "--json", "--frames", "0"]
        ), redirect_stdout(stdout), redirect_stderr(stderr):
            with self.assertRaises(SystemExit) as raised:
                capture_probe.parse_args()

        self.assertEqual(raised.exception.code, 2)
        self.assertEqual(stderr.getvalue(), "")
        report = json.loads(stdout.getvalue())
        self.assertEqual(report["status"], "FAILURE")
        self.assertEqual(report["error_type"], "ArgumentError")
        self.assertIn("--frames", report["error"])

    def test_negative_config_device_fails_before_opening_capture(self):
        settings = mock.Mock(capture_device=-1)
        with mock.patch.object(
            sys, "argv", ["capture_probe.py", "--json"]
        ), mock.patch.object(
            capture_probe, "load_settings", return_value=settings
        ), mock.patch.object(
            capture_probe, "probe"
        ) as probe_mock, mock.patch.object(
            capture_probe, "InstanceLock"
        ) as lock_mock, redirect_stdout(io.StringIO()) as stdout:
            code = capture_probe.main()

        self.assertEqual(code, capture_probe.EXIT_OPERATIONAL_FAILURE)
        report = json.loads(stdout.getvalue())
        self.assertEqual(report["status"], "FAILURE")
        self.assertEqual(report["device"], -1)
        self.assertIn("capture_device", report["error"])
        probe_mock.assert_not_called()
        lock_mock.assert_not_called()

    def test_probe_aggregates_mock_frames_without_opening_device(self):
        frames = [
            np.zeros((2, 3, 3), dtype=np.uint8),
            np.full((2, 3, 3), 10, dtype=np.uint8),
        ]
        fake = _FakeCapture(frames)
        with mock.patch.object(capture_probe, "open_capture", return_value=fake), mock.patch.object(
            capture_probe, "decode_image", return_value=(None, None)
        ), mock.patch.object(capture_probe, "require_opencv_gui", return_value="WIN32UI"):
            report = capture_probe.probe(7, frame_limit=2, timeout=1, save_frame=False)
        self.assertTrue(fake.released)
        self.assertEqual(report["status"], "SUCCESS")
        self.assertEqual(report["captured_frames"], 2)
        self.assertEqual(report["compared_frame_pairs"], 1)
        self.assertEqual(report["changed_frame_pairs"], 1)
        self.assertEqual(report["pixel_mean"], 5.0)
        self.assertEqual(report["decode_image_successes"], 0)

    def test_warmup_frames_are_discarded_from_measurement_statistics(self):
        warmup = np.full((2, 3, 3), 200, dtype=np.uint8)
        measured = [
            np.zeros((2, 3, 3), dtype=np.uint8),
            np.full((2, 3, 3), 10, dtype=np.uint8),
        ]
        fake = _FakeCapture([warmup, *measured])
        clock = iter([0, 0, 0, 1, 1, 1, 1, 1, 2])
        with mock.patch.object(capture_probe, "open_capture", return_value=fake), mock.patch.object(
            capture_probe, "decode_image", return_value=(None, None)
        ), mock.patch.object(
            capture_probe, "require_opencv_gui", return_value="WIN32UI"
        ), mock.patch.object(capture_probe.time, "monotonic", side_effect=clock):
            report = capture_probe.probe(
                7, frame_limit=2, timeout=5, save_frame=False, warmup_seconds=0.5
            )

        self.assertEqual(report["warmup_frames_discarded"], 1)
        self.assertEqual(report["captured_frames"], 2)
        self.assertEqual(report["pixel_mean"], 5.0)
        self.assertEqual(report["compared_frame_pairs"], 1)
        self.assertEqual(report["changed_frame_pairs"], 1)

    def test_v5_band_frames_are_detected_and_counted_separately(self):
        from src import codec_v5, wire

        packets = [
            wire.PhysicalPacket(4, b"s" * 16, 10 + band, 0, 1, 5, b"band" + bytes([band]))
            for band in range(2)
        ]
        banded = codec_v5.render_frame(codec_v5.MONO, packets)
        blank = np.zeros_like(banded)
        fake = _FakeCapture([banded, blank])
        with mock.patch.object(capture_probe, "open_capture", return_value=fake), mock.patch.object(
            capture_probe, "require_opencv_gui", return_value="WIN32UI"
        ):
            report = capture_probe.probe(7, frame_limit=2, timeout=5, save_frame=False)

        self.assertEqual(report["decode_image_successes"], 0)
        self.assertEqual(report["band_decode_frames"], 1)
        self.assertEqual(report["band_packets_decoded"], 2)
        self.assertTrue(report["protocol_frames_detected"])
        self.assertEqual(report["success_scope"], "protocol_detected")
        self.assertEqual(sum(report["packet_kinds"].values()), 2)
        self.assertEqual(sum(report["active_rects"].values()), 1)


if __name__ == "__main__":
    unittest.main()
