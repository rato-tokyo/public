"""Offline benchmark safety and deterministic codec checks."""

import unittest
from unittest.mock import patch

import numpy as np

from tools.codec_benchmark import FORMATS, benchmark, decode, encode


class CodecBenchmarkTests(unittest.TestCase):
    def test_clean_round_trip_all_formats(self):
        for _, cell, channels, levels in FORMATS:
            with self.subTest(cell=cell, channels=channels, levels=levels):
                rng = np.random.default_rng(3)
                shape = (12 // cell, 24 // cell)
                symbols = rng.integers(0, levels, (*shape, channels), dtype=np.uint8)
                if channels == 1:
                    symbols = symbols[:, :, 0]
                palette = np.rint(np.linspace(0, 255, levels)).astype(np.uint8)
                self.assertTrue(np.array_equal(symbols, decode(encode(palette[symbols], cell, channels), cell, channels, levels)))

    def test_comparison_is_deterministic_except_timings(self):
        with patch("tools.codec_benchmark.WIDTH", 24), patch("tools.codec_benchmark.HEIGHT", 12):
            first = benchmark(scale=0.92, border=1, noise=4, seed=7)
            second = benchmark(scale=0.92, border=1, noise=4, seed=7)
        for a, b in zip(first, second):
            self.assertEqual(a["symbol_errors"], b["symbol_errors"])
            self.assertEqual(a["raw_payload_bytes"], b["raw_payload_bytes"])

    def test_invalid_distortion_rejected(self):
        for options in ({"scale": 0}, {"border": 1080}, {"noise": -1}):
            with self.subTest(options=options), self.assertRaises(ValueError):
                benchmark(**options)


if __name__ == "__main__":
    unittest.main()
