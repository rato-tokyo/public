"""The explicit file-test creates only its unique requested source."""

from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from src.app import Runner
from src.constants import MessageKind
from src.messages import parse_json


class FileTestCommandTests(unittest.TestCase):
    def _runner(self, base: Path) -> Runner:
        runner = Runner.__new__(Runner)
        runner.base = base
        runner.file_test_id = "a" * 32
        runner.file_test_payload = b"diagnostic data"
        runner.file_test_request = {
            "id": runner.file_test_id,
            "path": f"pixelduplex-test/{runner.file_test_id}/forward.bin",
            "return_path": f"pixelduplex-test/{runner.file_test_id}/return.bin",
            "size": len(runner.file_test_payload),
            "sha256": hashlib.sha256(runner.file_test_payload).hexdigest(),
        }
        runner.file_test_created = False
        runner.file_test_started = None
        runner.last_file_test_arm = float("-inf")
        runner.engine = SimpleNamespace(
            file_echo_status=None,
            inbound=SimpleNamespace(transfer=None, completed_message=None),
        )
        runner.ledger = Mock()
        runner.ledger.is_complete.return_value = True
        runner._send_app = Mock()
        runner._status = Mock()
        (base / "artifacts" / "reports").mkdir(parents=True)
        return runner

    def test_request_is_sent_before_source_is_created(self):
        with tempfile.TemporaryDirectory() as directory:
            runner = self._runner(Path(directory))
            request = runner.file_test_request
            self.assertIsNone(runner._file_test_tick(1.0))
            sent = runner._send_app.call_args.args[0]
            self.assertEqual(sent[0][0], MessageKind.FILE_ECHO_ARM)
            self.assertEqual(parse_json(sent[0][1]), request)
            source = runner.base / "target" / request["path"]
            self.assertFalse(source.exists())

            runner.engine.file_echo_status = {"id": request["id"], "status": "ARMED"}
            self.assertIsNone(runner._file_test_tick(2.0))
            self.assertEqual(source.read_bytes(), runner.file_test_payload)
            self.assertTrue(runner.file_test_created)

    def test_unrelated_response_cannot_create_source(self):
        with tempfile.TemporaryDirectory() as directory:
            runner = self._runner(Path(directory))
            runner.engine.file_echo_status = {"id": "b" * 32, "status": "ARMED"}
            self.assertIsNone(runner._file_test_tick(1.0))
            self.assertFalse((runner.base / "target").exists())

    def test_verified_return_writes_success_report(self):
        with tempfile.TemporaryDirectory() as directory:
            runner = self._runner(Path(directory))
            request = runner.file_test_request
            runner.engine.file_echo_status = {"id": request["id"], "status": "ARMED"}
            self.assertIsNone(runner._file_test_tick(1.0))
            returned = runner.base / "received" / request["return_path"]
            returned.parent.mkdir(parents=True)
            returned.write_bytes(runner.file_test_payload)
            runner.engine.inbound.transfer = object()
            runner.engine.inbound.completed_message = object()
            self.assertIsNone(runner._file_test_tick(1.5))
            runner.engine.inbound.transfer = None
            runner.engine.inbound.completed_message = None
            with patch("builtins.print"):
                self.assertEqual(runner._file_test_tick(2.0), 0)
            report = json.loads((runner.base / "artifacts" / "reports" / "file_test.json").read_text())
            self.assertEqual(report["status"], "SUCCESS")
            self.assertTrue(report["sha256_verified"])
            self.assertEqual(report["round_trip_seconds"], 1.0)


if __name__ == "__main__":
    unittest.main()
