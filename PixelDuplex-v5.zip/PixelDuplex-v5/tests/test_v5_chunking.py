"""Profile-dependent file chunks without touching the physical device."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from src.constants import MessageKind
from src.diagnostic import DiagnosticSession
from src.ledger import Ledger
from src.messages import decode_data, encode_ack, encode_data, json_bytes, parse_json
from src.sync import SenderEngine


class ProfileChunkTests(unittest.TestCase):
    def test_diagnostic_uses_large_candidate_chunks(self):
        diagnostic = DiagnosticSession(
            "receiver", window_size=8, retransmit_seconds=1.0, chunk_bytes=120_000,
        )
        metadata = diagnostic.start(b"x" * 180_000, 0.0)
        details = parse_json(metadata[0][1])
        self.assertEqual((details["chunk_count"], details["chunk_bytes"]), (2, 120_000))
        diagnostic.handle(
            MessageKind.BLOB_ACK,
            encode_ack(bytes.fromhex(details["transfer_id"]), 0, 0), 0.1,
        )
        chunks = [decode_data(payload)[2] for kind, payload in diagnostic.tick(0.2)
                  if kind == MessageKind.BLOB_DATA]
        self.assertEqual([len(chunk) for chunk in chunks], [120_000, 60_000])

    def test_diagnostic_records_receive_side_goodput_without_first_chunk(self):
        origin = DiagnosticSession(
            "receiver", window_size=8, retransmit_seconds=1.0, chunk_bytes=120_000,
        )
        metadata = origin.start(b"x" * 180_000, 0.0)[0][1]
        transfer_id = bytes.fromhex(parse_json(metadata)["transfer_id"])
        peer = DiagnosticSession("sender", window_size=8, retransmit_seconds=1.0)
        peer.handle(MessageKind.BLOB_META, metadata, 0.1)
        peer.handle(MessageKind.BLOB_DATA, encode_data(transfer_id, 0, b"x" * 120_000), 1.0)
        completion = peer.handle(
            MessageKind.BLOB_DATA, encode_data(transfer_id, 1, b"x" * 60_000), 3.0,
        )
        result = peer.direction_metrics["outbound"]
        self.assertEqual(result["goodput_measured_bytes"], 60_000)
        self.assertEqual(result["transfer_seconds"], 2.0)
        self.assertEqual(result["goodput_bytes_per_second"], 30_000.0)
        complete_value = parse_json(next(payload for kind, payload in completion
                                         if kind == MessageKind.BLOB_COMPLETE))
        self.assertEqual(complete_value["goodput_bytes_per_second"], 30_000.0)

    def test_large_chunks_and_idle_only_change(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            target = root / "target"
            target.mkdir()
            content = b"x" * 130_000
            (target / "sample.bin").write_bytes(content)
            ledger = Ledger(root / "ledger.json", "sender")
            sender = SenderEngine(
                target, ledger.scope("outgoing"), chunk_bytes=120_000,
                scan_interval=0.1, stable_seconds=0.1,
            )
            try:
                sender.tick(0.0)
                sender.tick(1.0)
                messages = sender.handle(
                    MessageKind.FILE_REQUEST, json_bytes({"path": "sample.bin"}), 1.1,
                )
                self.assertEqual(parse_json(messages[0][1])["chunk_bytes"], 120_000)
                with self.assertRaises(RuntimeError):
                    sender.set_chunk_bytes(60_000)
                data = [decode_data(payload) for kind, payload in sender.tick(1.2)
                        if kind == MessageKind.FILE_DATA]
                self.assertEqual([len(chunk) for _, _, chunk in data], [120_000, 10_000])
                self.assertEqual(b"".join(chunk for _, _, chunk in data), content)
            finally:
                sender.close()
            sender.set_chunk_bytes(60_000)
            self.assertEqual(sender.chunk_bytes, 60_000)


if __name__ == "__main__":
    unittest.main()
