from __future__ import annotations

import json
import hashlib
import tempfile
import unittest
from pathlib import Path

from src.constants import MessageKind
from src.ledger import Ledger
from src.messages import encode_data, json_bytes, parse_json
from src.sync import ReceiverEngine, SenderEngine, interval_metrics


class OutgoingTransferReportTests(unittest.TestCase):
    def test_incoming_report_uses_transfer_interval_metrics(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            counters = {
                "unique_physical_frames": 10,
                "duplicate_physical_frames": 0,
                "discarded_physical_frames": 0,
                "authentication_failures": 0,
            }
            receiver = ReceiverEngine(
                root / "received", Ledger(root / "ledger.json", "receiver").scope("incoming"),
                report_path=root / "last_transfer.json",
                metrics_provider=lambda: counters.copy(),
            )
            data = b"payload"
            digest = hashlib.sha256(data).hexdigest()
            receiver.handle(MessageKind.MANIFEST, json_bytes([
                {"path": "sample.bin", "size": len(data), "sha256": digest, "sendable": True},
            ]), 1.0)
            transfer_id = bytes.fromhex("11" * 16)
            receiver.handle(MessageKind.FILE_META, json_bytes({
                "transfer_id": transfer_id.hex(), "path": "sample.bin", "size": len(data),
                "sha256": digest, "chunk_count": 1, "chunk_bytes": 1024,
            }), 2.0)
            counters["unique_physical_frames"] = 12
            counters["duplicate_physical_frames"] = 4
            receiver.handle(MessageKind.FILE_DATA, encode_data(transfer_id, 0, data), 3.0)
            report = json.loads((root / "last_transfer.json").read_text(encoding="utf-8"))
            self.assertEqual(report["status"], "SUCCESS")
            self.assertEqual(report["unique_physical_frames"], 2)
            self.assertEqual(report["duplicate_physical_frames"], 4)
            self.assertEqual(report["unique_chunks"], 1)
            self.assertIsNone(report["missing_chunks"])
            receiver.close()

    def test_interval_metrics_are_link_wide_deltas(self):
        start = {
            "unique_physical_frames": 10,
            "duplicate_physical_frames": 20,
            "discarded_physical_frames": 30,
            "authentication_failures": 1,
        }
        end = {
            "unique_physical_frames": 13,
            "duplicate_physical_frames": 25,
            "discarded_physical_frames": 32,
            "authentication_failures": 2,
        }
        result = interval_metrics(start, lambda: end)
        self.assertEqual(result["unique_physical_frames"], 3)
        self.assertEqual(result["duplicate_physical_frames"], 5)
        self.assertEqual(result["discarded_physical_frames"], 2)
        self.assertEqual(result["authentication_failures"], 1)
        self.assertIn("includes control traffic", result["physical_metric_scope"])

    def test_receiver_completion_ack_writes_outgoing_last_transfer(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "target"
            target.mkdir()
            (target / "sample.bin").write_bytes(b"payload")
            report_path = root / "last_transfer.json"
            counters = {
                "unique_physical_frames": 10,
                "duplicate_physical_frames": 0,
                "discarded_physical_frames": 0,
                "authentication_failures": 0,
            }
            sender = SenderEngine(
                target, Ledger(root / "ledger.json", "sender").scope("outgoing"),
                scan_interval=0.1, stable_seconds=0.1,
                report_path=report_path,
                metrics_provider=lambda: counters.copy(),
            )
            try:
                sender.tick(0.0)
                sender.tick(1.0)
                metadata = sender.handle(
                    MessageKind.FILE_REQUEST, json_bytes({"path": "sample.bin"}), 1.1
                )
                self.assertEqual(metadata[0][0], MessageKind.FILE_META)
                meta = parse_json(metadata[0][1])
                self.assertIn(MessageKind.FILE_DATA, [kind for kind, _ in sender.tick(1.2)])
                self.assertIsNotNone(sender.transfer)
                sender.transfer.reliable.mark_displayed(0, 1.2)
                # Retransmit after DEFAULT_RETRANSMIT_SECONDS (2.0) from display.
                self.assertIn(MessageKind.FILE_DATA, [kind for kind, _ in sender.tick(3.3)])
                counters["unique_physical_frames"] = 15
                counters["duplicate_physical_frames"] = 7
                counters["discarded_physical_frames"] = 2
                counters["authentication_failures"] = 1
                replies = sender.handle(
                    MessageKind.FILE_COMPLETE,
                    json_bytes({
                        "transfer_id": meta["transfer_id"],
                        "size": meta["size"],
                        "sha256": meta["sha256"],
                        "session_id": "peer-session",
                    }),
                    2.0,
                )
            finally:
                sender.close()

            self.assertEqual(replies[0][0], MessageKind.COMPLETE_CONFIRM)
            report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(report["status"], "SUCCESS")
            self.assertEqual(report["direction"], "outgoing")
            self.assertEqual(report["relative_path"], "sample.bin")
            self.assertTrue(report["sha256_verified"])
            self.assertEqual(report["session_id"], "peer-session")
            self.assertEqual(report["retransmitted_chunks"], 1)
            self.assertEqual(report["unique_physical_frames"], 5)
            self.assertEqual(report["duplicate_physical_frames"], 7)
            self.assertEqual(report["discarded_physical_frames"], 2)
            self.assertEqual(report["authentication_failures"], 1)

    def test_source_change_writes_cancelled_outgoing_last_transfer(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "target"
            target.mkdir()
            source = target / "sample.bin"
            source.write_bytes(b"before")
            report_path = root / "last_transfer.json"
            sender = SenderEngine(
                target, Ledger(root / "ledger.json", "sender").scope("outgoing"),
                scan_interval=0.1, stable_seconds=0.1,
                report_path=report_path,
            )
            try:
                sender.tick(0.0)
                sender.tick(1.0)
                sender.handle(
                    MessageKind.FILE_REQUEST, json_bytes({"path": "sample.bin"}), 1.1
                )
                source.write_bytes(b"changed and now longer")
                sender.tick(2.0)
            finally:
                sender.close()

            report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(report["status"], "CANCELLED")
            self.assertEqual(report["direction"], "outgoing")
            self.assertEqual(report["relative_path"], "sample.bin")
            self.assertFalse(report["sha256_verified"])


if __name__ == "__main__":
    unittest.main()
