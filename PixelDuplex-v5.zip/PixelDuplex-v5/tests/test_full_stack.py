from __future__ import annotations

import os
import json
import tempfile
import unittest
from collections import deque
from pathlib import Path

from src.constants import FILE_CHUNK_BYTES
from src.duplex import DuplexEngine
from src.ledger import Ledger
from src.link import LinkSession
from src.sync import ReceiverEngine, SenderEngine


class FullStackSimulationTests(unittest.TestCase):
    def test_encrypted_duplex_sync_uses_separate_send_and_receive_folders(self):
        a_data, b_data = os.urandom(120_123), os.urandom(90_321)
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            a_base, b_base = base / "a", base / "b"
            (a_base / "target").mkdir(parents=True)
            (b_base / "target").mkdir(parents=True)
            (a_base / "target" / "from-a.bin").write_bytes(a_data)
            (b_base / "target" / "from-b.bin").write_bytes(b_data)
            a_ledger = Ledger(a_base / "ledger.json", "sender")
            b_ledger = Ledger(b_base / "ledger.json", "receiver")
            a = DuplexEngine(
                a_base / "target", a_base / "received", a_ledger, "sender",
                scan_interval=0.1, stable_seconds=0.2, retransmit_seconds=0.3,
            )
            b = DuplexEngine(
                b_base / "target", b_base / "received", b_ledger, "receiver",
                scan_interval=0.1, stable_seconds=0.2, retransmit_seconds=0.3,
            )
            a_link = LinkSession("sender", "duplex password")
            b_link = LinkSession("receiver", "duplex password")
            a2b, b2a = deque(), deque()
            dropped: set[tuple] = set()

            def enqueue(link, queue, messages):
                for kind, payload in messages:
                    queue.extend(link.secure(kind, payload))

            def drain_one(queue, link, engine, reverse, now):
                if not queue:
                    return
                packet = queue.popleft()
                identity = (
                    packet.session_id, packet.message_id, packet.fragment_index,
                )
                if packet.kind == 4 and packet.message_id % 11 == 0 and identity not in dropped:
                    dropped.add(identity)
                    return
                replies, messages = link.receive(packet)
                reverse.extend(replies)
                for kind, payload in messages:
                    enqueue(link, reverse, engine.handle(kind, payload, now))

            try:
                for step in range(5000):
                    now = step * 0.05
                    a2b.extend(a_link.periodic(now))
                    b2a.extend(b_link.periodic(now))
                    if a_link.connected and b_link.connected:
                        enqueue(a_link, a2b, a.tick(now))
                        enqueue(b_link, b2a, b.tick(now))
                    self.assertFalse(
                        a.outbound.transfer is not None and b.outbound.transfer is not None,
                        "the receive token must prevent simultaneous opposite file transfers",
                    )
                    drain_one(a2b, b_link, b, b2a, now)
                    drain_one(b2a, a_link, a, a2b, now)
                    if (
                        (b_base / "received" / "from-a.bin").exists()
                        and (a_base / "received" / "from-b.bin").exists()
                        and a.transfer is None and b.transfer is None
                    ):
                        break
                self.assertEqual(
                    (b_base / "received" / "from-a.bin").read_bytes(), a_data,
                )
                self.assertEqual(
                    (a_base / "received" / "from-b.bin").read_bytes(), b_data,
                )
                self.assertFalse((a_base / "target" / "from-b.bin").exists())
                self.assertFalse((b_base / "target" / "from-a.bin").exists())
                self.assertTrue(a_ledger.is_complete("from-a.bin", "outgoing"))
                self.assertTrue(a_ledger.is_complete("from-b.bin", "incoming"))
                self.assertTrue(b_ledger.is_complete("from-b.bin", "outgoing"))
                self.assertTrue(b_ledger.is_complete("from-a.bin", "incoming"))
                self.assertTrue(dropped)
                self.assertGreater(max(a.token_epoch, b.token_epoch), 0)
            finally:
                a.close()
                b.close()

    def test_encrypted_receiver_driven_sync_over_lossy_physical_packets(self):
        data = os.urandom(180_123)
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            target = base / "sender" / "target"
            received = base / "receiver" / "received"
            target.mkdir(parents=True)
            (target / "file.bin").write_bytes(data)

            sender_link = LinkSession("sender", "shared test password")
            receiver_link = LinkSession("receiver", "shared test password")
            sender = SenderEngine(
                target, Ledger(base / "sender" / "ledger.json", "sender").scope("outgoing"),
                scan_interval=0.25, stable_seconds=0.5, retransmit_seconds=0.5,
            )
            receiver = ReceiverEngine(
                received, Ledger(base / "receiver" / "ledger.json", "receiver").scope("incoming"),
                session_id="simulation",
                report_path=base / "receiver" / "report.json",
            )
            s2r, r2s = deque(), deque()
            dropped: set[tuple] = set()

            def enqueue_app(link, queue, messages):
                for kind, payload in messages:
                    queue.extend(link.secure(kind, payload))

            def deliver_one(queue, destination_link, destination_engine, reverse, now):
                if not queue:
                    return
                packet = queue.popleft()
                identity = (packet.session_id, packet.kind, packet.message_id, packet.fragment_index)
                # Drop a deterministic subset once. Retransmission/repeated
                # control requests must make the protocol converge anyway.
                if packet.kind == 4 and packet.message_id % 7 == 0 and identity not in dropped:
                    dropped.add(identity)
                    return
                link_replies, app_messages = destination_link.receive(packet)
                reverse.extend(link_replies)
                for kind, payload in app_messages:
                    replies = destination_engine.handle(kind, payload, now)
                    enqueue_app(destination_link, reverse, replies)

            try:
                for step in range(3000):
                    now = step * 0.125
                    s2r.extend(sender_link.periodic(now))
                    r2s.extend(receiver_link.periodic(now))
                    if sender_link.connected and receiver_link.connected:
                        enqueue_app(sender_link, s2r, sender.tick(now))
                        enqueue_app(receiver_link, r2s, receiver.tick(now))
                    deliver_one(s2r, receiver_link, receiver, r2s, now)
                    deliver_one(r2s, sender_link, sender, s2r, now)
                    output = received / "file.bin"
                    if output.exists() and sender.transfer is None and receiver.transfer is None:
                        break
                self.assertTrue(sender_link.connected)
                self.assertTrue(receiver_link.connected)
                self.assertTrue(dropped)
                self.assertEqual((received / "file.bin").read_bytes(), data)
                self.assertTrue(sender.ledger.is_complete("file.bin"))
                self.assertTrue(receiver.ledger.is_complete("file.bin"))
                report = json.loads((base / "receiver" / "report.json").read_text(encoding="utf-8"))
                self.assertEqual(report["status"], "SUCCESS")
                self.assertTrue(report["sha256_verified"])
                self.assertEqual(report["goodput_measured_bytes"], len(data) - FILE_CHUNK_BYTES)
            finally:
                sender.close()
                receiver.close()


if __name__ == "__main__":
    unittest.main()
