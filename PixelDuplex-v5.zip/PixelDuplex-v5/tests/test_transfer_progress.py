from __future__ import annotations

import io
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from src.app import console
from src.ledger import Ledger
from src.sync import (
    ReceiverEngine, SenderEngine, TransferProgress, chunk_bytes_done,
)


def run_transfer(base: Path, size: int, chunk_bytes: int, name: str = "data.bin"):
    target, received = base / "target", base / "received"
    target.mkdir()
    received.mkdir()
    (target / name).write_bytes(bytes(range(256)) * (size // 256) + b"x" * (size % 256))
    sent, got = [], []
    sender = SenderEngine(
        target, Ledger(base / "a.json", "sender").scope("outgoing"),
        scan_interval=0.1, stable_seconds=0.1, chunk_bytes=chunk_bytes,
        progress_sink=sent.append,
    )
    receiver = ReceiverEngine(
        received, Ledger(base / "b.json", "receiver").scope("incoming"),
        progress_sink=got.append,
    )
    to_sender = []
    try:
        for step in range(200):
            now = step * 0.5
            to_receiver = sender.tick(now)
            for kind, payload in to_sender:
                to_receiver.extend(sender.handle(kind, payload, now))
            to_sender = receiver.tick(now)
            for kind, payload in to_receiver:
                to_sender.extend(receiver.handle(kind, payload, now))
            if any("DONE" in line for line in sent):
                break
    finally:
        sender.close()
        receiver.close()
    return sent, got


class TransferProgressTests(unittest.TestCase):
    def test_both_directions_report_every_twenty_percent_and_verified_done(self):
        with tempfile.TemporaryDirectory() as directory:
            sent, got = run_transfer(Path(directory), 10_000, 1_000)
        for lines in (sent, got):
            self.assertIn("START size=10.0 KB", lines[0])
            steps = [line.split("PROGRESS ")[1].split("%")[0]
                     for line in lines if "PROGRESS" in line]
            self.assertEqual(steps, ["20", "40", "60", "80", "100"])
            self.assertIn("DONE", lines[-1])
            self.assertTrue(all('path="data.bin"' in line for line in lines))
        self.assertIn("receiver verified size and SHA-256", sent[-1])
        self.assertIn("SHA-256 verified, saved", got[-1])

    def test_single_chunk_file_jumps_to_100_once(self):
        with tempfile.TemporaryDirectory() as directory:
            sent, got = run_transfer(Path(directory), 500, 1_000)
        for lines in (sent, got):
            self.assertEqual(sum("PROGRESS" in line for line in lines), 1)
            self.assertIn("PROGRESS 100%", "".join(lines))

    def test_partial_progress_reports_floor_step_and_average(self):
        lines = []
        progress = TransferProgress(lines.append, "incoming", "a.bin", 1000, 0.0)
        progress.update(450, 5.0)
        self.assertEqual(progress.percent, 45)
        self.assertIn("PROGRESS 40%", lines[-1])
        self.assertIn("average=90 B/s", lines[-1])
        progress.update(590, 6.0)
        self.assertEqual(len(lines), 2)  # still below 60%

    def test_interrupted_transfer_is_not_reported_as_done(self):
        lines = []
        receiver = ReceiverEngine(Path("."), mock.Mock(), progress_sink=lines.append)
        receiver.transfer = mock.Mock(progress=TransferProgress(
            lines.append, "incoming", "a.bin", 1000, 0.0,
        ))
        receiver.transfer.progress.update(450, 5.0)
        receiver.close()
        self.assertIn("INTERRUPTED at 45%; not complete", lines[-1])
        self.assertFalse(any("DONE" in line for line in lines))

    def test_short_last_chunk_counts_exact_bytes(self):
        self.assertEqual(chunk_bytes_done({0, 1}, 3, 100, 250), 200)
        self.assertEqual(chunk_bytes_done({0, 2}, 3, 100, 250), 150)
        self.assertEqual(chunk_bytes_done({0, 1, 2}, 3, 100, 250), 250)

    def test_console_survives_unencodable_path(self):
        raw = io.BytesIO()
        stream = io.TextIOWrapper(raw, encoding="cp932", errors="strict")
        with mock.patch("sys.stdout", stream):
            console('TRANSFER incoming path="\U0001F4C4.bin"')
            stream.flush()
        self.assertIn(b'path="?.bin"', raw.getvalue())


if __name__ == "__main__":
    unittest.main()
