from __future__ import annotations

import hashlib
import json
import os
import tempfile
import unittest
import uuid
from collections import deque
from pathlib import Path

from src.constants import MessageKind
from src.duplex import DuplexEngine
from src.file_loopback import copy_verified_echo, validate_arm
from src.ledger import Ledger
from src.link import LinkSession
from src.messages import json_bytes


class FileLoopbackTests(unittest.TestCase):
    def test_encrypted_file_round_trips_twice_without_reflecting_normal_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            a_root, b_root = root / "a", root / "b"
            (a_root / "target").mkdir(parents=True)
            (b_root / "target").mkdir(parents=True)
            normal = os.urandom(127)
            (b_root / "target" / "normal.bin").write_bytes(normal)
            a_ledger = Ledger(a_root / "ledger.json", "sender")
            b_ledger = Ledger(b_root / "ledger.json", "receiver")
            a = DuplexEngine(a_root / "target", a_root / "received", a_ledger,
                             "sender", scan_interval=0.1, stable_seconds=0.1,
                             retransmit_seconds=0.2)
            b = DuplexEngine(b_root / "target", b_root / "received", b_ledger,
                             "receiver", scan_interval=0.1, stable_seconds=0.1,
                             retransmit_seconds=0.2)
            a_link = LinkSession("sender", "test password")
            b_link = LinkSession("receiver", "test password")
            a2b, b2a = deque(), deque()

            def enqueue(link, queue, messages):
                for kind, payload in messages:
                    queue.extend(link.secure(kind, payload))

            def deliver(queue, link, engine, reverse, now):
                if not queue:
                    return
                replies, messages = link.receive(queue.popleft())
                reverse.extend(replies)
                for kind, payload in messages:
                    enqueue(link, reverse, engine.handle(kind, payload, now))

            requests = []
            for index in range(2):
                data = os.urandom(1024 + index)
                request_id = uuid.uuid4().hex
                request = {
                    "id": request_id,
                    "path": f"pixelduplex-test/{request_id}/forward.bin",
                    "return_path": f"pixelduplex-test/{request_id}/return.bin",
                    "size": len(data),
                    "sha256": hashlib.sha256(data).hexdigest(),
                }
                source = b_root / "target" / request["path"]
                source.parent.mkdir(parents=True, exist_ok=True)
                source.write_bytes(data)
                requests.append((request, data))

            try:
                armed = set()
                completed = set()
                for step in range(12000):
                    now = step * 0.05
                    a2b.extend(a_link.periodic(now))
                    b2a.extend(b_link.periodic(now))
                    if a_link.connected and b_link.connected:
                        for request, _ in requests:
                            request_id = request["id"]
                            if request_id not in armed and (not armed or len(completed) == len(armed)):
                                enqueue(b_link, b2a, [(MessageKind.FILE_ECHO_ARM, json_bytes(request))])
                                armed.add(request_id)
                                break
                        enqueue(a_link, a2b, a.tick(now))
                        enqueue(b_link, b2a, b.tick(now))
                    deliver(a2b, b_link, b, b2a, now)
                    deliver(b2a, a_link, a, a2b, now)
                    for request, data in requests:
                        returned = b_root / "received" / request["return_path"]
                        if returned.exists() and returned.read_bytes() == data:
                            completed.add(request["id"])
                    if (len(completed) == 2
                            and (a_root / "received" / "normal.bin").exists()
                            and all(a_ledger.is_complete(request["return_path"], "outgoing")
                                    for request, _ in requests)):
                        break
                self.assertEqual(len(completed), 2)
                self.assertEqual((a_root / "received" / "normal.bin").read_bytes(), normal)
                self.assertFalse((a_root / "target" / "normal.bin").exists())
                self.assertFalse((b_root / "received" / "normal.bin").exists())
                for request, data in requests:
                    self.assertEqual((a_root / "received" / request["path"]).read_bytes(), data)
                    self.assertEqual((a_root / "target" / request["return_path"]).read_bytes(), data)
                    self.assertEqual((b_root / "received" / request["return_path"]).read_bytes(), data)
                    self.assertTrue(b_ledger.is_complete(request["path"], "outgoing"))
                    self.assertTrue(a_ledger.is_complete(request["path"], "incoming"))
                    self.assertTrue(a_ledger.is_complete(request["return_path"], "outgoing"))
                    self.assertTrue(b_ledger.is_complete(request["return_path"], "incoming"))
            finally:
                a.close()
                b.close()

    def test_invalid_arm_and_existing_different_target_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            received, target = root / "received", root / "target"
            received.mkdir()
            target.mkdir()
            request_id = uuid.uuid4().hex
            data = b"correct payload"
            request = {
                "id": request_id,
                "path": f"pixelduplex-test/{request_id}/forward.bin",
                "return_path": f"pixelduplex-test/{request_id}/return.bin",
                "size": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
            with self.assertRaises(ValueError):
                validate_arm({**request, "return_path": "../../escape"})
            source = received / request["path"]
            source.parent.mkdir(parents=True)
            source.write_bytes(data)
            destination = target / request["return_path"]
            destination.parent.mkdir(parents=True)
            destination.write_bytes(b"existing different content")
            with self.assertRaises(FileExistsError):
                copy_verified_echo(received, target, request)
            self.assertEqual(destination.read_bytes(), b"existing different content")


if __name__ == "__main__":
    unittest.main()
