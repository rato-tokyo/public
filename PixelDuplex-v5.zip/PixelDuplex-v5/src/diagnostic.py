"""Reliable in-memory blob round trip used by the physical self-test."""

from __future__ import annotations

import hashlib
import math
import uuid
from dataclasses import dataclass, field

from .constants import FILE_CHUNK_BYTES, MessageKind
from .messages import decode_ack, decode_data, encode_ack, encode_data, json_bytes, parse_json
from .reliable import SelectiveRepeatReceiver, SelectiveRepeatSender


AppMessage = tuple[int, bytes]


@dataclass
class BlobSend:
    transfer_id: bytes
    phase: str
    payload: bytes
    reliable: SelectiveRepeatSender
    digest: str
    chunk_bytes: int
    meta_acked: bool = False
    last_meta: float = float("-inf")


@dataclass
class BlobReceive:
    transfer_id: bytes
    phase: str
    size: int
    digest: str
    chunk_count: int
    reliable: SelectiveRepeatReceiver
    chunks: dict[int, bytes] = field(default_factory=dict)
    completed: bool = False
    last_complete: float = float("-inf")
    first_chunk_at: float | None = None
    last_chunk_at: float | None = None
    first_chunk_bytes: int | None = None


class DiagnosticSession:
    """Transfers random bytes out and back using the production SR primitives."""

    def __init__(self, role: str, *, window_size: int, retransmit_seconds: float,
                 chunk_bytes: int = FILE_CHUNK_BYTES):
        if not 0 < chunk_bytes <= 120_000:
            raise ValueError("chunk_bytes must be between 1 and 120000")
        self.role = role
        self.window_size = window_size
        self.retransmit_seconds = retransmit_seconds
        self.chunk_bytes = chunk_bytes
        self.send: BlobSend | None = None
        self.receive: BlobReceive | None = None
        self.expected: bytes | None = None
        self.result: bytes | None = None
        self.completed_sends: set[bytes] = set()
        self.completed_receives: dict[bytes, AppMessage] = {}
        self.direction_metrics: dict[str, dict] = {}

    @staticmethod
    def handles(kind: int) -> bool:
        return kind in {
            MessageKind.BLOB_META, MessageKind.BLOB_DATA,
            MessageKind.BLOB_ACK, MessageKind.BLOB_COMPLETE,
            MessageKind.BLOB_COMPLETE_ACK,
        }

    @property
    def active(self) -> bool:
        return self.send is not None or self.receive is not None or self.expected is not None

    @property
    def finished(self) -> bool:
        return self.result is not None and self.send is None and self.receive is None

    def set_chunk_bytes(self, chunk_bytes: int) -> None:
        if self.active:
            raise RuntimeError("cannot change diagnostic chunk size while active")
        if not 0 < chunk_bytes <= 120_000:
            raise ValueError("chunk_bytes must be between 1 and 120000")
        self.chunk_bytes = chunk_bytes

    def start(self, payload: bytes, now: float) -> list[AppMessage]:
        if self.role != "receiver" or self.active:
            raise RuntimeError("diagnostic can only be initiated once by the receiver role")
        self.expected = payload
        self._start_send("outbound", payload)
        assert self.send is not None
        self.send.last_meta = now
        return [self._meta()]

    def _start_send(self, phase: str, payload: bytes) -> None:
        count = max(1, math.ceil(len(payload) / self.chunk_bytes))
        self.send = BlobSend(
            uuid.uuid4().bytes, phase, payload,
            SelectiveRepeatSender(count, self.window_size, self.retransmit_seconds),
            hashlib.sha256(payload).hexdigest(),
            self.chunk_bytes,
        )

    def _meta(self) -> AppMessage:
        assert self.send is not None
        return MessageKind.BLOB_META, json_bytes({
            "transfer_id": self.send.transfer_id.hex(), "purpose": "self-test",
            "phase": self.send.phase, "size": len(self.send.payload),
            "sha256": self.send.digest,
            "chunk_count": self.send.reliable.chunk_count,
            "chunk_bytes": self.send.chunk_bytes,
        })

    def handle(self, kind: int, payload: bytes, now: float) -> list[AppMessage]:
        try:
            return self._handle(kind, payload, now)
        except (UnicodeDecodeError, KeyError, TypeError, AttributeError, ValueError):
            # A malformed diagnostic message must not end the peer's `run`.
            return []

    def _handle(self, kind: int, payload: bytes, now: float) -> list[AppMessage]:
        if kind == MessageKind.BLOB_META:
            value = parse_json(payload)
            if value.get("purpose") != "self-test":
                return []
            transfer_id = bytes.fromhex(value["transfer_id"])
            if transfer_id in self.completed_receives:
                return [self.completed_receives[transfer_id]]
            if self.receive is None:
                self.receive = BlobReceive(
                    transfer_id, value["phase"], int(value["size"]), value["sha256"],
                    int(value["chunk_count"]),
                    SelectiveRepeatReceiver(int(value["chunk_count"])),
                )
            if self.receive.transfer_id != transfer_id:
                return []
            base, bitmap = self.receive.reliable.ack()
            return [(MessageKind.BLOB_ACK, encode_ack(transfer_id, base, bitmap))]
        if kind == MessageKind.BLOB_ACK and self.send is not None:
            transfer_id, base, bitmap = decode_ack(payload)
            if transfer_id == self.send.transfer_id:
                self.send.meta_acked = True
                self.send.reliable.acknowledge(base, bitmap)
            return []
        if kind == MessageKind.BLOB_DATA:
            return self._receive_data(payload, now)
        if kind == MessageKind.BLOB_COMPLETE:
            value = parse_json(payload)
            transfer_id = bytes.fromhex(value["transfer_id"])
            if transfer_id in self.completed_sends:
                return [(MessageKind.BLOB_COMPLETE_ACK, json_bytes({
                    "transfer_id": transfer_id.hex(),
                }))]
            if self.send is None or transfer_id != self.send.transfer_id:
                return []
            if value.get("phase") != self.send.phase:
                return []
            self.direction_metrics[self.send.phase] = {
                "transfer_seconds": value.get("transfer_seconds"),
                "goodput_measured_bytes": value.get("goodput_measured_bytes"),
                "goodput_bytes_per_second": value.get("goodput_bytes_per_second"),
            }
            self.completed_sends.add(transfer_id)
            self.send = None
            return [(MessageKind.BLOB_COMPLETE_ACK, json_bytes({"transfer_id": transfer_id.hex()}))]
        if kind == MessageKind.BLOB_COMPLETE_ACK and self.receive is not None:
            value = parse_json(payload)
            if value.get("transfer_id") == self.receive.transfer_id.hex():
                self.receive = None
                if self.result is not None:
                    self.expected = None
            return []
        return []

    def _receive_data(self, payload: bytes, now: float) -> list[AppMessage]:
        transfer_id, index, data = decode_data(payload)
        if transfer_id in self.completed_receives:
            return [self.completed_receives[transfer_id]]
        receive = self.receive
        if receive is None or transfer_id != receive.transfer_id or receive.completed:
            return []
        if receive.reliable.accept(index):
            receive.chunks[index] = data
            if receive.first_chunk_at is None:
                receive.first_chunk_at = now
                receive.first_chunk_bytes = len(data)
            receive.last_chunk_at = now
        base, bitmap = receive.reliable.ack()
        outgoing = [(MessageKind.BLOB_ACK, encode_ack(transfer_id, base, bitmap))]
        if receive.reliable.done:
            rebuilt = b"".join(receive.chunks[index] for index in range(receive.chunk_count))
            if len(rebuilt) != receive.size or hashlib.sha256(rebuilt).hexdigest() != receive.digest:
                if self.role == "receiver":
                    # The initiating self-test process reports the failure itself.
                    raise RuntimeError("self-test blob failed size or SHA-256 verification")
                # The responder is the normal `run`; drop the diagnostic, keep running.
                self.receive = None
                return []
            receive.completed = True
            receive.last_complete = now
            self.direction_metrics[receive.phase] = self._receive_metrics(receive)
            complete = self._complete_message(receive)
            self.completed_receives[transfer_id] = complete
            outgoing.append(complete)
            if receive.phase == "outbound" and self.role == "sender" and self.send is None:
                self._start_send("return", rebuilt)
                assert self.send is not None
                self.send.last_meta = now
                outgoing.append(self._meta())
            elif receive.phase == "return" and self.role == "receiver":
                self.result = rebuilt
        return outgoing

    @staticmethod
    def _receive_metrics(receive: BlobReceive) -> dict:
        if (receive.first_chunk_at is None or receive.last_chunk_at is None
                or receive.last_chunk_at <= receive.first_chunk_at
                or len(receive.reliable.received) < 2):
            return {
                "transfer_seconds": None,
                "goodput_measured_bytes": None,
                "goodput_bytes_per_second": None,
            }
        elapsed = receive.last_chunk_at - receive.first_chunk_at
        measured = receive.size - (receive.first_chunk_bytes or 0)
        return {
            "transfer_seconds": elapsed,
            "goodput_measured_bytes": measured,
            "goodput_bytes_per_second": measured / elapsed,
        }

    @staticmethod
    def _complete_message(receive: BlobReceive) -> AppMessage:
        return MessageKind.BLOB_COMPLETE, json_bytes({
            "transfer_id": receive.transfer_id.hex(), "phase": receive.phase,
            "size": receive.size, "sha256": receive.digest,
            **DiagnosticSession._receive_metrics(receive),
        })

    def tick(self, now: float) -> list[AppMessage]:
        outgoing: list[AppMessage] = []
        if self.send is not None:
            if not self.send.meta_acked and now - self.send.last_meta >= 1.0:
                self.send.last_meta = now
                outgoing.append(self._meta())
            if self.send.meta_acked:
                for transmission in self.send.reliable.due(now):
                    start = transmission.index * self.send.chunk_bytes
                    outgoing.append((
                        MessageKind.BLOB_DATA,
                        encode_data(
                            self.send.transfer_id, transmission.index,
                            self.send.payload[start:start + self.send.chunk_bytes],
                        ),
                    ))
        if self.receive is not None and self.receive.completed:
            if now - self.receive.last_complete >= 1.0:
                self.receive.last_complete = now
                outgoing.append(self._complete_message(self.receive))
        return outgoing
