"""Fixed-window Selective Repeat state machines."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Transmission:
    index: int
    attempts: int


class SelectiveRepeatSender:
    def __init__(self, chunk_count: int, window_size: int, retransmit_seconds: float):
        if chunk_count <= 0 or window_size <= 0 or retransmit_seconds <= 0:
            raise ValueError("selective-repeat parameters must be positive")
        self.chunk_count = chunk_count
        self.window_size = window_size
        self.retransmit_seconds = retransmit_seconds
        self.base = 0
        self.next_index = 0
        self.acked: set[int] = set()
        self.sent_at: dict[int, float] = {}
        # A reserved chunk is waiting in the physical display queue. Its
        # retransmission clock must not start until it has actually appeared.
        self.pending: set[int] = set()
        self.attempts: dict[int, int] = {}

    @property
    def done(self) -> bool:
        return len(self.acked) == self.chunk_count

    def acknowledge(self, base: int, bitmap: int, width: int = 64) -> None:
        if not 0 <= base <= self.chunk_count:
            raise ValueError("ACK base out of range")
        self.acked.update(range(base))
        for offset in range(width):
            index = base + offset
            if index < self.chunk_count and bitmap & (1 << offset):
                self.acked.add(index)
        while self.base in self.acked:
            self.base += 1
        for index in list(self.sent_at):
            if index in self.acked:
                self.sent_at.pop(index, None)
        self.pending.difference_update(self.acked)

    def due(self, now: float, max_transmissions: int | None = None) -> list[Transmission]:
        if max_transmissions is not None and max_transmissions <= 0:
            raise ValueError("max_transmissions must be positive")
        limit = self.window_size if max_transmissions is None else max_transmissions
        result: list[Transmission] = []
        ceiling = min(self.chunk_count, self.base + self.window_size)
        while self.next_index < ceiling and len(result) < limit:
            index = self.next_index
            self.next_index += 1
            if index not in self.acked and index not in self.pending:
                result.append(self._reserve(index))
        for index, sent_at in sorted(self.sent_at.items()):
            if len(result) >= limit:
                break
            if index not in self.acked and index not in self.pending and now - sent_at >= self.retransmit_seconds:
                result.append(self._reserve(index))
        return result

    def mark_displayed(self, index: int, now: float) -> None:
        """Start the retry clock after the final fragment reaches the display."""
        if index in self.pending and index not in self.acked:
            self.pending.remove(index)
            self.sent_at[index] = now

    def cancel_pending(self, index: int) -> None:
        """Release a reservation when its physical frames were not queued."""
        if index in self.pending:
            self.pending.remove(index)
            if index not in self.sent_at:
                self.next_index = min(self.next_index, index)

    def _reserve(self, index: int) -> Transmission:
        self.pending.add(index)
        self.attempts[index] = self.attempts.get(index, 0) + 1
        return Transmission(index, self.attempts[index])


class SelectiveRepeatReceiver:
    def __init__(self, chunk_count: int):
        if chunk_count <= 0:
            raise ValueError("chunk_count must be positive")
        self.chunk_count = chunk_count
        self.received: set[int] = set()

    def accept(self, index: int) -> bool:
        if not 0 <= index < self.chunk_count:
            raise ValueError("chunk index out of range")
        is_new = index not in self.received
        self.received.add(index)
        return is_new

    @property
    def done(self) -> bool:
        return len(self.received) == self.chunk_count

    def ack(self, width: int = 64) -> tuple[int, int]:
        base = 0
        while base in self.received:
            base += 1
        bitmap = 0
        for offset in range(width):
            if base + offset in self.received:
                bitmap |= 1 << offset
        return base, bitmap
