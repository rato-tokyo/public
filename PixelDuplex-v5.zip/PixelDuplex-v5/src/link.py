"""Handshake, encryption, fragmentation, and replay filtering for one endpoint."""

from __future__ import annotations

import time

from .constants import MessageKind, PhysicalKind
from . import codec_v5
from .crypto import AuthenticationError, ReplayError
from .handshake import Handshake, OutgoingHandshake, StaleProofError
from .wire import FragmentAssembler, PhysicalPacket, fragment_message


class LinkSession:
    def __init__(self, role: str, password: str):
        self.handshake = Handshake(role, password)
        self.assembler = FragmentAssembler()
        self.next_message_id = 1
        self.last_periodic = float("-inf")
        self.last_plain: OutgoingHandshake | None = None
        self.authentication_failures = 0
        self.duplicate_secure_messages = 0
        self.last_authenticated_packet = False
        self.send_profile = "baseline"

    def set_send_profile(self, profile: str) -> None:
        if profile != "baseline" and profile not in codec_v5.PROFILE_IDS:
            raise ValueError(f"unsupported send profile: {profile}")
        if profile != "baseline" and not self.connected:
            raise RuntimeError("secure channel is not established")
        self.send_profile = profile

    @property
    def connected(self) -> bool:
        return self.handshake.connected

    @property
    def session_id(self) -> bytes:
        return self.handshake.session_id

    def _pack(self, kind: int, session_id: bytes, payload: bytes,
              profile: str = "baseline") -> list[PhysicalPacket]:
        message_id = self.next_message_id
        self.next_message_id += 1
        if profile == "baseline":
            return fragment_message(kind, session_id, message_id, payload)
        return codec_v5.fragment_message(
            codec_v5.layout_for(profile), kind, session_id, message_id, payload,
        )

    def plain(self, outgoing: OutgoingHandshake) -> list[PhysicalPacket]:
        self.last_plain = outgoing
        return self._pack(outgoing.physical_kind, outgoing.session_id, outgoing.payload)

    def secure(self, kind: int, payload: bytes, *,
               force_baseline: bool = False) -> list[PhysicalPacket]:
        channel = self.handshake.channel
        if channel is None:
            raise RuntimeError("secure channel is not established")
        envelope = channel.seal(kind, payload)
        profile = "baseline" if force_baseline else self.send_profile
        return self._pack(PhysicalKind.SECURE, self.session_id, envelope, profile)

    def periodic(self, now: float | None = None) -> list[PhysicalPacket]:
        now = time.monotonic() if now is None else now
        if now - self.last_periodic < 0.5:
            return []
        self.last_periodic = now
        if self.handshake.state == "CONNECTING":
            return self.plain(self.handshake.beacon())
        if self.handshake.state in {"WAIT_READY", "WAIT_PING"} and self.last_plain:
            return self.plain(self.last_plain)
        probe = self.handshake.secure_probe()
        if probe:
            return self.secure(*probe)
        return []

    def receive(self, packet: PhysicalPacket) -> tuple[list[PhysicalPacket], list[tuple[int, bytes]]]:
        self.last_authenticated_packet = False
        complete = self.assembler.add(packet)
        if complete is None:
            return [], []
        outgoing: list[PhysicalPacket] = []
        messages: list[tuple[int, bytes]] = []
        if packet.kind != PhysicalKind.SECURE:
            try:
                response = self.handshake.receive_plain(packet.kind, packet.session_id, complete)
            except StaleProofError:
                self.authentication_failures += 1
                return outgoing, messages
            if response is not None:
                outgoing.extend(self.plain(response))
            if self.handshake.state == "WAIT_PONG":
                probe = self.handshake.secure_probe()
                if probe:
                    outgoing.extend(self.secure(*probe))
            return outgoing, messages
        if packet.session_id != self.session_id or self.handshake.channel is None:
            return outgoing, messages
        try:
            kind, payload = self.handshake.channel.open(complete)
        except ReplayError:
            self.duplicate_secure_messages += 1
            return outgoing, messages
        except AuthenticationError:
            self.authentication_failures += 1
            return outgoing, messages
        self.last_authenticated_packet = True
        handshake_response = self.handshake.receive_secure(kind, payload)
        if handshake_response is not None:
            outgoing.extend(self.secure(*handshake_response))
        if kind not in {MessageKind.PING, MessageKind.PONG}:
            messages.append((kind, payload))
        return outgoing, messages
