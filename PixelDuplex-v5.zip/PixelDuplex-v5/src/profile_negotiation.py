"""Session-bound, authenticated-control-channel profile agreement.

This module does not authenticate messages or change the codec. Callers must
deliver messages only after link authentication, on the baseline control codec,
and must keep using the baseline data codec until agreement is complete. A fresh
negotiator is required for every link session.
"""

from __future__ import annotations

from dataclasses import dataclass, field


BASELINE_PROFILE = "baseline"
# Profile names are identifiers, never peer-supplied codec parameters.
ALLOWED_PROFILES = frozenset({BASELINE_PROFILE, "mono-band4", "gray4-band4"})
MESSAGE_TYPES = frozenset({
    "PROFILE_PROPOSE", "PROFILE_ACK", "PROFILE_CONFIRM", "PROFILE_CONFIRMED",
})
# "sync": file sync will run on the agreed profile, so both ends must have
# chosen it. "trial": an explicit profile-test that never starts file sync.
PURPOSES = frozenset({"sync", "trial"})
MESSAGE_FIELDS = frozenset({"type", "session_id", "exchange_id", "profile_id", "purpose"})


class ProfileAgreementError(ValueError):
    """Invalid, stale, or inconsistent profile agreement."""


@dataclass
class ProfileNegotiator:
    role: str
    session_id: str
    supported_profiles: frozenset[str] = field(
        default_factory=lambda: frozenset({BASELINE_PROFILE})
    )
    timeout_seconds: float = 10.0
    # Responder only: the profile this end is configured to sync on.
    sync_profile: str = BASELINE_PROFILE
    state: str = field(init=False, default="IDLE")
    purpose: str | None = field(init=False, default=None)
    active_profile: str = field(init=False, default=BASELINE_PROFILE)
    selected_profile: str | None = field(init=False, default=None)
    deadline: float | None = field(init=False, default=None)
    error: str | None = field(init=False, default=None)
    _exchange_id: str | None = field(init=False, default=None)
    _proposed_profile: str | None = field(init=False, default=None)

    def __post_init__(self) -> None:
        if self.role not in {"initiator", "responder"}:
            raise ValueError("role must be initiator or responder")
        if not isinstance(self.session_id, str) or not self.session_id:
            raise ValueError("session_id must be a nonempty string")
        self.supported_profiles = frozenset(self.supported_profiles)
        if (BASELINE_PROFILE not in self.supported_profiles
                or not self.supported_profiles <= ALLOWED_PROFILES):
            raise ValueError("supported_profiles must contain baseline and known IDs only")
        if self.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be positive")
        if self.sync_profile not in self.supported_profiles:
            raise ValueError("sync_profile must be a supported profile")

    def _message(self, kind: str, profile: str) -> dict[str, str]:
        assert self._exchange_id is not None and self.purpose is not None
        return {
            "type": kind,
            "session_id": self.session_id,
            "exchange_id": self._exchange_id,
            "profile_id": profile,
            "purpose": self.purpose,
        }

    def _fail(self, reason: str) -> None:
        self.state = "FAILED"
        self.active_profile = BASELINE_PROFILE
        self.selected_profile = None
        self.deadline = None
        self.error = reason

    def tick(self, now: float) -> None:
        if self.deadline is not None and now >= self.deadline:
            self._fail("profile agreement timed out")

    def pending_message(self, now: float) -> dict[str, str] | None:
        """Return the last step for a bounded retry; retries do not extend timeout."""
        self.tick(now)
        if self.role == "initiator" and self.state == "WAIT_ACK":
            return self._message("PROFILE_PROPOSE", self._proposed_profile)
        if self.role == "responder" and self.state == "WAIT_CONFIRM":
            return self._message("PROFILE_ACK", self.selected_profile)
        if self.role == "initiator" and self.state == "WAIT_CONFIRMED":
            return self._message("PROFILE_CONFIRM", self.selected_profile)
        return None

    def propose(self, profile_id: str, exchange_id: str, now: float,
                purpose: str = "trial") -> dict[str, str]:
        """Start one agreement; exchange_id must be unique within the session."""
        if self.role != "initiator" or self.state != "IDLE":
            raise ProfileAgreementError("proposal is not allowed in this state")
        if profile_id not in self.supported_profiles:
            raise ValueError("profile is not locally supported")
        if not isinstance(exchange_id, str) or not exchange_id:
            raise ValueError("exchange_id must be a nonempty string")
        if purpose not in PURPOSES:
            raise ValueError("purpose must be sync or trial")
        self.purpose = purpose
        self._exchange_id = exchange_id
        self._proposed_profile = profile_id
        self.selected_profile = profile_id
        self.state = "WAIT_ACK"
        self.deadline = now + self.timeout_seconds
        return self._message("PROFILE_PROPOSE", profile_id)

    def receive(self, message: dict, now: float) -> dict[str, str] | None:
        """Process a decrypted, authenticated control message; duplicates are safe."""
        self.tick(now)
        if self.state == "FAILED":
            raise ProfileAgreementError(self.error or "profile agreement failed")
        if not isinstance(message, dict) or set(message) != MESSAGE_FIELDS:
            self._fail("invalid profile message shape")
            raise ProfileAgreementError(self.error)
        if not all(isinstance(value, str) for value in message.values()):
            self._fail("non-string profile message field")
            raise ProfileAgreementError(self.error)
        kind = message["type"]
        profile = message["profile_id"]
        exchange = message["exchange_id"]
        purpose = message["purpose"]
        if (kind not in MESSAGE_TYPES or message["session_id"] != self.session_id
                or not exchange or profile not in ALLOWED_PROFILES
                or purpose not in PURPOSES):
            self._fail("invalid or cross-session profile message")
            raise ProfileAgreementError(self.error)

        if self.role == "responder" and self.state == "IDLE" and kind == "PROFILE_PROPOSE":
            self._exchange_id = exchange
            self.purpose = purpose
            self._proposed_profile = profile
            acceptable = profile in self.supported_profiles and (
                purpose == "trial" or profile in {BASELINE_PROFILE, self.sync_profile}
            )
            # A sync proposal for a profile this end was not configured to sync
            # on falls back to baseline, so both ends always run file sync.
            self.selected_profile = profile if acceptable else BASELINE_PROFILE
            self.state = "WAIT_CONFIRM"
            self.deadline = now + self.timeout_seconds
            return self._message("PROFILE_ACK", self.selected_profile)

        if exchange != self._exchange_id or purpose != self.purpose:
            self._fail("profile exchange mismatch")
            raise ProfileAgreementError(self.error)

        if (self.role == "responder" and self.state in {"WAIT_CONFIRM", "ACTIVE"}
                and kind == "PROFILE_PROPOSE"):
            if profile != self._proposed_profile:
                self._fail("changed proposal for same exchange")
                raise ProfileAgreementError(self.error)
            return self._message("PROFILE_ACK", self.selected_profile)

        if (self.role == "initiator" and self.state == "WAIT_CONFIRMED"
                and kind == "PROFILE_ACK"):
            if profile != self.selected_profile:
                self._fail("changed ACK for same exchange")
                raise ProfileAgreementError(self.error)
            return self._message("PROFILE_CONFIRM", profile)

        if (self.role == "responder" and self.state == "ACTIVE"
                and kind == "PROFILE_CONFIRM"):
            if profile != self.selected_profile:
                self._fail("changed confirmation for same exchange")
                raise ProfileAgreementError(self.error)
            return self._message("PROFILE_CONFIRMED", profile)

        if (self.role == "initiator" and self.state == "ACTIVE"
                and kind == "PROFILE_ACK"):
            # The responder retries ACK every second; one may arrive late.
            if profile != self.selected_profile:
                self._fail("changed ACK for same exchange")
                raise ProfileAgreementError(self.error)
            return None

        if (self.role == "initiator" and self.state == "ACTIVE"
                and kind == "PROFILE_CONFIRMED"):
            if profile != self.selected_profile:
                self._fail("changed final confirmation for same exchange")
                raise ProfileAgreementError(self.error)
            return None

        if self.role == "initiator" and self.state == "WAIT_ACK" and kind == "PROFILE_ACK":
            if profile not in {self.selected_profile, BASELINE_PROFILE}:
                self._fail("unexpected profile selection")
                raise ProfileAgreementError(self.error)
            self.selected_profile = profile
            self.state = "WAIT_CONFIRMED"
            self.deadline = now + self.timeout_seconds
            return self._message("PROFILE_CONFIRM", profile)

        if self.role == "responder" and self.state == "WAIT_CONFIRM" and kind == "PROFILE_CONFIRM":
            if profile != self.selected_profile:
                self._fail("profile confirmation mismatch")
                raise ProfileAgreementError(self.error)
            response = self._message("PROFILE_CONFIRMED", profile)
            self.state = "ACTIVE"
            self.active_profile = profile
            self.deadline = None
            return response

        if self.role == "initiator" and self.state == "WAIT_CONFIRMED" and kind == "PROFILE_CONFIRMED":
            if profile != self.selected_profile:
                self._fail("final profile confirmation mismatch")
                raise ProfileAgreementError(self.error)
            self.state = "ACTIVE"
            self.active_profile = profile
            self.deadline = None
            return None

        self._fail("unexpected profile message or replay")
        raise ProfileAgreementError(self.error)
