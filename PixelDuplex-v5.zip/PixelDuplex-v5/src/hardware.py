"""Windows display/capture transport for PixelDuplex physical frames."""

from __future__ import annotations

import ctypes
import queue
import threading
import time
from collections import deque
from ctypes import wintypes
from typing import Callable

import cv2

from .constants import DEFAULT_FRAME_INTERVAL_SECONDS, HEIGHT, WIDTH
from . import codec_v5
from .wire import PhysicalPacket, decode_image, packet_image


_CAPTURE_CLOSE_JOIN_SECONDS = 2.0
_CAPTURE_REOPEN_SECONDS = 2.0
_WINDOW_STYLE_INDEX = -16
_POPUP_VISIBLE_STYLE = 0x80000000 | 0x10000000
_TOPMOST_NO_ACTIVATE = 0x20 | 0x40


def opencv_gui_backend() -> str | None:
    """Return the compiled OpenCV GUI backend, or None for headless builds."""
    for line in cv2.getBuildInformation().splitlines():
        stripped = line.strip()
        if stripped.startswith("GUI:"):
            backend = stripped.partition(":")[2].strip()
            return None if backend.upper() in {"", "NONE", "NO"} else backend
    return None


def require_opencv_gui() -> str:
    backend = opencv_gui_backend()
    if backend is None:
        raise RuntimeError(
            "OpenCV has no GUI backend; uninstall opencv-python-headless and "
            "install the repository requirement opencv-python"
        )
    return backend


def configure_dpi() -> None:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def active_monitors() -> list[dict]:
    if not hasattr(ctypes, "windll"):
        raise RuntimeError("PixelDuplex hardware mode requires Windows")
    monitors: list[dict] = []
    callback_type = ctypes.WINFUNCTYPE(
        ctypes.c_int, wintypes.HMONITOR, wintypes.HDC,
        ctypes.POINTER(wintypes.RECT), wintypes.LPARAM,
    )

    class MONITORINFOEXW(ctypes.Structure):
        _fields_ = [
            ("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT),
            ("rcWork", wintypes.RECT), ("dwFlags", wintypes.DWORD),
            ("szDevice", wintypes.WCHAR * 32),
        ]

    def callback(handle, _dc, _rect, _data):
        info = MONITORINFOEXW()
        info.cbSize = ctypes.sizeof(info)
        if ctypes.windll.user32.GetMonitorInfoW(handle, ctypes.byref(info)):
            rect = info.rcMonitor
            monitors.append({
                "handle": handle, "device": info.szDevice,
                "primary": bool(info.dwFlags & 1),
                "rect": (rect.left, rect.top, rect.right, rect.bottom),
            })
        return 1

    ctypes.windll.user32.EnumDisplayMonitors(None, None, callback_type(callback), 0)
    return monitors


def choose_external_monitor(monitors: list[dict], configured_device: str | None = None) -> dict:
    candidates = [item for item in monitors if not item["primary"]]
    if configured_device:
        candidates = [item for item in candidates if item["device"] == configured_device]
    if len(candidates) != 1:
        listing = "; ".join(
            f"{item['device']} primary={item['primary']} rect={item['rect']}"
            for item in monitors
        )
        raise RuntimeError(
            "could not select exactly one non-primary monitor before display; "
            f"detected: {listing or 'none'}"
        )
    selected = candidates[0]
    left, top, right, bottom = selected["rect"]
    if (right - left, bottom - top) != (WIDTH, HEIGHT):
        raise RuntimeError(
            f"PixelDuplex requires a 1920x1080 external monitor; "
            f"selected {selected['device']} is {right-left}x{bottom-top}"
        )
    return selected


def position_and_verify(window: str, monitor: dict) -> None:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    find_window = user32.FindWindowW
    find_window.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    find_window.restype = wintypes.HWND
    hwnd = find_window(None, window)
    if not hwnd:
        raise RuntimeError("could not locate output window")
    show_window = user32.ShowWindow
    show_window.argtypes = [wintypes.HWND, ctypes.c_int]
    show_window.restype = wintypes.BOOL
    show_window(hwnd, 0)
    try:
        set_style = user32.SetWindowLongPtrW
        set_style.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t]
        set_style.restype = ctypes.c_ssize_t
        style = _POPUP_VISIBLE_STYLE
    except AttributeError:
        set_style = user32.SetWindowLongW
        set_style.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.LONG]
        set_style.restype = wintypes.LONG
        style = ctypes.c_long(_POPUP_VISIBLE_STYLE).value
    ctypes.set_last_error(0)
    previous = set_style(hwnd, _WINDOW_STYLE_INDEX, style)
    if previous == 0 and ctypes.get_last_error():
        raise ctypes.WinError(ctypes.get_last_error())
    left, top, right, bottom = monitor["rect"]
    set_position = user32.SetWindowPos
    set_position.argtypes = [
        wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
        ctypes.c_int, ctypes.c_int, wintypes.UINT,
    ]
    set_position.restype = wintypes.BOOL
    if not set_position(
        hwnd, wintypes.HWND(-1), left, top, right - left, bottom - top,
        _TOPMOST_NO_ACTIVATE,
    ):
        raise ctypes.WinError(ctypes.get_last_error())
    actual = wintypes.RECT()
    get_rect = user32.GetWindowRect
    get_rect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    get_rect.restype = wintypes.BOOL
    if not get_rect(hwnd, ctypes.byref(actual)):
        raise ctypes.WinError(ctypes.get_last_error())
    if (actual.left, actual.top, actual.right, actual.bottom) != monitor["rect"]:
        raise RuntimeError("output window placement verification failed")


class DisplayLostError(RuntimeError):
    """The external data monitor disappeared or the window left it."""


def window_rect(window: str) -> tuple[int, int, int, int] | None:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    find_window = user32.FindWindowW
    find_window.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    find_window.restype = wintypes.HWND
    hwnd = find_window(None, window)
    if not hwnd:
        return None
    actual = wintypes.RECT()
    get_rect = user32.GetWindowRect
    get_rect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
    get_rect.restype = wintypes.BOOL
    if not get_rect(hwnd, ctypes.byref(actual)):
        return None
    return actual.left, actual.top, actual.right, actual.bottom


def hide_window(window: str) -> None:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowW.restype = wintypes.HWND
    hwnd = user32.FindWindowW(None, window)
    if hwnd:
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.ShowWindow(hwnd, 0)


def open_capture(device: int):
    capture = cv2.VideoCapture(device, cv2.CAP_DSHOW)
    if capture.isOpened():
        capture.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"YUY2"))
        capture.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)
        capture.set(cv2.CAP_PROP_FPS, 30)
    return capture


class HdmiFrameIO:
    """Queue physical packets while continuously capturing in a worker thread."""

    def __init__(self, device: int, monitor_device: str | None = None,
                 frame_interval: float = DEFAULT_FRAME_INTERVAL_SECONDS):
        self.device = device
        self.monitor_device = monitor_device
        self.frame_interval = frame_interval
        self.window = "PixelDuplex Data Display"
        self._outgoing: deque[PhysicalPacket] = deque()
        self._outgoing_enqueued_at: deque[float] = deque()
        self._outgoing_displayed: deque[Callable[[float], None] | None] = deque()
        self._outgoing_profiles: deque[str] = deque()
        self._outgoing_keys: deque[object | None] = deque()
        # Banded profiles repaint one band per sub-interval onto this canvas.
        self._canvas = None
        self._band_cursor = 0
        self._band_hold_until = 0.0
        self._prefer_bands = False
        self.coalesced_frames = 0
        self.capture_frames_per_second: float | None = None
        self._fps_since: float | None = None
        self._fps_count = 0
        self._incoming: queue.Queue[tuple[PhysicalPacket, tuple | None]] = queue.Queue(maxsize=512)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._capture = None
        self._capture_lock = threading.Lock()
        self._next_frame_at = 0.0
        self.repeated_capture_frames = 0
        self.undecodable_capture_frames = 0
        self.dropped_queue_frames = 0
        self.max_outgoing_queue_depth = 0
        self.displayed_unique_frames = 0
        self.displayed_duplicate_frames = 0
        self.display_delay_seconds_total = 0.0
        self.display_delay_seconds_max = 0.0
        self._displayed_identities: set[tuple[bytes, int, int, int, int]] = set()
        self._displayed_order: deque[tuple[bytes, int, int, int, int]] = deque()
        # Set by start(); tests that never open a window leave it None.
        self._monitor: dict | None = None
        self._display_checked_at = float("-inf")

    def start(self) -> None:
        require_opencv_gui()
        configure_dpi()
        monitor = choose_external_monitor(active_monitors(), self.monitor_device)
        self._monitor = monitor
        self._capture = open_capture(self.device)
        if not self._capture.isOpened():
            raise RuntimeError(f"could not open capture device {self.device}")
        cv2.namedWindow(self.window, cv2.WINDOW_NORMAL)
        position_and_verify(self.window, monitor)
        self._thread = threading.Thread(target=self._capture_loop, daemon=True)
        self._thread.start()

    def send(self, packets: list[PhysicalPacket], *, priority: bool = False,
             on_display: Callable[[float], None] | None = None,
             profile: str = "baseline",
             coalesce_key: object | None = None) -> None:
        """Queue packets. A single-packet send with ``coalesce_key`` replaces a
        still-undisplayed packet with the same key in place (cumulative ACKs)."""
        if profile != "baseline" and profile not in codec_v5.PROFILE_IDS:
            raise ValueError(f"unsupported send profile: {profile}")
        if coalesce_key is not None and len(packets) == 1:
            for index, key in enumerate(self._outgoing_keys):
                if key == coalesce_key:
                    self._outgoing[index] = packets[0]
                    self._outgoing_profiles[index] = profile
                    self._outgoing_displayed[index] = on_display
                    self.coalesced_frames += 1
                    return
        key = coalesce_key if len(packets) == 1 else None
        queued_at = time.monotonic()
        callbacks = [None] * len(packets)
        if callbacks:
            callbacks[-1] = on_display
        if priority:
            self._outgoing.extendleft(reversed(packets))
            self._outgoing_enqueued_at.extendleft(queued_at for _ in packets)
            self._outgoing_displayed.extendleft(reversed(callbacks))
            self._outgoing_profiles.extendleft(profile for _ in packets)
            self._outgoing_keys.extendleft(key for _ in packets)
        else:
            self._outgoing.extend(packets)
            self._outgoing_enqueued_at.extend(queued_at for _ in packets)
            self._outgoing_displayed.extend(callbacks)
            self._outgoing_profiles.extend(profile for _ in packets)
            self._outgoing_keys.extend(key for _ in packets)
        self.max_outgoing_queue_depth = max(self.max_outgoing_queue_depth, len(self._outgoing))

    def clear_outgoing(self) -> None:
        self._outgoing.clear()
        self._outgoing_enqueued_at.clear()
        self._outgoing_displayed.clear()
        self._outgoing_profiles.clear()
        self._outgoing_keys.clear()

    def display_metrics(self) -> dict[str, int | float | None]:
        displayed = self.displayed_unique_frames + self.displayed_duplicate_frames
        return {
            "outgoing_queue_depth": len(self._outgoing),
            "outgoing_queue_high_watermark": self.max_outgoing_queue_depth,
            "displayed_unique_frames": self.displayed_unique_frames,
            "displayed_duplicate_frames": self.displayed_duplicate_frames,
            "display_delay_seconds_mean": (
                self.display_delay_seconds_total / displayed if displayed else None
            ),
            "display_delay_seconds_max": (
                self.display_delay_seconds_max if displayed else None
            ),
            "coalesced_ack_frames": self.coalesced_frames,
            # Raw successful reads per second; the driver may repeat images.
            "capture_reads_per_second": self.capture_frames_per_second,
        }

    def check_display(self, now: float) -> None:
        """Stop before the data window can cover the primary screen.

        Windows moves a window onto the primary monitor when the extended
        display disappears (e.g. switched to duplicate or PC screen only).
        """
        if self._monitor is None or now - self._display_checked_at < 1.0:
            return
        self._display_checked_at = now
        expected = self._monitor
        try:
            current = choose_external_monitor(active_monitors(), self.monitor_device)
        except RuntimeError as error:
            reason = f"external monitor lost: {error}"
        else:
            if (current["device"], current["rect"]) != (expected["device"], expected["rect"]):
                reason = (f"external monitor changed: {expected['device']} {expected['rect']} "
                          f"-> {current['device']} {current['rect']}")
            elif window_rect(self.window) != expected["rect"]:
                reason = f"data window left the external monitor {expected['device']}"
            else:
                return
        hide_window(self.window)
        raise DisplayLostError(reason)

    def pump_display(self) -> bool:
        now = time.monotonic()
        self.check_display(now)
        if (self._outgoing and self._outgoing_profiles[0] == "baseline"
                and self._canvas is not None and now < self._band_hold_until):
            # A full-frame packet would erase every band; let the newest band
            # stay up for one whole frame_interval first.
            return (cv2.waitKey(1) & 0xFF) != 27
        if self._outgoing and now >= self._next_frame_at:
            packet = self._outgoing.popleft()
            queued_at = self._outgoing_enqueued_at.popleft()
            on_display = self._outgoing_displayed.popleft()
            profile = self._outgoing_profiles.popleft()
            self._outgoing_keys.popleft()
            if profile == "baseline":
                # Keep the band canvas: repainting one band over black after a
                # full-frame packet leaves too little screen to find the
                # active area of a scaled capture.
                image = packet_image(packet)
                hold = self.frame_interval
            else:
                # Staggered repaint: each band still stays up for one full
                # frame_interval, but only one band changes at a time.
                if self._canvas is None:
                    self._canvas = codec_v5.blank_canvas()
                    self._band_cursor = 0
                codec_v5.paint_band(
                    self._canvas, self._band_cursor, codec_v5.layout_for(profile), packet,
                )
                self._band_cursor = (self._band_cursor + 1) % codec_v5.BANDS
                self._band_hold_until = now + self.frame_interval
                image = self._canvas
                hold = self.frame_interval / codec_v5.BANDS
            cv2.imshow(self.window, image)
            delay = max(0.0, now - queued_at)
            self.display_delay_seconds_total += delay
            self.display_delay_seconds_max = max(self.display_delay_seconds_max, delay)
            identity = (
                packet.session_id, packet.kind, packet.message_id,
                packet.fragment_index, packet.fragment_count,
            )
            if identity in self._displayed_identities:
                self.displayed_duplicate_frames += 1
            else:
                self.displayed_unique_frames += 1
                self._displayed_identities.add(identity)
                self._displayed_order.append(identity)
                while len(self._displayed_order) > 4096:
                    self._displayed_identities.discard(self._displayed_order.popleft())
            # Advance from the schedule, not from "now", so waitKey and loop
            # latency do not accumulate; resync after an idle or long stall.
            scheduled = self._next_frame_at + hold
            self._next_frame_at = scheduled if scheduled > now else now + hold
            if on_display is not None:
                on_display(now)
        return (cv2.waitKey(1) & 0xFF) != 27

    def receive(self) -> list[tuple[PhysicalPacket, tuple | None]]:
        result = []
        while True:
            try:
                result.append(self._incoming.get_nowait())
            except queue.Empty:
                return result

    def _capture_loop(self) -> None:
        previous_identities: set[tuple[bytes, int, int, int, int]] = set()
        failed_since: float | None = None
        while not self._stop.is_set():
            capture = self._capture
            if capture is None:
                if self._stop.wait(_CAPTURE_REOPEN_SECONDS):
                    break
                self._reopen_capture()
                continue
            try:
                ok, frame = capture.read()
            except (cv2.error, OSError):
                ok, frame = False, None
            if not ok:
                previous_identities = set()
                now = time.monotonic()
                if failed_since is None:
                    failed_since = now
                elif now - failed_since >= _CAPTURE_REOPEN_SECONDS:
                    failed_since = None
                    self._reopen_capture()
                else:
                    self._stop.wait(0.05)
                continue
            failed_since = None
            self._count_capture_read(time.monotonic())
            try:
                packets, rect = self._decode_frame(frame)
            except Exception:
                # An unexpected frame must not silently stop the capture worker.
                packets, rect = [], None
            if not packets:
                self.undecodable_capture_frames += 1
                previous_identities = set()
                continue
            delivered: set[tuple[bytes, int, int, int, int]] = set()
            for packet in packets:
                identity = (
                    packet.session_id,
                    packet.kind,
                    packet.message_id,
                    packet.fragment_index,
                    packet.fragment_count,
                )
                # A band that did not change since the previous capture is a
                # repeat; only the repainted band carries new data.
                if identity in previous_identities:
                    self.repeated_capture_frames += 1
                    delivered.add(identity)
                    continue
                try:
                    self._incoming.put_nowait((packet, rect))
                except queue.Full:
                    self.dropped_queue_frames += 1
                else:
                    # Remember only successful delivery. A full queue must leave
                    # the same physical packet eligible for the next capture.
                    delivered.add(identity)
            previous_identities = delivered

    def _decode_frame(self, frame) -> tuple[list[PhysicalPacket], tuple[int, int, int, int] | None]:
        """Decode baseline or banded frames, trying the last successful format first."""
        def baseline():
            packet, rect = decode_image(frame)
            return ([packet], rect) if packet is not None else ([], None)

        def banded():
            return codec_v5.decode_bands(frame)

        order = (banded, baseline) if self._prefer_bands else (baseline, banded)
        for decoder in order:
            packets, rect = decoder()
            if packets:
                self._prefer_bands = decoder is banded
                return packets, rect
        return [], None

    def _count_capture_read(self, now: float) -> None:
        """Measure raw capture reads per second over roughly 5-second windows."""
        if self._fps_since is None:
            self._fps_since, self._fps_count = now, 0
            return
        self._fps_count += 1
        elapsed = now - self._fps_since
        if elapsed >= 5.0:
            self.capture_frames_per_second = round(self._fps_count / elapsed, 2)
            self._fps_since, self._fps_count = now, 0

    def _reopen_capture(self) -> None:
        """Replace a failed DirectShow handle without reopening on every bad frame."""
        with self._capture_lock:
            old = self._capture
            self._capture = None
        if old is not None:
            old.release()
        if self._stop.is_set():
            return
        try:
            replacement = open_capture(self.device)
        except (cv2.error, OSError):
            return
        if not replacement.isOpened():
            replacement.release()
            return
        with self._capture_lock:
            if self._stop.is_set():
                replacement.release()
            else:
                self._capture = replacement

    def close(self) -> None:
        self._stop.set()
        thread = self._thread
        with self._capture_lock:
            capture = self._capture
            self._capture = None
        if thread is not None:
            thread.join(timeout=_CAPTURE_CLOSE_JOIN_SECONDS)
        # DirectShow read() can remain blocked until the capture handle is
        # released. Release it exactly once, then give the worker one final
        # bounded opportunity to finish.
        if capture is not None:
            capture.release()
        if thread is not None and thread.is_alive():
            thread.join(timeout=_CAPTURE_CLOSE_JOIN_SECONDS)
        shutdown_failed = thread is not None and thread.is_alive()
        if not shutdown_failed:
            self._thread = None
        try:
            cv2.destroyAllWindows()
        except cv2.error:
            # Avoid masking the actionable startup error on headless builds.
            pass
        if shutdown_failed:
            raise RuntimeError("capture worker did not stop after capture release")
