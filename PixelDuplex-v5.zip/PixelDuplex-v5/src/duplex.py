"""Bidirectional file-sync composition and single-transfer arbitration."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from .constants import (
    DEFAULT_RETRANSMIT_SECONDS, DEFAULT_SCAN_INTERVAL_SECONDS,
    DEFAULT_STABLE_SECONDS, DEFAULT_WINDOW_SIZE, MessageKind,
)
from .ledger import Ledger
from .file_loopback import copy_verified_echo, validate_arm
from .messages import json_bytes, parse_json
from .sync import AppMessage, ReceiverEngine, SenderEngine


class DuplexEngine:
    """Run outbound and inbound engines under one authenticated receive token."""

    def __init__(self, target: Path, received: Path, ledger: Ledger, role: str, *,
                 window_size: int = DEFAULT_WINDOW_SIZE,
                 scan_interval: float = DEFAULT_SCAN_INTERVAL_SECONDS,
                 stable_seconds: float = DEFAULT_STABLE_SECONDS,
                 retransmit_seconds: float = DEFAULT_RETRANSMIT_SECONDS,
                 session_id: str = "local", report_path: Path | None = None,
                 metrics_provider: Callable[[], dict[str, int]] | None = None,
                 progress_sink: Callable[[str], None] | None = None):
        if role not in {"sender", "receiver"}:
            raise ValueError("role must be sender or receiver")
        self.role = role
        self.peer_role = "receiver" if role == "sender" else "sender"
        self.outbound = SenderEngine(
            target, ledger.scope("outgoing"), window_size=window_size,
            scan_interval=scan_interval, stable_seconds=stable_seconds,
            retransmit_seconds=retransmit_seconds,
            report_path=report_path,
            metrics_provider=metrics_provider,
            progress_sink=progress_sink,
        )
        self.inbound = ReceiverEngine(
            received, ledger.scope("incoming"), session_id=session_id,
            report_path=report_path,
            metrics_provider=metrics_provider,
            progress_sink=progress_sink,
        )
        self.token_epoch = 0
        self.token_owner = "receiver"
        self.last_token_sent = float("-inf")
        self.idle_since: float | None = None
        self.scan_interval = scan_interval
        self.file_echo_status: dict | None = None
        self._file_echo_arm: dict | None = None
        self._file_echo_result: dict | None = None

    @property
    def transfer(self):
        return self.inbound.transfer or self.outbound.transfer

    @property
    def transfer_direction(self) -> str | None:
        if self.inbound.transfer is not None:
            return "incoming"
        if self.outbound.transfer is not None:
            return "outgoing"
        return None

    def close(self) -> None:
        self.outbound.close()
        self.inbound.close()

    def update_session_id(self, session_id: str) -> None:
        self.inbound.session_id = session_id

    def set_chunk_bytes(self, chunk_bytes: int) -> None:
        """Apply an agreed physical profile only while file transfer is idle."""
        if self.transfer is not None or self.inbound.completed_message is not None:
            raise RuntimeError("cannot change chunk size during transfer")
        self.outbound.set_chunk_bytes(chunk_bytes)

    def _token_message(self) -> AppMessage:
        return MessageKind.SYNC_TOKEN, json_bytes({
            "epoch": self.token_epoch, "owner": self.token_owner,
        })

    def _receive_idle(self) -> bool:
        return (
            self.inbound.manifest_received
            and not self.inbound.pending
            and self.inbound.transfer is None
            and self.inbound.completed_message is None
        )

    def handle(self, kind: int, payload: bytes, now: float) -> list[AppMessage]:
        try:
            if kind == MessageKind.FILE_ECHO_RESULT:
                value = parse_json(payload)
                if isinstance(value, dict):
                    self.file_echo_status = value
                return []
            if kind == MessageKind.FILE_ECHO_ARM:
                return self._handle_file_echo_arm(payload)
            if kind == MessageKind.SYNC_TOKEN:
                return self._handle_token(payload)
            # Messages addressed to our sending side; everything else (including
            # the sender's CONFLICT cancellation and FILE_UNAVAILABLE) is inbound.
            if kind in {
                MessageKind.MANIFEST_REQUEST, MessageKind.FILE_REQUEST,
                MessageKind.FILE_ACK, MessageKind.FILE_COMPLETE,
                MessageKind.ALREADY_COMPLETE, MessageKind.FILE_REJECTED,
            }:
                return self.outbound.handle(kind, payload, now)
            outgoing = self.inbound.handle(kind, payload, now)
        except (UnicodeDecodeError, KeyError, TypeError, AttributeError, ValueError):
            # A malformed peer message is dropped; it must not end `run`.
            # Filesystem and ledger failures are OSError and still propagate.
            return []
        if kind == MessageKind.FILE_DATA:
            outgoing.extend(self._maybe_copy_echo())
        return outgoing

    def _echo_result(self, status: str, reason: str | None = None) -> list[AppMessage]:
        request = self._file_echo_arm
        if request is None:
            return []
        result = {"id": request["id"], "status": status}
        if reason is not None:
            result["reason"] = reason
        self._file_echo_result = result
        return [(MessageKind.FILE_ECHO_RESULT, json_bytes(result))]

    def _handle_file_echo_arm(self, payload: bytes) -> list[AppMessage]:
        if self.role != "sender":
            return []
        try:
            request = validate_arm(parse_json(payload))
        except (ValueError, TypeError):
            return []
        current = self._file_echo_arm
        if current is not None and request["id"] == current["id"] and request != current:
            return [(MessageKind.FILE_ECHO_RESULT, json_bytes({
                "id": request["id"], "status": "FAILURE", "reason": "echo request changed for the same id",
            }))]
        if current is None or request != current:
            self._file_echo_arm = request
            self._file_echo_result = None
        if self._file_echo_result is not None and self._file_echo_result["status"] != "ARMED":
            return [(MessageKind.FILE_ECHO_RESULT, json_bytes(self._file_echo_result))]
        copied = self._maybe_copy_echo()
        return copied or self._echo_result("ARMED")

    def _maybe_copy_echo(self) -> list[AppMessage]:
        request = self._file_echo_arm
        if request is None or (
            self._file_echo_result is not None
            and self._file_echo_result["status"] != "ARMED"
        ):
            return []
        record = self.inbound.ledger.get(request["path"])
        if not record or record.get("status") != "SUCCESS":
            return []
        if record.get("size") != request["size"] or record.get("sha256") != request["sha256"]:
            return self._echo_result("FAILURE", "received ledger does not match echo request")
        try:
            copy_verified_echo(self.inbound.root, self.outbound.root, request)
        except (OSError, ValueError) as error:
            return self._echo_result("FAILURE", str(error))
        return self._echo_result("COPIED")

    def _handle_token(self, payload: bytes) -> list[AppMessage]:
        value = parse_json(payload)
        epoch, owner = value.get("epoch"), value.get("owner")
        if not isinstance(epoch, int) or owner not in {"sender", "receiver"}:
            return []
        if epoch < self.token_epoch:
            return [self._token_message()]
        if epoch == self.token_epoch:
            return [] if owner == self.token_owner else [self._token_message()]
        self.token_epoch, self.token_owner = epoch, owner
        self.idle_since = None
        if owner == self.role:
            self.inbound.start_round()
        return [self._token_message()]

    def tick(self, now: float) -> list[AppMessage]:
        outgoing = self.outbound.tick(now)
        if self.token_owner == self.role:
            outgoing.extend(self.inbound.tick(now))
            if self._receive_idle():
                if self.idle_since is None:
                    self.idle_since = now
                elif now - self.idle_since >= max(1.0, self.scan_interval):
                    self.token_epoch += 1
                    self.token_owner = self.peer_role
                    self.last_token_sent = now
                    self.idle_since = None
                    outgoing.append(self._token_message())
            else:
                self.idle_since = None
        if now - self.last_token_sent >= 1.0:
            self.last_token_sent = now
            outgoing.append(self._token_message())
        return outgoing
