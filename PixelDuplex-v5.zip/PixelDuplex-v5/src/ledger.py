"""Small, atomic JSON ledger used by both PixelDuplex roles."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path


LEDGER_VERSION = 2


class LedgerError(RuntimeError):
    pass


class Ledger:
    def __init__(self, path: Path, role: str):
        self.path = path
        self.role = role
        self.data = self._load()

    def _empty(self) -> dict:
        return {
            "version": LEDGER_VERSION,
            "role": self.role,
            "outgoing": {},
            "incoming": {},
        }

    def _load(self) -> dict:
        if not self.path.exists():
            return self._empty()
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as error:
            raise LedgerError(f"ledger is unreadable; refusing to discard state: {error}") from error
        if not isinstance(value, dict) or value.get("version") != LEDGER_VERSION:
            raise LedgerError("unsupported or invalid ledger format")
        if (
            value.get("role") != self.role
            or not isinstance(value.get("outgoing"), dict)
            or not isinstance(value.get("incoming"), dict)
        ):
            raise LedgerError("ledger role or directional maps are invalid")
        return value

    def save(self) -> None:
        atomic_json(self.path, self.data)

    def scope(self, direction: str) -> "LedgerScope":
        if direction not in {"outgoing", "incoming"}:
            raise ValueError("ledger direction must be outgoing or incoming")
        return LedgerScope(self, direction)

    def get(self, relative_path: str, direction: str) -> dict | None:
        self.scope(direction)
        value = self.data[direction].get(relative_path)
        return value if isinstance(value, dict) else None

    def is_complete(self, relative_path: str, direction: str) -> bool:
        item = self.get(relative_path, direction)
        return bool(item and item.get("status") == "SUCCESS")

    def record(self, relative_path: str, *, direction: str, status: str, size: int | None = None,
               sha256: str | None = None, session_id: str | None = None,
               reason: str | None = None) -> None:
        self.scope(direction)
        item = {
            "status": status,
            "size": size,
            "sha256": sha256,
            "session_id": session_id,
            "reason": reason,
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        }
        self.data[direction][relative_path] = item
        self.save()


class LedgerScope:
    """Directional view that lets both engines safely share one ledger object."""

    def __init__(self, ledger: Ledger, direction: str):
        self.ledger = ledger
        self.direction = direction

    def get(self, relative_path: str) -> dict | None:
        return self.ledger.get(relative_path, self.direction)

    def is_complete(self, relative_path: str) -> bool:
        return self.ledger.is_complete(relative_path, self.direction)

    def record(self, relative_path: str, **values) -> None:
        self.ledger.record(relative_path, direction=self.direction, **values)


REPLACE_ATTEMPTS = 5
REPLACE_RETRY_SECONDS = 0.05


def atomic_json(path: Path, value: dict) -> None:
    """Write a complete temporary file, then replace the target atomically.

    On Windows a reader holding the target open (a status or ledger check)
    makes the replace fail with PermissionError; retry briefly, then raise.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    for attempt in range(REPLACE_ATTEMPTS):
        try:
            with temporary.open("w", encoding="utf-8", newline="\n") as stream:
                json.dump(value, stream, ensure_ascii=False, indent=2, sort_keys=True)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
            return
        except PermissionError:
            if attempt == REPLACE_ATTEMPTS - 1:
                raise
            time.sleep(REPLACE_RETRY_SECONDS)
