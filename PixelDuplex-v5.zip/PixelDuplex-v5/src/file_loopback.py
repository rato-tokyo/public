"""Explicit, bounded file round-trip diagnostic on the responder."""

from __future__ import annotations

import os
import re
import uuid
from pathlib import Path

from .files import is_regular_without_reparse, safe_output_path, sha256_file


MAX_ECHO_BYTES = 65536
_DIGEST = re.compile(r"[0-9a-f]{64}\Z")
_ID = re.compile(r"[0-9a-f]{32}\Z")


def validate_arm(value: object) -> dict:
    if not isinstance(value, dict):
        raise ValueError("echo request is not an object")
    request_id = value.get("id")
    if not isinstance(request_id, str) or not _ID.fullmatch(request_id):
        raise ValueError("invalid echo id")
    if value.get("path") != f"pixelduplex-test/{request_id}/forward.bin":
        raise ValueError("invalid echo source path")
    if value.get("return_path") != f"pixelduplex-test/{request_id}/return.bin":
        raise ValueError("invalid echo return path")
    size = value.get("size")
    if type(size) is not int or not 0 <= size <= MAX_ECHO_BYTES:
        raise ValueError("invalid echo size")
    digest = value.get("sha256")
    if not isinstance(digest, str) or not _DIGEST.fullmatch(digest):
        raise ValueError("invalid echo digest")
    return value


def copy_verified_echo(received_root: Path, target_root: Path, request: dict) -> None:
    """Publish the verified receive without replacing any existing target."""
    source = safe_output_path(received_root, request["path"])
    destination = safe_output_path(target_root, request["return_path"])
    if not is_regular_without_reparse(source):
        raise ValueError("echo source is not a regular file")
    if source.stat().st_size != request["size"] or sha256_file(source) != request["sha256"]:
        raise ValueError("echo source does not match request")
    if destination.exists():
        if (is_regular_without_reparse(destination) and
                destination.stat().st_size == request["size"] and
                sha256_file(destination) == request["sha256"]):
            return
        raise FileExistsError("echo return path already exists with different content")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary_dir = target_root.parent / "artifacts" / "reports"
    temporary_dir.mkdir(parents=True, exist_ok=True)
    temporary = temporary_dir / f"file-test-return-{uuid.uuid4().hex}.tmp"
    try:
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, "wb") as output, source.open("rb") as input_stream:
            while chunk := input_stream.read(65536):
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
        if temporary.stat().st_size != request["size"] or sha256_file(temporary) != request["sha256"]:
            raise ValueError("echo source changed while copying")
        # Hard-link creation is atomic and fails if a competing file appeared.
        os.link(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
